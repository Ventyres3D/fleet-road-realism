Fleet & Road Realism - Fahrzeugdaten (.v3def) / vehicle data files (.v3def)
===========================================================================

DE
==

Steuern und Strassenabgaben der eigenen Zulassung (Kfz-Steuer in Deutschland,
Oesterreich, der Schweiz, Frankreich, Italien, Polen, Tschechien, der Slowakei,
Ungarn, Griechenland, Rumaenien, Bulgarien, Slowenien, Kroatien, Serbien,
Montenegro, Nordmazedonien, Bosnien und Herzegowina, Albanien, der Tuerkei,
Russland, Litauen, Lettland, Estland und Kosovo, Schweizer LSVA) brauchen Angaben zum
Fahrzeug. Das meiste liest die Mod aus den .sii-Dateien des Fahrzeugs selbst:

  Motor-.sii     Leistung (info[] "... (270@@kw@@)", sonst aus torque und
                 torque_curve[]), Hubraum (volume), Elektro (type: electric)
  Chassis-.sii   Achszahl (residual_travel[]), Leergewicht
                 (Lkw: Summe von kerb_weight[], Auflieger: trailer_mass)
  Aufbau-.sii    Masse (kommt zu trailer_mass dazu)

Was die Spieldateien nicht enthalten (Euro-Klasse, zulaessige Gewichte,
Sattelzugmaschine oder Solo-Lkw, Art der Federung), kommt aus kleinen
optionalen Dateien, die eine Lkw- oder Auflieger-Mod neben ihren eigenen
Definitionen mitliefern kann. Dieselben Dateien stellen auch die Lage von
Kennzeichen und Schildern ein, Doubles (Zulassung, Trennen beim Beladen,
Kabel, Kuppeltoene, Fanghilfe, Stuetzen), animiertes Zubehoer, den Ladeboden
und die Aufliegerlaengen der Fahrertouren.

Alle Dateien sind optional. Eine fehlende Datei oder Zeile ist kein Fehler, es
gilt der Standardwert, der unter "Schluessel" bei jedem Eintrag steht.

Wo die Dateien liegen
---------------------
Gleicher Ordner und gleicher Name wie die .sii, die das Fahrzeug nutzt, nur mit
.v3def:

  Motor          /def/vehicle/truck/your_truck/engine/your_engine.sii
              -> /def/vehicle/truck/your_truck/engine/your_engine.v3def

  Motorsound     (fuer Soundmods, nur Kaltstart-Nageln, siehe "MOTORSOUND")
                 neben der Sound-.sui, die die Motor-.sii per @include einbindet:
                 /def/vehicle/truck/your_truck/engine/sound.sui
              -> /def/vehicle/truck/your_truck/engine/sound.v3def
                 und/oder neben der .soundref aus sounds[] "engine|...":
                 /def/vehicle/truck/your_truck/engine/sound_engine.soundref
              -> /def/vehicle/truck/your_truck/engine/sound_engine.v3def

  Lkw-Chassis    /def/vehicle/truck/your_truck/chassis/your_chassis.sii
              -> /def/vehicle/truck/your_truck/chassis/your_chassis.v3def

  Auflieger      /def/vehicle/trailer_owned/your_trailer/chassis/your_chassis.sii
              -> /def/vehicle/trailer_owned/your_trailer/chassis/your_chassis.v3def

  Firmenauflieger (Auftragsauflieger, kein Ordner chassis/: das Chassis ist
  die .sii, deren Name mit "chassis" beginnt)
                 /def/vehicle/trailer/your_company_trailer/chassis_hook.sii
              -> /def/vehicle/trailer/your_company_trailer/chassis_hook.v3def

  Zubehoer       /def/vehicle/trailer_owned/your_trailer/accessory/r_bumper/your_bumper.sii
              -> /def/vehicle/trailer_owned/your_trailer/accessory/r_bumper/your_bumper.v3def
                 (Heckstossstangen, siehe "ZUBEHOER HECKSTOSSSTANGE" unter "Schluessel")

  Spiegel        /def/vehicle/truck/your_truck/accessory/mirror/your_mirror.sii
              -> /def/vehicle/truck/your_truck/accessory/mirror/your_mirror.v3def
                 (auch s_mirror, f_mirror usw., siehe "ZUBEHOER SPIEGEL" unter "Schluessel")

  Innenraum      /def/vehicle/truck/your_truck/interior/your_interior.sii
              -> /def/vehicle/truck/your_truck/interior/your_interior.v3def
                 (Schlafen, Woelbung der Frontscheibe, siehe "ZUBEHOER INNENRAUM")

  Kabine         /def/vehicle/truck/your_truck/cabin/your_cabin.sii
              -> /def/vehicle/truck/your_truck/cabin/your_cabin.v3def
                 (Waschduesen, siehe "WASCHDUESEN")

Die Beispiele im Ordner def/ dieses Pakets zeigen das Format.


Format
------
  schluessel: wert

  - ein Eintrag je Zeile, Leerzeichen oder Tabs um den Doppelpunkt erlaubt
  - Zeilen mit # oder // am Anfang sind Kommentare, ein # nach dem Wert auch
  - Gewichte: Tonnen (Werte bis 100, z. B. 18.00) oder Kilogramm (ueber 100,
    z. B. 18000)
  - Dezimalpunkt oder Dezimalkomma (18.50 oder 18,50), kein Tausendertrenner
  - emission: ganze Zahl 0-7
  - type: tractor, rigid oder swapbody (Lkw); semitrailer, dolly, drawbar,
    centeraxle oder swapbody (Auflieger)
  - suspension: air oder leaf
  - registration: own, next, prev oder none
  - loading: own, next oder prev
  - load_split: true oder false
  - cable_connect: Meter groesser 0 bis 20 (z. B. 1.2)
  - fixed_plate: Spiel-Token des Landes, z. B. germany, optional |Kuerzel
  - cylinders: ganze Zahl 1-16
  - knock_strength: Zahl 0-3 (z. B. 0.5)
  - knock_tone: Zahl 0.4-2 (z. B. 0.7)
  - mirror_axes: horizontal, vertical oder both
  - mirror_rain_size: Zahl groesser 0 bis 20 (z. B. 0.5)
  - sleeper: true oder false
  - bed_head: a oder b
  - washer: fixed oder wiper
  - washer_jets: single oder double
  - washer_jets_angle: Grad 5-170
  - Koordinaten (bed_area, washer_spot[], washer[n]): x;y;z, so wie ZModeler sie
    anzeigt
  - italy_/serbia_card_shift_front / _rear: Millimeter, positiv = hoch,
    negativ = runter, -200 bis 200 (z. B. 15 oder -7.5)
  - italy_/serbia_card_depth_front / _rear: Millimeter, positiv = weg vom
    Fahrzeug, negativ = zum Fahrzeug hin, -200 bis 200
  - italy_/serbia_card_tilt_rear: Grad, positiv = Oberkante zum Fahrzeug hin,
    negativ = Oberkante vom Fahrzeug weg, -45 bis 45 (z. B. 12.5)
  - greece_export_shift_front / _rear: Millimeter, positiv = hoch, negativ =
    runter, -200 bis 200
  - greece_export_depth_front / _rear: Millimeter, positiv = weg vom Fahrzeug,
    negativ = zum Fahrzeug hin, -200 bis 200
  - greece_export_rotate_front / _rear: Grad, positiv = Oberkante zum Fahrzeug
    hin, negativ = Oberkante vom Fahrzeug weg, -45 bis 45
  - plate_depth_front / _rear: Millimeter, positiv = weg vom Fahrzeug,
    negativ = zum Fahrzeug hin, -200 bis 200
  - plate_rotate_front / _rear: Grad, positiv = Oberkante zum Fahrzeug hin,
    negativ = Oberkante vom Fahrzeug weg, -45 bis 45
  - sonst nichts in der Zeile (keine Einheiten wie "t" oder "kg")

Schluessel
==========
Jeder Eintrag beginnt mit >>> und zeigt die Zeile so, wie sie in die v3def
kommt (<...> = eigener Wert, | = eins davon). Alles darunter ist Beschreibung.

MOTOR
-----
/def/vehicle/truck/xxxx/engine/xxxx.v3def

  >>> emission: 0 - 7
      Euro-Klasse 0-7
      Standard: Euro 6

  KALTSTART-NAGELN
  Ein kalter Diesel nagelt: Die Mod mischt dem Motorsound des eigenen Lkw je
  Zuendung einen kurzen metallischen Schlag bei, dazu einen leicht unrunden
  Lauf und einen raueren Klang. Wie kalt der Motor ist, rechnet die Mod genau
  wie das Spiel fuer cold_start_rpm aus der Oeltemperatur (voll bis etwa 19 Grad
  C, weg ab 90 Grad C). Am staerksten im Leerlauf und beim Anfahren unter Last
  bei niedriger Drehzahl, mit steigender Drehzahl schwaecher. Elektromotoren
  nageln nicht.
  Der Motorsound kommt aus sounds[] "engine|..." der Motor-.sii (auch ueber
  @include), direkt als "<bank>#<event>" oder ueber eine .soundref. Nur dieses
  Ereignis bekommt das Nageln, exhaust, turbo usw. nicht. Dafuer muss nichts
  eingetragen werden; die drei Zeilen unten sind nur Feineinstellung.

  >>> cylinders: <1 - 16>
      Zahl der Zylinder; bestimmt den Takt der Schlaege
      (Drehzahl / 60 x Zylinder / 2 je Sekunde)
      Standard: 6

  >>> knock_strength: <0 - 3>
      Staerke des Nagelns (und des unrunden Laufs) fuer diesen Motor,
      1 = normal, 0.5 = halb so stark, 2 = doppelt, 0 = aus
      Standard: 1

  >>> knock_tone: <0.4 - 2>
      Tonhoehe des Nagelns fuer diesen Motor, damit es zum Klang des
      Motorsounds passt; kleiner = tiefer und dumpfer (z. B. grosse V8),
      groesser = heller und haerter
      Standard: 1

MOTORSOUND
----------
/def/vehicle/truck/xxxx/engine/sound.v3def         (neben der Sound-.sui)
/def/vehicle/truck/xxxx/engine/sound_engine.v3def  (neben der .soundref)

  Fuer Soundmods, die nur die Sound-.sui oder nur die .soundref ersetzen:
  dieselben drei Zeilen wie beim Kaltstart-Nageln des Motors, passend zum
  eigenen Sound. Es gilt immer der genaueste Wert: .soundref-.v3def vor
  Sound-.v3def vor Motor-.v3def. Eine Zeile, die fehlt, kommt von der
  naechsten Datei.

  >>> cylinders: <1 - 16>
      wie beim Motor
      Standard: Wert der Motor-.v3def

  >>> knock_strength: <0 - 3>
      wie beim Motor
      Standard: Wert der Motor-.v3def

  >>> knock_tone: <0.4 - 2>
      wie beim Motor
      Standard: Wert der Motor-.v3def

CHASSIS LKW
-----------
/def/vehicle/truck/xxxx/chassis/xxxx.v3def

  >>> type: tractor | rigid | swapbody
      tractor = Sattelzugmaschine
      rigid = Solo-Lkw (Ladung auf dem eigenen Rahmen)
      swapbody = Wechselbrueckenfahrzeug (Fahrgestell fuer Wechselaufbauten);
                 Steuer und Papiere wie rigid, im deutschen Fahrzeugschein
                 "Wechselfahrgestell"
      Standard: tractor

      Welche Auflieger passen (feste Gespanne, Frachtauftraege mit
      Firmenauflieger, Schnellauftraege): es zaehlt der "type" des vordersten
      Teils des Aufliegers (siehe CHASSIS AUFLIEGER)
        tractor   nur semitrailer
        rigid     dolly, drawbar, centeraxle
        swapbody  dolly, drawbar, centeraxle und swapbody
      Unpassende Auftraege werden fuer diesen Lkw nur ausgeblendet, das
      Angebot bleibt bestehen.

  >>> fixed_plate: "<land>" | "<land>|<Kuerzel>"
      Kennzeichen fest im Modell (ohne Kennzeichen-Locator des Spiels), z. B.
      bei Paketen mit echten, festen Kennzeichen am Fahrzeug

        fixed_plate: "germany"
        fixed_plate: "germany|HN"

      Das Fahrzeug ist ab dem Kauf fest in diesem Land zugelassen: kein
      Kurzzeitkennzeichen, keine Zulassungspflicht. Kfz-Steuer nach den Regeln
      dieses Landes (Gewicht, Achsen, Euro-Klasse usw. wie bei jedem Fahrzeug aus
      den uebrigen Eintraegen). Versicherung ist die gesetzliche Haftpflicht,
      aenderbar im Versicherungsmenue (F7). Der Zulassungsservice ist fuer das
      Fahrzeug gesperrt: keine Zulassungs-Kachel in der Werkstatt, kein Klick auf
      das Kennzeichen im Manager.
      <land> = Spiel-Token des Landes (germany, austria, netherlands ...).
      <Kuerzel> = Zulassungsbezirk, so wie er im Zulassungsfenster steht; ohne
      Kuerzel der Standardbezirk des Landes. Wichtig, wo die Steuer vom Bezirk
      abhaengt (z. B. Polen, Rumaenien, Frankreich).
      Fahrzeuge, die schon im Besitz sind (Kurzzeit, abgemeldet oder in einem
      anderen Land zugelassen), werden einmal auf das Land umgeschrieben; die
      alte Steuer endet, Schadenfreiheitsklasse und Versicherung bleiben.
      Standard: kein Eintrag = normale Zulassung
  >>> gross_combination_weight: <Tonnen oder kg>
      zulaessiges Zuggesamtgewicht
      Standard: 40 t

  >>> plate_depth_front: <mm>
      Kennzeichen vorne vor/zurueck, mm

      Wie die Pappschild-Schluessel, aber fuer alle normalen Kennzeichen des Chassis
      (feste und Kurzzeitkennzeichen; Pappschilder und Papiere behalten ihre eigenen
      Schluessel). plate_depth_front / plate_depth_rear verschieben das Kennzeichen
      vor oder zurueck in Millimetern: positive Werte weg vom Fahrzeug (z. B. aus
      einer Mulde oder einer Stossstange heraus), negative zum Fahrzeug hin.
      plate_rotate_front / plate_rotate_rear neigen das Kennzeichen um seine
      waagerechte Mittellinie (von der Seite gesehen), in Grad: positive Werte
      bringen die Oberkante zum Fahrzeug hin und die Unterkante weg, negative
      umgekehrt. Ein Auflieger hat nur das hintere Kennzeichen. Verschoben werden nur
      die Fahrzeuge der eigenen Firma.

        plate_depth_rear: 12        # hinteres Kennzeichen 12 mm weiter aussen
        plate_rotate_front: -8      # vorderes Kennzeichen, Oberkante 8 Grad weg
      Standard: 0

  >>> plate_rotate_front: <Grad>
      Kennzeichen vorne Neigung, Grad
      Standard: 0

  >>> italy_card_shift_front: <mm>
      italienisches Pappschild (foglio di via) vorne hoch/runter, mm

      Die italienische Kurzzeitzulassung (foglio di via, Pappe 275 x 200 mm) und das
      serbische Probekennzeichen (PROBA, Pappe 340 x 180 mm) sind Pappschilder, die
      viel groesser als ein Kennzeichen sind. Je nach Modell reichen sie bis an eine
      Rueckleuchte, verschwinden hinter einem Unterfahrschutz oder in der
      Kennzeichenmulde. Italien nutzt die Schluessel italy_card_*, Serbien die
      Schluessel serbia_card_*. Das montenegrinische Probekennzeichen (PROBA) ist so
      gross wie das serbische und nutzt ebenfalls serbia_card_*, eine Einstellung
      passt also fuer beide.

      Die Standardhoehe passt schon fuer die Fahrzeuge des Spiels:
        Lkw vorne     mittig auf dem Kennzeichen
        Lkw hinten    30 mm tiefer als das Kennzeichen
        Auflieger     10 mm tiefer als das Kennzeichen

      ..._card_shift_front / ..._card_shift_rear verschieben das Schild von diesem
      Standard aus fuer ein Chassis hoch oder runter, in Millimetern: positive Werte
      hoch, negative runter. ..._card_depth_front / ..._card_depth_rear verschieben
      es vor oder zurueck: positive Werte weg vom Fahrzeug (aus der Kennzeichenmulde
      heraus), negative zum Fahrzeug hin. ..._card_tilt_rear neigt das hintere Schild
      um seine waagerechte Mittellinie (von der Seite gesehen), in Grad: positive
      Werte bringen die Oberkante zum Fahrzeug hin und die Unterkante weg (z. B. um
      einem schraegen Kennzeichenhalter zu folgen), negative umgekehrt. Ein
      Auflieger hat nur das hintere Schild.

        italy_card_shift_rear: 15      # 15 mm hoeher als der Standard
        italy_card_shift_front: -10    # 10 mm tiefer als der Standard
        serbia_card_depth_rear: 20     # 20 mm weiter aus der Kennzeichenmulde
        serbia_card_tilt_rear: 10      # Oberkante 10 Grad zum Fahrzeug geneigt
      Standard: 0

  >>> italy_card_depth_front: <mm>
      italienisches Pappschild vorne vor/zurueck, mm
      Standard: 0

  >>> serbia_card_shift_front: <mm>
      serbisches/montenegrinisches Pappschild (PROBA) vorne hoch/runter, mm
      Standard: 0

  >>> serbia_card_depth_front: <mm>
      PROBA-Schild vorne vor/zurueck, mm
      Standard: 0

  >>> greece_export_shift_front: <mm>
      griechisches Exportschild vorne hoch/runter, mm

      Das griechische Exportschild ist kleiner und hoeher als ein normales
      Kennzeichen (370 x 120 mm statt 520 x 110 mm) und wird als eigenes Schild
      gezeichnet, mittig auf dem normalen Kennzeichen. greece_export_shift_front /
      _rear verschieben es hoch oder runter in Millimetern (positiv hoch),
      greece_export_depth_front / _rear vor oder zurueck (positiv weg vom Fahrzeug),
      greece_export_rotate_front / _rear neigen es um seine waagerechte Mittellinie
      in Grad (positiv = Oberkante zum Fahrzeug hin). Ohne Eintrag sind alle Werte
      0. Ein Auflieger hat nur das hintere Schild.

        greece_export_shift_rear: 12     # 12 mm hoeher
        greece_export_rotate_front: -5   # Oberkante 5 Grad weg geneigt
      Standard: 0

  >>> greece_export_depth_front: <mm>
      griechisches Exportschild vorne vor/zurueck, mm
      Standard: 0

  >>> greece_export_rotate_front: <Grad>
      griechisches Exportschild vorne Neigung, Grad
      Standard: 0

  KIPPBARE SATTELKUPPLUNG
  Die Platte der Sattelkupplung kann sich um ihr Lager neigen. Gekuppelt folgt
  sie der Laengsneigung des Aufliegers gegenueber dem Lkw, beim Unterfahren
  einer Aufliegerfront ebenso, sonst faellt sie in ihre Ruhelage zurueck.
  Beim Anschlagen am Auflieger und beim Zurueckfallen spielt ein Ton, je nach
  Wucht lauter oder leiser. Die Platte ist ein eigenes Modell an einem Locator
  des Chassis-Modells:

    couple_model: "/vehicle/truck/your_truck/fifthwheel.pmd"
    couple_tilt_front: 10
    couple_tilt_rear: 15
    couple_tilt_rest: 5

  - Locator couple_0 im Chassis-Modell = Lager der Platte (bei mehreren
    Kupplungen couple_1, couple_2 ... mit [1], [2] ... an den Schluesseln)
  - die Platte (.pmd): nur das drehbare Teil, Ursprung im Lager, Ausrichtung
    wie im Lkw. Das Chassis-Modell selbst enthaelt die Platte nicht mehr (in
    den groeberen LODs darf sie fest bleiben)

  >>> couple_model[n]: "<Pfad>.pmd"
      Modell der drehbaren Platte am Locator couple_n; ohne [n] = [0]

  >>> couple_tilt_front[n]: <Grad>
      wie weit sich die Platte nach vorn neigen kann, Grad (0 bis 45)
      Standard: starr (nach vorn keine Neigung)

  >>> couple_tilt_rear[n]: <Grad>
      wie weit sich die Platte nach hinten neigen kann, Grad (0 bis 45)
      Standard: starr (nach hinten keine Neigung)

  >>> couple_tilt_rest[n]: <Grad>
      Ruhelage ohne Auflieger, Grad (-45 bis 45), positiv = hinten tiefer
      Standard: aus dem Schwerpunkt der Platte

  >>> couple_contact_sound[n]: <.soundref oder .bank#event, - = kein Ton>
      Ton beim Anschlagen am Auflieger
      Standard: Ton der Mod (/sound/lphd/fifthwheel.bank#contact)

  >>> couple_rest_sound[n]: <.soundref oder .bank#event, - = kein Ton>
      Ton beim Zurueckfallen in die Ruhelage
      Standard: Ton der Mod (/sound/lphd/fifthwheel.bank#rest)

CHASSIS AUFLIEGER
-----------------
/def/vehicle/trailer_owned/xxxx/chassis/xxxx.v3def
Firmenauflieger: /def/vehicle/trailer/xxxx/chassis_xxxx.v3def

  >>> type: semitrailer | dolly | drawbar | centeraxle | swapbody
      Art dieses Teils, so wie er in echt ist
      semitrailer = Sattelauflieger (liegt mit king_pin_load auf dem Teil davor)
      dolly       = Dolly (Achsaggregat mit Deichsel und Sattelkupplung)
      drawbar     = Deichselanhaenger bzw. Drehschemelachse eines
                    Drehschemelanhaengers
      centeraxle  = Zentralachsanhaenger
      swapbody    = die Wechselbruecke selbst (Auflieger mit unsichtbaren
                    Raedern): keine Zulassung (wie "registration: none"),
                    passt nur an Lkw mit "type: swapbody"
      dolly, drawbar und centeraxle haben keine Sattellast (king_pin_load
      wird ignoriert).
      In den Papieren: semitrailer = Sattelanhaenger, centeraxle =
      Zentralachsanhaenger, drawbar und dolly = Anhaenger.
      Bei mehrteiligen Aufliegern bekommt jeder Teil seinen eigenen Typ; fuer
      feste Gespanne und Auftraege zaehlt nur der vorderste Teil (siehe CHASSIS
      LKW, type). Gilt auch fuer Firmenauflieger.
      Standard: semitrailer

  >>> king_pin_load: <Tonnen oder kg>
      Last auf dem Koenigszapfen (nur semitrailer)
      Standard: nach Achszahl: 1 -> 10 t, sonst 12 t

  >>> registration: own | next | prev | none
      own = eigene Zulassung
      next = gehoert zum Teil dahinter
      prev = gehoert zum Teil davor
      none = keine Zulassung (z. B. Wechselbruecke als Auflieger mit
             unsichtbaren Raedern; bei "type: swapbody" automatisch)

      "registration: none": das Teil ist kein Fahrzeug im Sinne der Zulassung,
      sondern ein Aufbau bzw. Ladung:
        - kein Eintrag in der Zulassungsstelle, keine Zulassungs-Kachel in der
          Werkstatt, kein Klick auf das Kennzeichen im Auflieger-Manager
        - keine Kennzeichen (auch beim Kauf kein Kurzzeitkennzeichen), keine
          Fahrzeugpapiere
        - keine Kfz-Steuer, keine Versicherung, keine Strafen wegen Zulassung
      Das Fahrzeug, auf dem die Wechselbruecke sitzt, bleibt normal zugelassen.

      Eigene Auflieger mit mehr als einem Chassis (B-Double, HCT, Sattelauflieger auf
      einem Dolly, Drehschemelanhaenger) sind im Spiel eine Kette aus Teilen. Ohne
      "registration"-Zeile ist jeder Teil ein eigenes Fahrzeug: eigener Eintrag in
      der Zulassungsstelle, eigenes Kennzeichen, eigene Steuer und Versicherung. Das
      ist richtig fuer Sattelauflieger und fuer Dollys, die in echt eigene
      zugelassene Fahrzeuge sind.

      "registration: next" oder "registration: prev" verbindet ein Chassis mit
      seinem Nachbarn. Nur fuer Teile verwenden, die in echt kein eigenes Fahrzeug
      sind, z. B. die Drehschemelachse (vorderer Teil) eines Drehschemelanhaengers.
      Verbundene Teile sind ein Fahrzeug:
        - ein Eintrag in der Zulassungsstelle, zugelassen unter dem Kennzeichen des
          hintersten Teils (das hinten zu sehen ist)
        - Steuer und Versicherung einmal, fuer das ganze Fahrzeug
        - beim Kauf kein eigenes Kurzzeitkennzeichen; der verbundene Teil behaelt das
          Kennzeichen, das das Spiel ihm gibt

      "next" und "prev" beziehen sich auf die Lage, so passt dasselbe Chassis in
      jeder Zusammenstellung, in der es vorkommt. Verbindungen koennen hintereinander
      gehen.

      Werte eines verbundenen Fahrzeugs
        Achsen          Summe der Teile
        Leergewicht     Summe der Teile
        Gesamtgewicht   Summe von gross_vehicle_weight aller Teile
                        minus king_pin_load jedes Teils hinter dem ersten
                        (diese Last liegt auf dem Teil davor und ist dort schon
                        gezaehlt)
        Sattellast      die des vorderen Teils (Last auf dem Lkw)

      Jedem Teil die Werte geben, die er fuer sich hat - aufteilen muss man nichts.

      Beispiel 1: Drehschemelanhaenger, 2 Achsen, 18 t (ein Fahrzeug)

        Drehschemelachse (vorne) type: drawbar
                                 registration: next
                                 gross_vehicle_weight: 9.00
                                 (Deichsel, nichts auf dem Lkw)
        hinterer Teil            (kein type = semitrailer, liegt auf dem
                                 Drehschemel)
                                 gross_vehicle_weight: 18.00
                                 king_pin_load: 9.00

        -> 1 Fahrzeug, 2 Achsen, 9 + 18 - 9 = 18 t, keine Sattellast auf dem
           Lkw, passt an rigid und swapbody

      Beispiel 2: Sattelauflieger auf einem Dolly (zwei Fahrzeuge, keine
      "registration"-Zeile)

        Dolly                    type: dolly
                                 gross_vehicle_weight: 18.00
        Sattelauflieger          (kein type = semitrailer)
                                 gross_vehicle_weight: 39.00
                                 king_pin_load: 12.00

        -> 2 Fahrzeuge mit 2 Zulassungen, jedes mit seinen eigenen Werten besteuert
           (Dolly 18 t, Sattelauflieger 39 t mit 12 t auf dem Dolly)

      Beispiel 3: HCT Sattelauflieger + Dolly + Sattelauflieger

        keine "registration"-Zeilen -> 3 Fahrzeuge (Sattelauflieger, Dolly,
                                       Sattelauflieger)
        Dolly "type: dolly", die Sattelauflieger ohne type -> passt nur an
        Sattelzugmaschinen (vorderster Teil semitrailer)

      "prev" am ersten Teil oder "next" am letzten Teil eines Aufliegers ist ein
      Fehler (siehe unten), der Teil gilt dann als "own".
      Standard: own

  >>> fixed_plate: "<land>" | "<land>|<Kuerzel>"
      Kennzeichen fest im Modell (ohne Kennzeichen-Locator des Spiels), z. B.
      bei Paketen mit echten, festen Kennzeichen am Fahrzeug

        fixed_plate: "germany"
        fixed_plate: "germany|HN"

      Das Fahrzeug ist ab dem Kauf fest in diesem Land zugelassen: kein
      Kurzzeitkennzeichen, keine Zulassungspflicht. Kfz-Steuer nach den Regeln
      dieses Landes (Gewicht, Achsen, Euro-Klasse usw. wie bei jedem Fahrzeug aus
      den uebrigen Eintraegen). Versicherung ist die gesetzliche Haftpflicht,
      aenderbar im Versicherungsmenue (F7). Der Zulassungsservice ist fuer das
      Fahrzeug gesperrt: keine Zulassungs-Kachel in der Werkstatt, kein Klick auf
      das Kennzeichen im Manager.
      <land> = Spiel-Token des Landes (germany, austria, netherlands ...).
      <Kuerzel> = Zulassungsbezirk, so wie er im Zulassungsfenster steht; ohne
      Kuerzel der Standardbezirk des Landes. Wichtig, wo die Steuer vom Bezirk
      abhaengt (z. B. Polen, Rumaenien, Frankreich).
      Fahrzeuge, die schon im Besitz sind (Kurzzeit, abgemeldet oder in einem
      anderen Land zugelassen), werden einmal auf das Land umgeschrieben; die
      alte Steuer endet, Schadenfreiheitsklasse und Versicherung bleiben.
      Mehrteilige Auflieger: der Eintrag darf in jedem Teil der Gruppe stehen und
      gilt fuer die Zulassung der Gruppe.
      Standard: kein Eintrag = normale Zulassung
  >>> loading: own | next | prev
      Mit der Option "Eigene Doubles beim Beladen trennen" wird die Kette eines
      Aufliegers auf mehrere Ladespuren der Firma verteilt: von hinten bekommt
      jeder Teil eine eigene Spur und wird dort abgekuppelt (Taste zum
      Abkuppeln), der vordere Teil bleibt am Lkw und wird auf der Spur des
      Spiels beladen. Nach dem Beladen werden die Teile wieder
      zusammengekuppelt; die Tour beginnt, wenn die Kette vollstaendig ist. Beim
      Entladen wird die Kette nur getrennt, wenn im Abgabefenster des Aufliegers
      die schwierigste Wahl (meiste XP) genommen wird.

      Das gilt fuer eigene Auflieger und fuer Firmen-(Auftrags-)Auflieger
      gleichermassen. Es passiert nur, wenn Fracht be- oder entladen wird: einfaches
      Abstellen mit der Taste zum Abkuppeln (z. B. an einer Werkstatt oder einem
      Aufliegerhof) haelt die Kette immer zusammen.

      Welche Glieder zusammengehoeren, legt "loading" in der v3def jedes Chassis der
      Kette fest:
        own   das Glied ist eine eigene Ladeeinheit
        next  das Glied bleibt beim Glied dahinter (z. B. bleibt ein Dolly unter dem
              hinteren Sattelauflieger)
        prev  das Glied bleibt beim Glied davor

      Hat ein Glied der Kette keine "loading"-Zeile oder eine, die nicht gelesen
      werden kann, wird die Kette nie getrennt.

      Die Zeile gilt nur fuer die Kette, in der der Auflieger gerade ist. Ein
      Auflieger mit "loading: own", der als einzelner Auflieger faehrt, wird ganz
      normal beladen; derselbe Auflieger kann in einer anderen Kette der vordere Teil
      eines Doubles sein oder hinter einem Dolly mit "next" stehen.

      Beispiel: HCT Sattelauflieger + Dolly + Sattelauflieger
      (Dateien in def/vehicle/trailer_owned/your_hct/chassis/)

        vorderer Sattelauflieger front_trailer.v3def   loading: own
        Dolly                    dolly.v3def           loading: next
        hinterer Sattelauflieger rear_trailer.v3def    loading: own

        -> 2 Teile: vorderer Sattelauflieger / Dolly + hinterer Sattelauflieger

      Beispiel: Firmen-(Auftrags-)Double, Sattelauflieger + Zentralachsanhaenger
      (Dateien in def/vehicle/trailer/your_company_trailer/)

        vorderer Sattelauflieger chassis_hook.v3def    loading: own
        Zentralachsanhaenger     chassis_ca.v3def      loading: own

        -> 2 Teile: Sattelauflieger / Zentralachsanhaenger
      Standard: keiner (die Kette wird nie getrennt)

  >>> load_split: true | false
      false = beim Be- und Entladen wird die Kette nie getrennt (z. B.
      Holzauflieger, die von oben per Kran beladen werden); "loading" legt
      weiter fest, welche Teile sich unterwegs trennen lassen
      Standard: true

  >>> cable: prev | next | both | none
      wer den Kabelstrang beim Trennen behaelt: prev, next, both oder none

      Wird die Kette eines eigenen Doubles getrennt (Option "Eigene Doubles beim
      Beladen trennen", oder ein Teil mit der Taste zum Abkuppeln abgekuppelt), hat
      das Spiel selbst keine Regel fuer den Kabelstrang zwischen den beiden Teilen.
      Die Chassis-.v3def entscheidet:

        cable: prev    dieser Teil behaelt den Strang zum Teil davor
        cable: next    dieser Teil behaelt den Strang zum Teil dahinter
        cable: both    prev und next
        cable: none    dieser Teil behaelt nie einen Strang

      Mehrere "cable"-Zeilen sind erlaubt. Zwischen dem vorderen Teil A und dem
      hinteren Teil B:
        1. B hat prev oder both           -> der Strang bleibt an B (Ruhelage an B)
        2. sonst A hat next oder both     -> der Strang bleibt an A (Ruhelage wie im
                                             Spiel)
        3. sonst A hat none               -> der Strang bleibt an B
        4. sonst                          -> der Strang wird entfernt

      Ein Strang, der am hinteren Teil bleibt, behaelt seinen Aufliegerstecker in der
      Dose (z. B. des Dollys); das freie Ende geht an einen Ruhepunkt des
      Chassis-Modells:

        cable_rest_prev {
            rst_cable_y : 0.45; 1.20; 5.80 : 0; 0; 0
            rst_cable_w : 0.55; 1.20; 5.80 : 0; 0; 0
        }

        name : x; y; z : heading; pitch; roll   (Meter, Grad, Chassis-Modell)

      Der Eintrag wird ueber den Ruhe-Namen des Kabel-Zubehoers gewaehlt (Gross- und
      Kleinschreibung egal); hat das Zubehoer keinen Ruhe-Namen, ueber das Ende des
      Dosen-Locators (ele_cable_w -> ..._w), sonst nach der Reihenfolge der
      Straenge. Fehlende Ruhepunkte stehen in der fleet_road_realism.log.
      Werden die Teile wieder gekuppelt, verkabelt das Spiel die Kette wie gewohnt und die
      Ruhestraenge verschwinden.

      So legt die DLL einen Ruhestrang:
        - Die Z-Achse des Ruhepunkts (und des Dosen-Locators) zeigt zum Kabelende,
          also zum Steckerkopf. Das Kabel kommt auf der Gegenseite heraus: zeigt der
          Ruhepunkt nach unten, geht das Kabel nach oben aus dem Stecker.
        - Laenge: bei geraden Kabeln straight_cable_length des Kabel-Zubehoers,
          sonst die Seillaenge des Spiels.
        - An beiden Enden macht das Kabel einen Bogen (Steifigkeit, je laenger das
          Kabel, desto weiter); die Ueberlaenge haengt in der Mitte nach unten durch.
        - Das Kabel legt sich auf die Boxen der Chassis-Kollision (.pmc, bzw.
          collision_override): auf einer Deichsel liegt es oben auf. Boxen, die ueber
          beiden Kabelenden liegen (Rahmen, Aufbau), schieben das Kabel zur Seite
          oder nach unten, nie darueber.
        - Ist das Kabel kuerzer als der Weg von der Dose zum Ruhepunkt, wird es
          gespannt gezeichnet - dann den Ruhepunkt naeher an die Dose legen.
      Standard: keiner (beim Trennen wird der Kabelstrang zwischen den Teilen entfernt)

  >>> cable_connect: <m>
      nur am vorderen Glied eines Doubles, bei dem im gekuppelten Zustand kein Platz
      zum Kabelstecken ist (z. B. B-Double): Abstand in Metern zwischen den
      Kabelpunkten dieses Glieds und der Front des dahinter gekuppelten Teils, bei dem
      die Kabel gesteckt bzw. geloest werden (groesser 0, kleiner 20)

      Ankuppeln: zuruecksetzen bis zum Abstand, Kabel mit der Taste stecken, dann
      einhaken. Abkuppeln: Taste entriegelt, Stuetzen runter, Kabel bleiben gesteckt;
      bis zum Abstand vorfahren und mit der Taste loesen (weiter weg loesen sie sich
      von selbst).

        cable_connect: 1.2
      Standard: keiner (erst einhaken, dann Kabel stecken)

  >>> cable_rest_prev {
          ...
      }
      Ruhepunkte fuer die freien Steckerenden

  >>> hook_attach: <.soundref oder .bank#event, - = kein Ton>
      Ton Ankuppeln des Teils dahinter

      Kuppeltoene zwischen den Teilen, wie sie der Lkw in seiner sound.sui hat. Die
      Toene des vorderen Teils spielen am Kuppelpunkt:

        hook_attach: /sound/your_trailer/hook.soundref
        hook_detach: /sound/your_trailer.bank#hook_detach
        trailer_cables: /sound/your_trailer.bank#cables

        oder in der Form der sound.sui des Lkw:
        sounds[]: "hook_attach|/sound/your_trailer/hook.soundref"

        - Pfad zu einer .soundref oder bank#event, "-" = kein Ton
        - mehrere Zeilen mit demselben Namen: eine davon zufaellig
        - andere Ton-Namen (air_brake ...) werden ignoriert
        - '#' beginnt einen Kommentar nur am Zeilenanfang oder nach einem
          Leerzeichen (Pfade wie "bank#event" bleiben ganz)
      Standard: kein Ton

  >>> hook_detach: <.soundref oder .bank#event, - = kein Ton>
      Ton Abkuppeln des Teils dahinter
      Standard: kein Ton

  >>> trailer_cables: <.soundref oder .bank#event, - = kein Ton>
      Ton Kabel anstecken
      Standard: kein Ton

  >>> twistlock_lock: <.soundref oder .bank#event, - = kein Ton>
      Ton Twistlock verriegeln

      Twistlock-Toene von Containerchassis (Verriegeln und Oeffnen von Hand), am
      Twistlock:

        twistlock_lock: /sound/your_trailer.bank#lock
        twistlock_unlock: /sound/your_trailer.bank#open

        oder: sounds[]: "twistlock_lock|/sound/your_trailer.bank#lock"
        (twistlock_open ist dasselbe wie twistlock_unlock; Regeln wie oben)
      Standard: /sound/trailer/container.bank#lock

  >>> twistlock_unlock: <.soundref oder .bank#event, - = kein Ton>
      Ton Twistlock oeffnen (twistlock_open = dasselbe)
      Ton-Werte: .soundref oder .bank#event, oder sounds[]: "name|pfad" (siehe "hook_attach" und "twistlock_lock")
      Standard: /sound/trailer/container.bank#open

  >>> trailer_brace_up_sound: <.soundref oder .bank#event, - = kein Ton>
      Ton beim Hochfahren der Stuetzen, wenn die DLL einen Teil eines Doubles
      ankuppelt (z. B. "-" in der dolly.v3def, der Dolly hat keine Stuetzen)

      Je Stuetze ein eigener Ton mit [n] (Nummer wie bei trailer_brace_model[n]):

        trailer_brace_up_sound[0]: "/sound/your_trailer.bank#legs/up"
        trailer_brace_down_sound[0]: "/sound/your_trailer.bank#legs/down"

        - [n] gilt nur fuer Stuetze n, [] = naechste freie Nummer, "-" = kein Ton
        - ohne [] gilt der Ton fuer alle Stuetzen ohne eigenen Eintrag
        - Stuetze ohne eigenen Eintrag und ohne Eintrag ohne [] = Ton des Spiels
          (im Beispiel: Stuetze 1 hat den Ton des Spiels)
      Standard: Ton des Spiels

  >>> trailer_brace_down_sound: <.soundref oder .bank#event, - = kein Ton>
      Ton beim Herunterfahren der Stuetzen, wenn die DLL einen Teil eines
      Doubles abstellt; je Stuetze mit [n] (siehe "trailer_brace_up_sound")
      Standard: Ton des Spiels

  >>> dbl_coupling {
          ...
      }
      Fanghilfe beim Wiederankuppeln

      Formen, die die Teile ineinander fuehren, wenn ein abgekuppelter Teil eines
      eigenen Doubles wieder angekuppelt wird (Fangmaul hinten am vorderen Teil,
      Zugoese bzw. Koenigszapfen vorne am abgekuppelten Teil). Sie wirken wie die
      Fanghilfen des Spiels (pmc-Teile "adv_cpling"): weich, ohne Stoss, und nur
      solange dieser Teil angekuppelt wird; sonst sind sie aus.

        dbl_coupling {
            box : 0;0.543118;5.146128 : 0;0;0 : 0.099903;0.063770;0.153327
            cylinder : 0;0.539275;-5.769051 : 90.036583;0;0 : 0.053878;0.033937
        }

        box : x;y;z : rotX;rotY;rotZ : sizeX;sizeY;sizeZ
        capsule | cylinder : x;y;z : rotX;rotY;rotZ : scaleX;scaleZ

        - Lage in Metern, Drehung in Grad, Groessen - alles so, wie ZModeler es fuer
          das Chassis-Modell anzeigt
        - mehrere Zeilen, je eine Form
        - statt des Blocks darf die pmc des Chassis Teile mit dem Namen
          "dbl_cpling" enthalten

  >>> model_override: "<Pfad>.pmd"
      eigenes Chassis-Modell (.pmd)

      Ersetzt das Chassis-Modell des Spiels und fuegt Stuetzen hinzu, z. B. fuer
      einen Teil eines Doubles, der allein stehen kann:

        model_override: "/vehicle/trailer_owned/your_trailer/chassis.pmd"
        collision_override: "/vehicle/trailer_owned/your_trailer/chassis.pmc"

        trailer_brace_model[0]: "/vehicle/trailer_owned/your_trailer/brace_front.pmd"
        trailer_brace_anim[0]: "/vehicle/trailer_owned/your_trailer/brace_front.pma"
        trailer_brace_use[0]: always

        trailer_brace_model[1]: "/vehicle/trailer_owned/your_trailer/brace_rear.pmd"
        trailer_brace_anim[1]: "/vehicle/trailer_owned/your_trailer/brace_rear.pma"
        trailer_brace_use_min[1]: 5500
        trailer_brace_use[1]: loading

        - model_override (.pmd) / collision_override (.pmc): Modell und Kollision
          statt derer aus der Chassis-.sii
        - fehlt eine angegebene Datei (bei .pmd auch die .pmg), steht ein Fehler in
          der fleet_road_realism.log und das Modell des Spiels bleibt (kein Absturz)
        - trailer_brace_model / trailer_brace_anim: Modell (.pmd) und Animation
          (.pma) einer Stuetze, wie in der Chassis-.sii des Spiels. Ohne [] =
          Stuetze 0, mit [n] = Stuetze n (mehrere Stuetzen)
        - trailer_brace_use / trailer_brace_use_min immer mit [n] (oder []),
          model_override / collision_override immer ohne []; n hoechstens 15
        - trailer_brace_use[n]: always = die Stuetze geht immer runter, wenn der
          Teil abgestellt wird; loading = nur beim Trennen zum Be- und Entladen an
          der Firma, sonst nach Gewicht (trailer_brace_use_min)
        - trailer_brace_use_min[n]: kg - die Stuetze geht auch runter, wenn die
          Ladung des Teils mindestens so schwer ist
        - ohne trailer_brace_use: immer, bzw. nur nach Gewicht, wenn
          trailer_brace_use_min gesetzt ist
        - die Stuetzen gehen in der Reihenfolge der Eintraege runter und umgekehrt
          hoch; die Modellteile von Stuetze 0 sind brace_on / brace_off (oder
          brace_on_0 / brace_off_0), die von Stuetze n brace_on_n / brace_off_n

  >>> collision_override: "<Pfad>.pmc"
      eigene Chassis-Kollision (.pmc)

  >>> trailer_brace_model[n]: "<Pfad>.pmd"
      Modell der Stuetze n (.pmd)

  >>> trailer_brace_anim[n]: "<Pfad>.pma"
      Animation der Stuetze n (.pma)

  >>> trailer_brace_use[n]: always | loading
      always = immer
      loading = beim Trennen an der Firma, sonst nach Gewicht

  >>> trailer_brace_use_min[n]: <kg>
      kg - Stuetze geht auch runter ab diesem Ladungsgewicht
      (siehe "model_override")

CHASSIS ALLE (Lkw und Auflieger)
--------------------------------
/def/vehicle/truck/xxxx/chassis/xxxx.v3def
/def/vehicle/trailer_owned/xxxx/chassis/xxxx.v3def

  >>> gross_vehicle_weight: <Tonnen oder kg>
      zulaessiges Gesamtgewicht
      Standard: Lkw nach Achszahl: 2 -> 18 t, 3 -> 26 t, 4 und mehr -> 32 t
                Auflieger nach Achszahl: 1 -> 20 t, 2 -> 30 t, 3 und mehr -> 39 t

  >>> suspension: air | leaf
      air = Luftfederung (oder gleichwertig) der Antriebsachse(n) bzw.
      Aufliegerachsen
      leaf = jede andere Federung
      Standard: air

  >>> plate_depth_rear: <mm>
      Kennzeichen hinten vor/zurueck, mm
      (siehe "plate_depth_front" bei CHASSIS LKW)
      Standard: 0

  >>> plate_rotate_rear: <Grad>
      Kennzeichen hinten Neigung, Grad
      (siehe "plate_depth_front" bei CHASSIS LKW)
      Standard: 0

  >>> italy_card_shift_rear: <mm>
      italienisches Pappschild hinten hoch/runter, mm
      (siehe "italy_card_shift_front" bei CHASSIS LKW)
      Standard: 0

  >>> italy_card_depth_rear: <mm>
      italienisches Pappschild hinten vor/zurueck, mm
      (siehe "italy_card_shift_front" bei CHASSIS LKW)
      Standard: 0

  >>> italy_card_tilt_rear: <Grad>
      italienisches Pappschild hinten Neigung, Grad
      (siehe "italy_card_shift_front" bei CHASSIS LKW)
      Standard: 0

  >>> serbia_card_shift_rear: <mm>
      PROBA-Schild hinten hoch/runter, mm
      (siehe "italy_card_shift_front" bei CHASSIS LKW)
      Standard: 0

  >>> serbia_card_depth_rear: <mm>
      PROBA-Schild hinten vor/zurueck, mm
      (siehe "italy_card_shift_front" bei CHASSIS LKW)
      Standard: 0

  >>> serbia_card_tilt_rear: <Grad>
      PROBA-Schild hinten Neigung, Grad
      (siehe "italy_card_shift_front" bei CHASSIS LKW)
      Standard: 0

  >>> greece_export_shift_rear: <mm>
      griechisches Exportschild hinten hoch/runter, mm
      (siehe "greece_export_shift_front" bei CHASSIS LKW)
      Standard: 0

  >>> greece_export_depth_rear: <mm>
      griechisches Exportschild hinten vor/zurueck, mm
      (siehe "greece_export_shift_front" bei CHASSIS LKW)
      Standard: 0

  >>> greece_export_rotate_rear: <Grad>
      griechisches Exportschild hinten Neigung, Grad
      (siehe "greece_export_shift_front" bei CHASSIS LKW)
      Standard: 0

ZUBEHOER HECKSTOSSSTANGE
------------------------
/def/vehicle/trailer_owned/xxxx/accessory/r_bumper/xxxx.v3def

  Ein Zubehoer kann ein eigenes Modell und eine Animation bekommen, die je nach
  dem Teil dahinter laeuft, z. B. eine Heckstossstange, die hochklappt, wenn der
  naechste Teil eines Doubles angekuppelt ist. Derzeit fuer Heckstossstangen
  (accessory/r_bumper/) vom Zubehoer-Typ accessory_addon_data.

    model_override: "/vehicle/trailer_owned/upgrade/r_bumper/your_bumper.pmd"
    model_override_uk: "/vehicle/trailer_owned/upgrade/r_bumper/your_bumper_uk.pmd"
    collision_override: "/vehicle/trailer_owned/upgrade/r_bumper/your_bumper.pmc"
    model_anim: "/vehicle/trailer_owned/upgrade/r_bumper/your_bumper.pma"
    anim_type: attach_next
    anim_start: attached
    anim_distance: 2

  Locatoren des Modells, zu denen es einen Knochen mit gleichem Namen gibt,
  wandern mit der Animation mit (Leuchten, Kennzeichen). truckpaint-Materialien
  werden lackiert wie der Rest des Aufliegers.

  truckpaint-Meshes bei animiertem Zubehoer als eigene Objekte unter eigenen
  Knochen anlegen, nicht an andere Teile attachen. Sonst sehen nach dem
  Lackieren alle anderen Teile falsch aus (Leuchten schwarz, Texturen fehlen).

  >>> model_override: "<Pfad>.pmd"
      eigenes Modell (.pmd), statt exterior_model aus der Zubehoer-.sii

  >>> model_override_uk: "<Pfad>.pmd"
      eigenes UK-Modell (.pmd), statt exterior_model_uk aus der Zubehoer-.sii
      Standard: model_override

  >>> collision_override: "<Pfad>.pmc"
      eigene Kollision (.pmc), statt coll aus der Zubehoer-.sii

  >>> model_anim: "<Pfad>.pma"
      Animation (.pma) fuer das Modell

  >>> anim_type: attach_next
      attach_next = haengt vom Teil dahinter ab (der einzige Typ)

  >>> anim_start: attached | detached
      welchen Zustand das erste Bild der .pma zeigt: attached (Teil dahinter
      angekuppelt) oder detached

  >>> anim_distance: <Meter>
      Meter. "detached" nur, wenn hinten nichts angekuppelt ist und kein Teil des
      eigenen Doubles naeher steht (Ende zu Ende), damit die Stossstange die
      Tueren nicht blockiert, wenn die Teile zum Beladen dicht hintereinander
      stehen
      Standard: 2

ZUBEHOER SPIEGEL
----------------
/def/vehicle/truck/xxxx/accessory/mirror/xxxx.v3def
(ebenso s_mirror, f_mirror und andere Spiegel-Ordner, deren Name auf "mirror"
endet; Zubehoer-Typ accessory_addon_data)

  Drehbare Spiegelglaeser: Beim Verstellen der Spiegel im Spiel ("Spiegel
  einstellen") dreht sich das Glas mit, um genau den Winkel, um den das Spiel
  das Spiegelbild dreht. Dazu bekommt der Spiegel Ersatzmodelle ohne Glas mit
  Locatoren, und jedes Glas ist ein eigenes Modell an seinem Locator. Dazu ein
  Verstell-Ton (Motor oder von Hand).

    interior_model_override: "/vehicle/truck/upgrade/mirror/your_truck/mirror_01_interior_mg.pmd"
    interior_model_override_uk: "/vehicle/truck/upgrade/mirror/your_truck/mirror_01_interior_uk_mg.pmd"
    exterior_model_override: "/vehicle/truck/upgrade/mirror/your_truck/mirror_01_mg.pmd"
    exterior_model_override_uk: "/vehicle/truck/upgrade/mirror/your_truck/mirror_01_uk_mg.pmd"
    mirror_glass[]: d "/vehicle/truck/upgrade/mirror/your_truck/glass_d.pmd"
    mirror_glass[]: ds "/vehicle/truck/upgrade/mirror/your_truck/glass_ds.pmd"
    mirror_glass_ext[]: d "/vehicle/truck/upgrade/mirror/your_truck/glass_d_ext.pmd"
    mirror_glass_ext[]: ds "/vehicle/truck/upgrade/mirror/your_truck/glass_ds_ext.pmd"
    mirror_adjust: electric

  Kuerzel der Spiegel (wie die Kamera-Locatoren des Spiels im Spiegelmodell):

    d    Fahrerseite (cam_d)                  p    Beifahrerseite (cam_p)
    ds   Fahrerseite Weitwinkel (cam_ds)      ps   Beifahrerseite Weitwinkel (cam_ps)
    s    Rampen-/Seitenspiegel (cam_s)        f    Frontspiegel (cam_f)
    h    Hauben-/Kotfluegelspiegel (cam_h)

  Fahrer- und Beifahrerseite gelten auch fuer Rechtslenker (UK-Modelle).

  Modelle:
  - Ersatzmodelle (innen und aussen): das bisherige Spiegelmodell ohne die
    Glaeser, dafuer mit Locatoren mglass_d, mglass_ds, mglass_p, mglass_ps,
    mglass_s, mglass_f, mglass_h (nur die vorhandenen). Innen- und
    Aussenmodell haben dieselben Locator-Namen. Die Locatoren bekommen keinen
    Hookup.
  - Locator = Drehpunkt des Glases, Drehung 0. Bei modernen Spiegeln der
    Stellmotor bzw. Kugelkopf hinter dem Glas, bei Spiegeln, deren ganzer
    Kopf am Arm schwenkt, das Gelenk am Arm.
  - Glasmodell (.pmd): Ursprung im Drehpunkt, das Glas so, wie es im
    Spiegelmodell sitzt (nur verschoben, nicht gedreht). Diese Stellung ist
    die Neutralstellung ("Zuruecksetzen" im Spiel). Innen und aussen
    eigene Glasmodelle (unterschiedliche Materialien).
  - Gedreht wird um den Winkel der Spiel-Einstellung (seitlich bis 10 Grad,
    hoch/runter bis 7,5 Grad), in den Achsen der Kamera-Locatoren. Wie weit
    sich das Glas dabei bewegt, ergibt sich aus dem Abstand zum Drehpunkt.
  - Aussen wird an jedem Fahrzeug mit diesem Spiegel gezeichnet; verstellt
    ist nur der eigene Lkw, alle anderen stehen neutral.

  >>> interior_model_override: "<Pfad>.pmd"
      Innenmodell ohne Glaeser, statt interior_model aus der Zubehoer-.sii

  >>> interior_model_override_uk: "<Pfad>.pmd"
      wie interior_model_override fuer interior_model_uk (Rechtslenker)

  >>> exterior_model_override: "<Pfad>.pmd"
      Aussenmodell ohne Glaeser, statt exterior_model aus der Zubehoer-.sii
      (nur bei Spiegeln)

  >>> exterior_model_override_uk: "<Pfad>.pmd"
      wie exterior_model_override fuer exterior_model_uk (Rechtslenker)

  >>> mirror_glass[]: <Kuerzel> "<Pfad>.pmd"
      Glas im Innenmodell am Locator mglass_<Kuerzel>, eine Zeile je Glas
      (braucht interior_model_override)

  >>> mirror_glass_ext[]: <Kuerzel> "<Pfad>.pmd"
      Glas im Aussenmodell am Locator mglass_<Kuerzel>, eine Zeile je Glas
      (braucht exterior_model_override)

  >>> mirror_adjust: electric | manual
      Ton beim Verstellen: electric = Stellmotor (Anlauf, Motor solange
      sich das Glas bewegt, angestrengter Motor am Anschlag bei gehaltener
      Taste, Auslauf), manual = kurzes Knarzen je Schritt. Die Toene bringt
      die Mod mit (/sound/lphd/mirror.bank). Gilt fuer die Spiegel mit
      mirror_glass[]- bzw. mirror_glass_ext[]-Zeilen, sonst nach dem Ordner
      (mirror = d, ds, p, ps; s_mirror = s; f_mirror = f; andere = f, h).
      Standard: kein Ton

  >>> mirror_axes: horizontal | vertical | both
      in welcher Richtung sich die Spiegel dieses Zubehoers im Spiel
      verstellen lassen: horizontal = nur links/rechts, vertical = nur
      hoch/runter, both = beides. Die Pfeile der anderen Richtung sind im
      Einstellfenster ausgeblendet.
      Standard: both

  >>> mirror_glass_axes[]: <Kuerzel> locator | camera
      Drehachsen eines Glases, eine Zeile je Glas: camera = Achsen der
      Spiegelkamera cam_<Kuerzel> (wie das Spiegelbild), locator = Achsen
      des Locators mglass_<Kuerzel>. Fuer Spiegel, deren Kopf schraeg am Arm
      sitzt, die Kamera aber gerade steht: den Locator im Modell so kippen,
      dass seine Y-Achse der Neigung des Arms folgt (X zur Seite, Z nach
      hinten wie im Modell). Links/rechts dreht das Glas dann um diese
      Y-Achse, hoch/runter um die mitgekippte Querachse. Das Glasmodell
      bleibt dabei wie im Spiegelmodell (der Locator dreht es nicht mit).

        mirror_glass_axes[]: ds locator

      Standard: camera
      wie mirror_glass[] fuer das Innenmodell der Rechtslenker
      (braucht interior_model_override_uk)

  >>> mirror_glass_ext_uk[]: <Kuerzel> "<Pfad>.pmd"
      wie mirror_glass_ext[] fuer das Aussenmodell der Rechtslenker
      (braucht exterior_model_override_uk)

  >>> mirror_rain[]: <Kuerzel> "<Pfad>.mat"
      Regentropfen auf dem Spiegelglas (Option "Regentropfen auf den
      Spiegeln"): Material des Glases im Spiegelmodell bzw. im Glasmodell aus
      mirror_glass[]. Jedes Glas braucht ein eigenes Material; alle Flaechen mit
      diesem Material bekommen Tropfen wie die Frontscheibe, ein drehbares Glas
      nimmt sie mit.

        mirror_rain[]: d "/vehicle/truck/upgrade/mirror/your_truck/glass_d.mat"

  >>> mirror_rain_uk[]: <Kuerzel> "<Pfad>.mat"
      wie mirror_rain[] fuer die Rechtslenker-Modelle

  >>> mirror_rain_size: <Faktor>
      Groesse der Tropfen auf allen Glaesern dieses Zubehoers im Verhaeltnis
      zur Frontscheibe (z. B. 0.5 = halb so gross)
      Standard: 1

ZUBEHOER INNENRAUM
------------------
/def/vehicle/truck/xxxx/interior/xxxx.v3def (Innenraum-Zubehoer,
accessory_interior_data)

  Schlafen: Mit "Ausruhen" ab 1 Stunde steht der Fahrer auf, geht zwischen den
  Sitzen zum Bett und legt sich hin (Innenkamera), nach dem Schlaf denselben
  Weg zurueck. Ohne Bett (oder unter 1 Stunde) ruht er im Sitz.

  >>> sleeper: true | false
      true = dieses Innenraum-Zubehoer hat ein Bett
      Standard: false

  >>> bed_area: "<Locator a>" "<Locator b>"
      zwei Locatoren im Innenmodell an zwei gegenueberliegenden Ecken der
      Liegeflaeche; oder direkt die Ecken als Koordinaten des Innenmodells, so
      wie ZModeler sie anzeigt:

        bed_area: "bed_a" "bed_b"
        bed_area: 0.55;0.92;-0.61 : -0.55;0.92;-1.30

      Ohne bed_area gibt es trotz sleeper: true keinen Schlaf-Ablauf.

  >>> bed_head: a | b
      Kopfende am Ende der Ecke a bzw. b
      Standard: zufaellig

  >>> windshield_material[]: "<Material>"
      Material der Frontscheibe im Innenmodell (oder ihres Ersatzes), eine
      Zeile je Material. Die Flaechen dieser Materialien geben die Woelbung der
      Frontscheibe fuer Dreck und Tropfen auf der Scheibe.
      Standard: kein Eintrag = Scheibe flach

WASCHDUESEN
-----------
/def/vehicle/truck/xxxx/cabin/xxxx.v3def (Kabinen-Zubehoer; gelesen wird jedes
Zubehoer des Lkw, das die Zeilen hat)

  Die Scheibenwaschanlage spritzt dort auf die Frontscheibe, wo die Duesen
  hinzielen. Koordinaten sind die des Kabinenmodells, so wie ZModeler sie
  anzeigt; die Mod rechnet sie ueber den Locator "interior" des Kabinenmodells
  in den Innenraum um (ohne diesen Locator gelten sie als Koordinaten des
  Innenmodells).

  >>> washer: fixed | wiper
      fixed = feste Duesen (Motorhaube/Windlauf), wiper = Duesen im Wischblatt
      (Strahl dreht mit dem Arm)
      Standard: fixed

  >>> washer_jets: single | double
      single = ein Strahl je Duese, double = zwei Strahlen je Duese in V-Form
      Standard: single

  >>> washer_jets_angle: <Grad 5 - 170>
      Oeffnung des V bei washer_jets: double
      Standard: zwei Auftreffstellen je 15 cm links/rechts

  >>> washer_spot[]: x;y;z
      Auftreffpunkt einer festen Duese auf der Scheibe, eine Zeile je Duese
      Standard: je Wischer ein Fleck von etwa 15 cm ueber dem ruhenden Blatt

  >>> washer[n]: x;y;z
      Lage der festen Duese n (n = 0, 1, 2 ...)

  >>> washer_spot[n]: x;y;z
      Auftreffpunkt der Duese n (braucht washer[n])

BODY
----
/def/vehicle/trailer_owned/xxxx/body/xxxx.v3def

  >>> floor: wood | metal | film
      wood, metal oder film = Ladeboden
      Standard: wood

  >>> floor[]: "wood|x1|x2"
      "metal|x1|x2" = Streifen mit anderem Boden
      (siehe README_lashing_data)

FIRMENAUFLIEGER FAHRERTOUR
--------------------------
/def/vehicle/trailer/xxxx.v3def (neben der .sui)

  >>> equivalency: <Token>
      gleicher Token = derselbe Auflieger in anderer Laenge

      Auflieger aus /def/vehicle/trailer (die Auflieger der Fahrertouren und
      Schnellauftraege), die es in zwei Laengen gibt (eingefahren / ausgezogen),
      bekommen eine .v3def neben ihrer .sui, gleicher Name:

        /def/vehicle/trailer/scs_lowloader_2ax.sui
        -> /def/vehicle/trailer/scs_lowloader_2ax.v3def
        /def/vehicle/trailer/scs_lowloader_2ax_ext.sui
        -> /def/vehicle/trailer/scs_lowloader_2ax_ext.v3def

        equivalency: lowldr_2ax  gleicher Token = derselbe Auflieger in anderer Laenge

      Nur Auflieger mit so einer Datei und einem Partner mit gleichem Token koennen
      umgestellt werden; alle anderen Auflieger brauchen keine Datei. Auf einer
      Fahrertour mit leerem Auflieger und stehendem Lkw stellt die Aktion
      "Auflieger anpassen" des Spiels auf die andere Laenge um (Chassis, Aufbau und Aufliegerdefinition der
      Partner-.sui). Fracht fuer beide Laengen kann angeboten werden; bei der
      Ladefirma wird die Fracht nur mit der richtigen Laenge geladen, das HUD
      fordert dazu auf, den Auflieger auszuziehen oder einzufahren (auch waehrend
      der Wartezeit moeglich). lphd_tieflader_v3def.zip enthaelt die Dateien fuer
      die SCS-Tieflader.


Fehler
------
Eine Zeile, die da ist, aber nicht gelesen werden kann (z. B.
"gross_vehicle_weight: 18 t", "emission: six", "emission: 9", "type: semi",
"suspension: steel", "registration: dolly", "italy_card_shift_rear: 1,5 cm",
"serbia_card_depth_rear: 2 cm", "italy_card_tilt_rear: 60",
"plate_rotate_rear: 50"), steht als Fehler im game.log

  <ERROR> [fleet_road_realism] /def/.../your_chassis.v3def: invalid value for
          gross_vehicle_weight (expected e.g. "gross_vehicle_weight: 18.00"),
          using default 18 t

und in der fleet_road_realism.log. Fuer diese Zeile gilt der Standardwert.


Wofuer die Werte verwendet werden
---------------------------------
  Deutschland (eigene Zulassung)  Kfz-Steuer nach Schadstoffklasse

  Oesterreich (eigene Zulassung)  Kfz-Steuer je angefangene Tonne und Monat:
                                  bis 12 t 1,55 EUR (mind. 15), 12-18 t 1,70 EUR,
                                  ueber 18 t 1,90 EUR; max. 80 EUR Lkw, 66 EUR
                                  Auflieger; Auflieger-Gewicht =
                                  gross_vehicle_weight - king_pin_load

  Schweiz (eigene Zulassung)      kantonale Motorfahrzeugsteuer, Tarif des
                                  Kantons auf dem Kennzeichen, je Kalenderjahr im
                                  Voraus (im Jahr der Zulassung anteilig, Rest
                                  zurueck bei Verkauf, Abmeldung oder Wechsel in
                                  einen anderen Kanton). Je nach Kanton nach
                                  Gesamtgewicht, Nutzlast (Gesamtgewicht -
                                  Leergewicht), Zuggesamtgewicht
                                  (Sattelzugmaschinen), Hubraum oder Leistung;
                                  manche Kantone nutzen die Euro-Klasse oder
                                  senken die Steuer fuer Elektro-Lkw. Die Nummer
                                  bleibt nach einem Verkauf ein Jahr fuer die
                                  Firma reserviert.

  Schweiz (alle Lkw)              LSVA = km in der Schweiz x Gewicht x Tarif
                                  Gewicht = Lkw + angekuppelter Auflieger -
                                  king_pin_load, max. 40 t; Tarif nach Emission
                                  (Rappen je tkm): Euro 0-3 3,26, Euro 4-5 2,82,
                                  Euro 6-7 2,39; Elektro-Lkw (Motor
                                  "type: electric") sind befreit

  Frankreich (eigene Zulassung)   TSVR (Schwerverkehrsabgabe), nachtraeglich je
                                  Kalenderjahr aus einem Fahrtenbuch (Tag fuer
                                  Tag): Solo-Lkw ab 12 t nach Achsen und
                                  Gesamtgewicht, Sattelzugmaschinen nach
                                  Zuggesamtgewicht und den Achsen des an dem Tag
                                  gezogenen Aufliegers (ohne Auflieger: nichts);
                                  Luft- / andere Federung

  Italien (eigene Zulassung)      IPT bei der Zulassung: Sattelzugmaschinen nach
                                  Leistung (kW), Solo-Lkw und Auflieger nach
                                  Nutzlast (Gesamtgewicht - Leergewicht); Bollo je
                                  Jahr: Solo-Lkw nach Achsen, Gesamtgewicht und
                                  Federung, Sattelzugmaschinen nach Region und
                                  Achsen (2 / 3 und mehr)

  Polen (eigene Zulassung)        Steuer auf Verkehrsmittel (zwei Raten im Jahr):
                                  Solo-Lkw nach Achsen und Gesamtgewicht,
                                  Sattelzugmaschinen nach Achsen und
                                  Zuggesamtgewicht, Auflieger nach Achsen; Luft- /
                                  andere Federung; Saetze der Gemeinde (sonst
                                  Mindestsaetze)

  Tschechien (eigene Zulassung)   Strassensteuer fuer Lkw ab 12 t, nachtraeglich
                                  je Kalenderjahr (1/12 je angefangenem Monat):
                                  Solo-Lkw nach Achsen und Gesamtgewicht,
                                  Sattelzugmaschinen nach Achsen und
                                  Zuggesamtgewicht (Auflieger sind ueber die
                                  Zugmaschine abgedeckt); Luft- / andere Federung

  Slowakei (eigene Zulassung)     Kraftfahrzeugsteuer, nachtraeglich je
                                  Kalenderjahr (1/12 je Monat, Erklaerung bis
                                  31. Januar, Vorauszahlungen vierteljaehrlich
                                  ueber 700 EUR / monatlich ueber 8.300 EUR Steuer
                                  des Vorjahres): Solo-Lkw nach Achsen und
                                  Gesamtgewicht, Sattelzugmaschinen nach Achsen
                                  und Zuggesamtgewicht, Luft- / andere Federung;
                                  Auflieger (O4) pauschal 150 EUR; Lkw zahlen
                                  einen Alterszuschlag (+10 % nach 3 Jahren, alle
                                  3 Jahre steigend, +50 % ab dem 181. Monat),
                                  gezaehlt ab der ersten Zulassung im Spiel

  Ungarn (eigene Zulassung)       Kraftfahrzeugsteuer je angefangene 100 kg,
                                  zahlbar bis 15. April fuer die Monate bis
                                  Jahresende (vom Monat nach der Zulassung bis zum
                                  Monat der Abmeldung): Solo-Lkw und Auflieger
                                  Leergewicht + 50 % der Nutzlast,
                                  Sattelzugmaschinen 2 x Leergewicht + 1/2 x
                                  (Zuggesamtgewicht - 2 x Leergewicht); Luft- /
                                  andere Federung; Ermaessigung fuer Euro III
                                  (-20 %, Sattelzugmaschinen -30 %) und Euro IV-V
                                  (-30 % / -50 %), keine fuer Euro I-II und
                                  Euro VI; Elektro-Lkw (Klasse 5E, emission-
                                  Eintrag wird ignoriert) -20 % / -30 %.
                                  Erwerbsabgabe bei der ersten Zulassung in
                                  Ungarn: Lkw je kW nach Leistung und Alter (ab
                                  der ersten Zulassung im Spiel), Auflieger
                                  pauschal 24.000 Ft

  Griechenland (eigene Zulassung) Strassensteuer je Kalenderjahr im Voraus (ganzes
                                  Jahr mit der Zulassung, dann am 1. November fuer
                                  das Folgejahr): Solo-Lkw nach Gesamtgewicht
                                  (bis 10 t 300 EUR, 20 t 600, 30 t 940, 40 t
                                  1.320, darueber 1.490), Sattelzugmaschinen
                                  300 EUR, Auflieger frei. Gebrauchte Lkw unter
                                  Euro V (emission 0-4) koennen in Griechenland
                                  nicht zugelassen werden; Elektro-Lkw sind von
                                  dieser Regel ausgenommen.

  Rumaenien (eigene Zulassung)    Steuer auf Verkehrsmittel je Kalenderjahr:
                                  Solo-Lkw nach Achsen und Gesamtgewicht,
                                  Sattelzugmaschinen nach ihren Achsen + den
                                  Achsen des bei der Zulassung gewaehlten
                                  Sattelaufliegers (keiner angekuppelt: 3) und
                                  Zuggesamtgewicht; Luft- / andere Federung. Die
                                  Zugmaschine zahlt fuer den Zug, der
                                  Sattelauflieger zahlt nichts. Elektro-Lkw nach
                                  derselben Tabelle. Der Halter am 31. Dezember
                                  zahlt fuer das naechste Jahr: im Laufe des
                                  Jahres zugelassen -> ab 1. Januar des
                                  Folgejahres; ganzes Jahr am 31. Maerz mit Bonus
                                  (10 %, Bacau 5 %); Zuschlag der Stadt der
                                  Garage (Brasov +35 %, Craiova +13 %,
                                  Timisoara +50 %); keine Erstattung bei Verkauf/
                                  Abmeldung

  Bulgarien (eigene Zulassung)    Kfz-Steuer je Jahr: Solo-Lkw nach Achsen und
                                  Gesamtgewicht, Sattelzugmaschinen nach Achsen
                                  und Zuggesamtgewicht; Luft- / andere Federung;
                                  Vielfaches des Mindestsatzes, das die Stadt der
                                  Garage festlegt (sonst nach dem Kennzeichen-
                                  Code): Sofia 1,25, Plovdiv 1,43, Varna 2,25,
                                  Burgas 1,5, Veliko Tarnovo 1,3, Stara Zagora
                                  1,5, sonst 1,0; Euro 4 -20 %, Euro 5-6 -50 %
                                  (nicht in Stara Zagora, Elektro-Lkw voller
                                  Satz); Auflieger keine eigene Steuer. Ganzes
                                  Jahr bis 30. April mit 5 % Rabatt; im Jahr der
                                  Zulassung 1/12 je Monat ab dem Monat der
                                  Zulassung (faellig in zwei Monaten); Verkauf
                                  oder Abmeldung: Steuer bis Monatsende, zu viel
                                  gezahlte Steuer wird erstattet

  Slowenien (eigene Zulassung)    jaehrliche Fahrzeugabgabe = Tage x Tagessatz,
                                  ein Jahr im Voraus mit der Zulassung, dann
                                  jaehrlich: Solo-Lkw je angefangene Tonne
                                  Gesamtgewicht, Sattelzugmaschinen je kW bis
                                  190 kW (darueber ein fester Tagessatz), eigene
                                  Saetze bis / ueber 20 t Gesamtgewicht;
                                  Anhaenger je Tonne Gesamtgewicht,
                                  Sattelauflieger frei. Euro VI -35 %, V -25 %,
                                  IV 0, III +10 %, II +20 %, I +30 %, 0 +40 %;
                                  Elektro-Lkw -90 %; Luftfederung (nur Solo-Lkw)
                                  weitere -15 %. Mindestens 5 EUR; Rest bei
                                  Verkauf/Abmeldung erstattet (Betraege bis 5 EUR
                                  nicht)

  Kroatien (eigene Zulassung)     Strassengebuehr 40 EUR x Koeffizient, ein Jahr im
                                  Voraus mit der Zulassung: Lkw nach Gesamtgewicht
                                  und Achsen, Anhaenger nach Gesamtgewicht und
                                  Achsen, Sattelauflieger nach der Summe der
                                  Achslasten (gross_vehicle_weight -
                                  king_pin_load). Umweltgebuehr (nur Lkw):
                                  60,52 EUR x Hubraumfaktor x Altersfaktor (Alter
                                  ab der ersten Zulassung im Spiel); Elektro-Lkw
                                  0. Keine Erstattung bei Verkauf/Abmeldung

  Serbien (eigene Zulassung)      Gemeindegebuehr je Jahr (faellig bei der
                                  Zulassung, dann jaehrlich, Hoechstsaetze fuer
                                  alle Gebiete): Solo-Lkw und Anhaenger nach
                                  Nutzlast (Gesamtgewicht - Leergewicht),
                                  Sattelzugmaschinen nach Leistung (kW); keine
                                  Erstattung bei Verkauf/Abmeldung

  Montenegro (eigene Zulassung)   Strassengebuehr fuer 12 Monate im Voraus mit der
                                  Zulassung, dann mit jeder Verlaengerung
                                  (kuerzere Zulassung anteilig nach Monaten);
                                  keine Erstattung, ein neuer Halter zahlt bis zum
                                  Ablauf nichts. Bis 30. Juni 2027: Solo-Lkw und
                                  Anhaenger nach Nutzlast (Gesamtgewicht -
                                  Leergewicht), Sattelzugmaschinen nach Leistung
                                  (kW); ab 1. Juli 2027: 5 EUR x Koeffizient nach
                                  Gesamtgewicht und Achsen (eigene Tabellen fuer
                                  Anhaenger und Sattelauflieger).
                                  Kurzzeit-Haftpflichtversicherung: Solo-Lkw und
                                  Anhaenger nach Nutzlast, Sattelzugmaschinen
                                  nach Leistung (kW)

  Nordmazedonien                  Strassengebuehr fuer 12 Monate mit der Zulassung
  (eigene Zulassung)              (kuerzere Zulassung anteilig, 30 Tage =
                                  1 Monat), keine Erstattung: Sattelzugmaschinen
                                  nach Leistung (kW), Solo-Lkw und Anhaenger nach
                                  Nutzlast (Gesamtgewicht - Leergewicht),
                                  Sattelauflieger pauschal 5.200 MKD

  Bosnien und Herzegowina         jaehrliche Abgaben fuer 12 Monate im Voraus mit
  (eigene Zulassung)              der Zulassung, nach der Entitaet des Bezirks.
                                  Foederation: Strassengebuehr 30 KM x
                                  Koeffizient, Lkw und Sattelzugmaschinen nach
                                  Gesamtgewicht und Achsen, Sattelauflieger nach
                                  der Summe der Achslasten (gross_vehicle_weight
                                  - king_pin_load), Anhaenger nach
                                  Gesamtgewicht; Umweltgebuehr (nur Lkw) nach
                                  Kraftstoff (Elektro x 0,2), Hubraum und Alter
                                  (ab der ersten Zulassung im Spiel);
                                  Wassergebuehr 0,30 KM je kW (nicht Elektro-Lkw);
                                  Strassengebuehr ab dem Tag der Abmeldung
                                  erstattet.
                                  Republika Srpska: Strassenmaut nach
                                  Gesamtgewicht, Sattelzugmaschinen pauschal
                                  120 KM; keine Erstattung

  Albanien (eigene Zulassung)     TVMP (nur Lkw): Hubraum x Alterskoeffizient
                                  x 12,5 ALL; in den ersten 3 Jahren frei, 0,20 im
                                  4. Jahr, +0,02 je Jahr bis 0,60 (Alter ab der
                                  ersten Zulassung im Spiel); Elektro-Lkw und
                                  Anhaenger zahlen nichts. Gueltig 365 Tage ab
                                  Zahlung, keine Erstattung; nach einer
                                  voruebergehenden Abmeldung anteilig je Monat bis
                                  31. Dezember

  Tuerkei (eigene Zulassung)      MTV (nur Lkw, Anhaenger frei) nach
                                  Gesamtgewicht des Lkw (nicht des Zuges) und
                                  Alter (1-6, 7-15, 16+ Jahre, gezaehlt ab dem
                                  Jahr der ersten Zulassung im Spiel); zwei
                                  gleiche Raten im Januar und Juli, mit der
                                  Zulassung die Rate des laufenden Halbjahres;
                                  nach Verkauf/Abmeldung keine weiteren Raten

  Russland (eigene Zulassung)     Transportsteuer (nur Lkw, Anhaenger frei):
                                  PS (kW x 1,35962) x Satz der Region auf dem
                                  Kennzeichen (in manchen Regionen nach Alter ab
                                  der ersten Zulassung im Spiel) x Monate / 12;
                                  nachtraeglich je Quartal (28. April, 28. Juli,
                                  28. Oktober, 1. Maerz); ein Monat zaehlt, wenn
                                  bis zum 15. zugelassen / nach dem 15.
                                  abgemeldet; keine Erstattung, offene Monate nach
                                  der Abmeldung werden zum naechsten Termin
                                  berechnet

  Litauen (eigene Zulassung)      Jahresgebuehr ab 12 t Gesamtgewicht (Lkw und
                                  Anhaenger), je Tonne Gesamtgewicht
                                  (Sattelauflieger: gross_vehicle_weight -
                                  king_pin_load), Luft- / andere Federung;
                                  12 Monate mit der Zulassung, dann jaehrlich;
                                  keine Erstattung

  Lettland (eigene Zulassung)     Fahrzeugbetriebssteuer je Kalenderjahr: Lkw bis
                                  12 t nach Euro-Klasse, ueber 12 t nach Achsen
                                  und Euro-Klasse (eigene Tabelle fuer
                                  Sattelzugmaschinen); Elektro-Lkw frei. Anhaenger
                                  ueber 3,5 t: eine Achse 66 EUR, sonst nach
                                  Achsen, Federung des Zugfahrzeugs und Gewicht
                                  (Sattelauflieger: Leergewicht der Zugmaschine +
                                  Gesamtgewicht des Sattelaufliegers; Anhaenger:
                                  Gesamtgewicht Lkw + Anhaenger); das
                                  Zugfahrzeug wird bei der Zulassung gewaehlt
                                  (Standard: Zugmaschine 2 Achsen, 7,7 t leer,
                                  Luftfederung / Solo-Lkw 3 Achsen, 26 t). Mit
                                  der Zulassung die restlichen Monate
                                  einschliesslich des laufenden, dann jeden
                                  Januar; Abmeldung: volle Restmonate erstattet

  Estland (eigene Zulassung)      Schwerverkehrssteuer je Quartal: Solo-Lkw ab
                                  12 t nach Achsen, Gesamtgewicht und Federung
                                  (Luft / andere); Sattelzugmaschinen als Zug:
                                  eigene Achsen + Achsen des bei der Zulassung
                                  gewaehlten Sattelaufliegers (Standard 3), nach
                                  Zuggesamtgewicht; Anhaenger frei. Mit der
                                  Zulassung die vollen restlichen Monate des
                                  Quartals (ohne den Zulassungsmonat), dann das
                                  ganze Quartal am 1. Januar / April / Juli /
                                  Oktober; keine Erstattung, nach der Abmeldung
                                  ab dem naechsten Quartal nichts mehr

  Kosovo (eigene Zulassung)       Strassensteuer 90 EUR + Umweltsteuer 30 EUR fuer
                                  365 Tage mit der Zulassung (Lkw und Anhaenger,
                                  pauschal, ohne Fahrzeugwerte); Verlaengerung
                                  170 EUR (inkl. 50 EUR Verwaltung); keine
                                  Erstattung


EN
==

Taxes and road charges of the own registration (vehicle tax in Germany, Austria,
Switzerland, France, Italy, Poland, Czechia, Slovakia, Hungary, Greece, Romania,
Bulgaria, Slovenia, Croatia, Serbia, Montenegro, North Macedonia, Bosnia and
Herzegovina, Albania, Turkey, Russia, Lithuania, Latvia, Estonia and Kosovo,
Swiss LSVA) need
data about a vehicle. Most of it is read from the vehicle's own .sii files:

  engine .sii    power (info[] "... (270@@kw@@)", otherwise from torque and
                 torque_curve[]), displacement (volume), electric (type: electric)
  chassis .sii   number of axles (residual_travel[]), empty weight
                 (truck: sum of kerb_weight[], trailer: trailer_mass)
  body .sii      mass (added to trailer_mass)

What the game files do not contain (Euro class, permissible weights, tractor or
rigid truck, kind of suspension) comes from small optional files that a truck or
trailer mod can ship next to its own definitions. The same files also set the
position of plates and signs, doubles (registration, splitting when loading,
cables, coupling sounds, coupling guide, support legs), animated accessories,
the deck and the trailer lengths of driver tours.

All files are optional. A missing file or a missing line is not an error, the
default value given for each entry under "Keys" is used.

Where the files go
------------------
Same folder and same name as the .sii the vehicle uses, only with .v3def:

  engine         /def/vehicle/truck/your_truck/engine/your_engine.sii
              -> /def/vehicle/truck/your_truck/engine/your_engine.v3def

  engine sound   (for sound mods, cold start knock only, see "ENGINE SOUND")
                 next to the sound .sui the engine .sii pulls in via @include:
                 /def/vehicle/truck/your_truck/engine/sound.sui
              -> /def/vehicle/truck/your_truck/engine/sound.v3def
                 and/or next to the .soundref from sounds[] "engine|...":
                 /def/vehicle/truck/your_truck/engine/sound_engine.soundref
              -> /def/vehicle/truck/your_truck/engine/sound_engine.v3def

  truck chassis  /def/vehicle/truck/your_truck/chassis/your_chassis.sii
              -> /def/vehicle/truck/your_truck/chassis/your_chassis.v3def

  trailer        /def/vehicle/trailer_owned/your_trailer/chassis/your_chassis.sii
              -> /def/vehicle/trailer_owned/your_trailer/chassis/your_chassis.v3def

  company trailer (job trailer, no chassis/ folder: the chassis is the .sii
  whose name starts with "chassis")
                 /def/vehicle/trailer/your_company_trailer/chassis_hook.sii
              -> /def/vehicle/trailer/your_company_trailer/chassis_hook.v3def

  accessory      /def/vehicle/trailer_owned/your_trailer/accessory/r_bumper/your_bumper.sii
              -> /def/vehicle/trailer_owned/your_trailer/accessory/r_bumper/your_bumper.v3def
                 (rear bumpers, see "ACCESSORY REAR BUMPER" under "Keys")

  mirror         /def/vehicle/truck/your_truck/accessory/mirror/your_mirror.sii
              -> /def/vehicle/truck/your_truck/accessory/mirror/your_mirror.v3def
                 (also s_mirror, f_mirror etc., see "ACCESSORY MIRROR" under "Keys")

  interior       /def/vehicle/truck/your_truck/interior/your_interior.sii
              -> /def/vehicle/truck/your_truck/interior/your_interior.v3def
                 (sleeping, windshield curvature, see "ACCESSORY INTERIOR")

  cabin          /def/vehicle/truck/your_truck/cabin/your_cabin.sii
              -> /def/vehicle/truck/your_truck/cabin/your_cabin.v3def
                 (washer nozzles, see "WASHER NOZZLES")

The examples in the def/ folder of this package show the format.


Format
------
  key: value

  - one entry per line, spaces or tabs around the colon are allowed
  - lines starting with # or // are comments, a # after the value too
  - weights: tonnes (values up to 100, e.g. 18.00) or kilograms (above 100,
    e.g. 18000)
  - decimal point or decimal comma (18.50 or 18,50), no thousands separator
  - emission: whole number 0-7
  - type: tractor, rigid or swapbody (truck); semitrailer, dolly, drawbar,
    centeraxle or swapbody (trailer)
  - suspension: air or leaf
  - registration: own, next, prev or none
  - loading: own, next or prev
  - load_split: true or false
  - cable_connect: metres above 0 up to 20 (e.g. 1.2)
  - fixed_plate: game token of the country, e.g. germany, optionally |code
  - cylinders: whole number 1-16
  - knock_strength: number 0-3 (e.g. 0.5)
  - knock_tone: number 0.4-2 (e.g. 0.7)
  - mirror_axes: horizontal, vertical or both
  - mirror_rain_size: number above 0 up to 20 (e.g. 0.5)
  - sleeper: true or false
  - bed_head: a or b
  - washer: fixed or wiper
  - washer_jets: single or double
  - washer_jets_angle: degrees 5-170
  - coordinates (bed_area, washer_spot[], washer[n]): x;y;z as ZModeler shows
    them
  - italy_/serbia_card_shift_front / _rear: millimetres, positive = up,
    negative = down, -200 to 200 (e.g. 15 or -7.5)
  - italy_/serbia_card_depth_front / _rear: millimetres, positive = away from
    the vehicle, negative = towards the vehicle, -200 to 200
  - italy_/serbia_card_tilt_rear: degrees, positive = top edge towards the
    vehicle, negative = top edge away from the vehicle, -45 to 45 (e.g. 12.5)
  - greece_export_shift_front / _rear: millimetres, positive = up, negative =
    down, -200 to 200
  - greece_export_depth_front / _rear: millimetres, positive = away from the
    vehicle, negative = towards the vehicle, -200 to 200
  - greece_export_rotate_front / _rear: degrees, positive = top edge towards the
    vehicle, negative = top edge away from the vehicle, -45 to 45
  - plate_depth_front / _rear: millimetres, positive = away from the vehicle,
    negative = towards the vehicle, -200 to 200
  - plate_rotate_front / _rear: degrees, positive = top edge towards the
    vehicle, negative = top edge away from the vehicle, -45 to 45
  - nothing else on the line (no units like "t" or "kg")

Keys
====
Every entry starts with >>> and shows the line as it goes into the v3def
(<...> = your value, | = one of them). Everything below it is description.

ENGINE
------
/def/vehicle/truck/xxxx/engine/xxxx.v3def

  >>> emission: 0 - 7
      Euro class 0-7
      Default:  Euro 6

  COLD START KNOCK
  A cold diesel knocks: the mod adds a short metallic knock per ignition to
  the engine sound of the own truck, plus slightly uneven running and a
  harsher sound. How cold the engine is comes from the oil temperature exactly
  as the game computes it for cold_start_rpm (full up to about 19 deg C, gone
  from 90 deg C). Strongest at idle and when pulling away under load at low
  rpm, weaker with rising rpm. Electric engines do not knock.
  The engine sound comes from sounds[] "engine|..." of the engine .sii (also
  through @include), directly as "<bank>#<event>" or through a .soundref.
  Only this event gets the knock, not exhaust, turbo etc. Nothing has to be
  entered for it; the three lines below are only fine tuning.

  >>> cylinders: <1 - 16>
      number of cylinders; sets the rate of the knocks
      (rpm / 60 x cylinders / 2 per second)
      Default:  6

  >>> knock_strength: <0 - 3>
      strength of the knock (and of the uneven running) for this engine,
      1 = normal, 0.5 = half as strong, 2 = double, 0 = off
      Default:  1

  >>> knock_tone: <0.4 - 2>
      pitch of the knock for this engine, so it matches the engine sound;
      lower = deeper and duller (e.g. big V8), higher = brighter and harder
      Default:  1

ENGINE SOUND
------------
/def/vehicle/truck/xxxx/engine/sound.v3def         (next to the sound .sui)
/def/vehicle/truck/xxxx/engine/sound_engine.v3def  (next to the .soundref)

  For sound mods that only replace the sound .sui or only the .soundref:
  the same three lines as for the cold start knock of the engine, matching
  your own sound. The most specific value wins: .soundref .v3def before
  sound .v3def before engine .v3def. A missing line comes from the next
  file.

  >>> cylinders: <1 - 16>
      as for the engine
      Default:  value of the engine .v3def

  >>> knock_strength: <0 - 3>
      as for the engine
      Default:  value of the engine .v3def

  >>> knock_tone: <0.4 - 2>
      as for the engine
      Default:  value of the engine .v3def

TRUCK CHASSIS
-------------
/def/vehicle/truck/xxxx/chassis/xxxx.v3def

  >>> type: tractor | rigid | swapbody
      tractor = tractor unit for semi-trailers
      rigid = rigid truck (load on its own frame)
      swapbody = swap body carrier (chassis for swap bodies); tax and papers
                 as rigid, in the German registration certificate
                 "Wechselfahrgestell"
      Default:  tractor

      Which trailers fit (fixed combinations, freight jobs with a company
      trailer, quick jobs): what counts is the "type" of the front part of the
      trailer (see TRAILER CHASSIS)
        tractor   semitrailer only
        rigid     dolly, drawbar, centeraxle
        swapbody  dolly, drawbar, centeraxle and swapbody
      Jobs that do not fit are only hidden for this truck, the offer stays.

  >>> fixed_plate: "<country>" | "<country>|<code>"
      plates fixed in the model (without the game's plate locator), e.g. for
      packs with real, fixed plates on the vehicle

        fixed_plate: "germany"
        fixed_plate: "germany|HN"

      The vehicle is permanently registered in this country from the purchase:
      no temporary plate, no registration duty. Vehicle tax by the rules of
      this country (weight, axles, Euro class etc. from the other entries, as
      for any vehicle). Insurance is the statutory liability insurance,
      changeable in the insurance menu (F7). The registration service is locked
      for the vehicle: no registration tile in the service shop, no click on
      the plate in the manager.
      <country> = game token of the country (germany, austria, netherlands ...).
      <code> = registration district as shown in the registration window;
      without code the default district of the country. Matters where the tax
      depends on the district (e.g. Poland, Romania, France).
      Vehicles already owned (temporary, deregistered or registered in another
      country) are re-registered to the country once; the old tax ends, no-claims
      class and insurance stay.
      Default:  no entry = normal registration
  >>> gross_combination_weight: <tonnes or kg>
      permissible gross combination weight
      Default:  40 t

  >>> plate_depth_front: <mm>
      front plate forward/back, mm

      Works like the cardboard keys, but for all normal plates of the chassis
      (permanent and temporary plates; the cardboard signs and papers keep their own
      keys). plate_depth_front / plate_depth_rear move the plate forward or back in
      millimetres: positive values away from the vehicle (e.g. out of a recess or a
      bumper), negative values towards the vehicle. plate_rotate_front /
      plate_rotate_rear tilt the plate around its horizontal centre line (seen from
      the side), in degrees: positive values move the top edge towards the vehicle
      and the bottom edge away from it, negative values the other way round. A
      trailer only has the rear plate. Only the vehicles of your company are moved.

        plate_depth_rear: 12        # rear plate 12 mm further out
        plate_rotate_front: -8      # front plate, top edge tilted 8 degrees away
      Default:  0

  >>> plate_rotate_front: <degrees>
      front plate tilt, degrees
      Default:  0

  >>> italy_card_shift_front: <mm>
      Italian cardboard plate (foglio di via) front up/down, mm

      The Italian temporary registration (foglio di via, cardboard 275 x 200 mm) and
      the Serbian test plate (PROBA, cardboard 340 x 180 mm) are cardboard signs that
      are much larger than a plate. Depending on the model they can reach up to a rear
      light, be hidden behind an underrun guard or disappear into the plate recess.
      Italy uses the italy_card_* keys, Serbia the serbia_card_* keys. The
      Montenegrin test plate (PROBA) has the same size as the Serbian one and also
      uses the serbia_card_* keys, so one setting fits both.

      The default height already fits the vehicles of the game:
        truck front   centred on the plate
        truck rear    30 mm lower than the plate
        trailer       10 mm lower than the plate

      ..._card_shift_front / ..._card_shift_rear move the sign up or down from this
      default for one chassis, in millimetres: positive values up, negative values
      down. ..._card_depth_front / ..._card_depth_rear move it forward or back:
      positive values away from the vehicle (out of the plate recess), negative values
      towards the vehicle. ..._card_tilt_rear tilts the rear sign around its
      horizontal centre line (seen from the side), in degrees: positive values move the
      top edge towards the vehicle and the bottom edge away from it (e.g. to follow an
      inclined plate holder), negative values the other way round. A trailer only has the rear sign.

        italy_card_shift_rear: 15      # 15 mm higher than the default
        italy_card_shift_front: -10    # 10 mm lower than the default
        serbia_card_depth_rear: 20     # 20 mm further out of the plate recess
        serbia_card_tilt_rear: 10      # top edge tilted 10 degrees towards the vehicle
      Default:  0

  >>> italy_card_depth_front: <mm>
      Italian cardboard plate front forward/back, mm
      Default:  0

  >>> serbia_card_shift_front: <mm>
      Serbian/Montenegrin cardboard plate (PROBA) front up/down, mm
      Default:  0

  >>> serbia_card_depth_front: <mm>
      PROBA plate front forward/back, mm
      Default:  0

  >>> greece_export_shift_front: <mm>
      Greek export plate front up/down, mm

      The Greek export plate is smaller and higher than a normal plate (370 x 120 mm
      instead of 520 x 110 mm) and is drawn as a plate of its own, centred on the
      normal plate. greece_export_shift_front / _rear move it up or down in
      millimetres (positive up), greece_export_depth_front / _rear forward or back
      (positive away from the vehicle), greece_export_rotate_front / _rear tilt it
      around its horizontal centre line in degrees (positive = top edge towards the
      vehicle). Without an entry all values are 0. A trailer only has the rear plate.

        greece_export_shift_rear: 12     # 12 mm higher
        greece_export_rotate_front: -5   # top edge tilted 5 degrees away
      Default:  0

  >>> greece_export_depth_front: <mm>
      Greek export plate front forward/back, mm
      Default:  0

  >>> greece_export_rotate_front: <degrees>
      Greek export plate front tilt, degrees
      Default:  0

  TILTING FIFTH WHEEL
  The fifth wheel plate can tilt around its bearing. When coupled it follows
  the longitudinal tilt of the trailer relative to the truck, also while
  driving under a trailer front, otherwise it falls back to its rest position.
  A sound plays when it hits the trailer and when it falls back, louder or
  quieter depending on the force. The plate is a model of its own at a locator
  of the chassis model:

    couple_model: "/vehicle/truck/your_truck/fifthwheel.pmd"
    couple_tilt_front: 10
    couple_tilt_rear: 15
    couple_tilt_rest: 5

  - locator couple_0 in the chassis model = bearing of the plate (with several
    fifth wheels couple_1, couple_2 ... with [1], [2] ... on the keys)
  - the plate (.pmd): only the tilting part, origin in the bearing,
    orientation as in the truck. The chassis model itself no longer contains
    the plate (in the coarser LODs it may stay fixed)

  >>> couple_model[n]: "<path>.pmd"
      model of the tilting plate at locator couple_n; without [n] = [0]

  >>> couple_tilt_front[n]: <degrees>
      how far the plate can tilt forward, degrees (0 to 45)
      Default:  rigid (no forward tilt)

  >>> couple_tilt_rear[n]: <degrees>
      how far the plate can tilt backward, degrees (0 to 45)
      Default:  rigid (no backward tilt)

  >>> couple_tilt_rest[n]: <degrees>
      rest position without trailer, degrees (-45 to 45), positive = rear lower
      Default:  from the centre of mass of the plate

  >>> couple_contact_sound[n]: <.soundref or .bank#event, - = no sound>
      sound when the plate hits the trailer
      Default:  sound of the mod (/sound/lphd/fifthwheel.bank#contact)

  >>> couple_rest_sound[n]: <.soundref or .bank#event, - = no sound>
      sound when the plate falls back to its rest position
      Default:  sound of the mod (/sound/lphd/fifthwheel.bank#rest)

TRAILER CHASSIS
---------------
/def/vehicle/trailer_owned/xxxx/chassis/xxxx.v3def
company trailer: /def/vehicle/trailer/xxxx/chassis_xxxx.v3def

  >>> type: semitrailer | dolly | drawbar | centeraxle | swapbody
      kind of this part, as it is in reality
      semitrailer = semi-trailer (rests with king_pin_load on the part in front)
      dolly       = converter dolly (axle unit with drawbar and fifth wheel)
      drawbar     = drawbar trailer or the turntable axle of a full trailer
      centeraxle  = centre-axle trailer
      swapbody    = the swap body itself (trailer with invisible wheels): no
                    registration (as "registration: none"), fits only trucks
                    with "type: swapbody"
      dolly, drawbar and centeraxle have no king pin load (king_pin_load is
      ignored).
      In the papers: semitrailer = semi-trailer, centeraxle = centre-axle
      trailer, drawbar and dolly = trailer.
      For trailers made of several parts every part gets its own type; for
      fixed combinations and jobs only the front part counts (see TRUCK
      CHASSIS, type). Also applies to company trailers.
      Default:  semitrailer

  >>> king_pin_load: <tonnes or kg>
      load on the king pin (semitrailer only)
      Default:  by number of axles: 1 -> 10 t, otherwise 12 t

  >>> registration: own | next | prev | none
      own = own registration
      next = belongs to the part behind it
      prev = belongs to the part in front of it
      none = no registration (e.g. swap body as a trailer with invisible
             wheels; automatic with "type: swapbody")

      "registration: none": the part is not a vehicle as far as registration
      goes, but a body or load:
        - no entry in the registration office, no registration tile in the
          service shop, no click on the plate in the trailer manager
        - no plates (no temporary plate when bought either), no vehicle papers
        - no vehicle tax, no insurance, no fines for registration
      The vehicle the swap body sits on stays registered as usual.

      Owned trailers with more than one chassis (B-double, HCT, semi-trailer on a
      converter dolly, full trailer with turntable) are a chain of parts in the game.
      Without a "registration" line every part is a vehicle of its own: own entry in the
      registration office, own plate, own tax and insurance. That is correct for
      semi-trailers and for converter dollies, which are registered vehicles of
      their own in reality.

      "registration: next" or "registration: prev" joins a chassis with its
      neighbour. Use it only for parts that are not a vehicle of their own in
      reality, e.g. the turntable axle (front part) of a full trailer with
      turntable steering. Joined parts are one vehicle:
        - one entry in the registration office, registered under the plate of the
          rearmost part (the one seen at the rear)
        - tax and insurance once, for the whole vehicle
        - no temporary plate of its own when bought; the joined part keeps the plate
          the game gives it

      "next" and "prev" are relative to the position, so the same chassis works in
      every configuration it is used in. Joins can be chained.

      Values of a joined vehicle
        axles          sum of the parts
        empty weight   sum of the parts
        gross weight   sum of gross_vehicle_weight of all parts
                       minus king_pin_load of every part behind the first one
                       (that load rests on the part in front of it and is already
                       counted there)
        king pin load  the one of the front part (load on the truck)

      Give every part the values it has on its own - nothing has to be split.

      Example 1: full trailer with turntable, 2 axles, 18 t (one vehicle)

        turntable axle (front)   type: drawbar
                                 registration: next
                                 gross_vehicle_weight: 9.00
                                 (drawbar, nothing on the truck)
        rear part                (no type = semitrailer, rests on the
                                 turntable)
                                 gross_vehicle_weight: 18.00
                                 king_pin_load: 9.00

        -> 1 vehicle, 2 axles, 9 + 18 - 9 = 18 t, no king pin load on the
           truck, fits rigid and swapbody

      Example 2: semi-trailer on a converter dolly (two vehicles, no "registration" line)

        converter dolly          type: dolly
                                 gross_vehicle_weight: 18.00
        semi-trailer             (no type = semitrailer)
                                 gross_vehicle_weight: 39.00
                                 king_pin_load: 12.00

        -> 2 vehicles with 2 registrations, each taxed with its own values
           (dolly 18 t, semi-trailer 39 t with 12 t on the dolly)

      Example 3: HCT semi-trailer + converter dolly + semi-trailer

        no "registration" lines  -> 3 vehicles (semi-trailer, dolly, semi-trailer)
        dolly "type: dolly", the semi-trailers without type -> fits tractor
        units only (front part semitrailer)

      "prev" on the first part or "next" on the last part of a trailer is an error
      (see below), the part then counts as "own".
      Default:  own

  >>> fixed_plate: "<country>" | "<country>|<code>"
      plates fixed in the model (without the game's plate locator), e.g. for
      packs with real, fixed plates on the vehicle

        fixed_plate: "germany"
        fixed_plate: "germany|HN"

      The vehicle is permanently registered in this country from the purchase:
      no temporary plate, no registration duty. Vehicle tax by the rules of
      this country (weight, axles, Euro class etc. from the other entries, as
      for any vehicle). Insurance is the statutory liability insurance,
      changeable in the insurance menu (F7). The registration service is locked
      for the vehicle: no registration tile in the service shop, no click on
      the plate in the manager.
      <country> = game token of the country (germany, austria, netherlands ...).
      <code> = registration district as shown in the registration window;
      without code the default district of the country. Matters where the tax
      depends on the district (e.g. Poland, Romania, France).
      Vehicles already owned (temporary, deregistered or registered in another
      country) are re-registered to the country once; the old tax ends, no-claims
      class and insurance stay.
      Multi-part trailers: the entry may be in any part of the group and counts
      for the registration of the group.
      Default:  no entry = normal registration
  >>> loading: own | next | prev
      With the option "Split own doubles when loading" the chain of a trailer is
      spread over several loading lanes of the company: from the rear, every
      part gets a lane of its own and is detached there (key for detaching), the
      front part stays on the truck and is loaded on the lane of the game. After
      loading, the parts are coupled back together; the tour starts when the
      chain is complete. When unloading, the chain is only split if the hardest
      choice (most XP) is taken in the trailer delivery window.

      This works for own trailers and for company (job) trailers alike. It is only
      done when cargo is loaded or unloaded: simply dropping the trailer with the key
      for detaching (e.g. at a workshop or a trailer hub) always keeps the chain
      together.

      Which links belong together is set with "loading" in the v3def of every chassis
      of the chain:
        own   the link is a loading unit of its own
        next  the link stays with the link behind it (e.g. a converter dolly stays
              under the rear semi-trailer)
        prev  the link stays with the link in front of it

      If one link of the chain has no "loading" line, or a line that cannot be read,
      the chain is never split.

      The line is only read for the chain the trailer is in at the moment. A
      trailer with "loading: own" that runs as a single trailer is loaded as usual;
      the same trailer can be the front part of a double or stand behind a dolly
      with "next" in another chain.

      Example: HCT semi-trailer + converter dolly + semi-trailer
      (files in def/vehicle/trailer_owned/your_hct/chassis/)

        front semi-trailer       front_trailer.v3def   loading: own
        converter dolly          dolly.v3def           loading: next
        rear semi-trailer        rear_trailer.v3def    loading: own

        -> 2 parts: front semi-trailer / dolly + rear semi-trailer

      Example: company (job) double, semi-trailer + centre-axle trailer
      (files in def/vehicle/trailer/your_company_trailer/)

        front semi-trailer       chassis_hook.v3def    loading: own
        centre-axle trailer      chassis_ca.v3def      loading: own

        -> 2 parts: semi-trailer / centre-axle trailer
      Default:  none (the chain is never split)

  >>> load_split: true | false
      false = the chain is never split for loading and unloading (e.g. timber
      trailers loaded from above by crane); "loading" still sets which parts
      can be split on the road
      Default:  true

  >>> cable: prev | next | both | none
      who keeps the cable strand when split: prev, next, both or none

      When the chain of an own double is split (option "Split own doubles when
      loading", or a part detached with the key for detaching), the game itself has
      no rule for the cable strand between the two parts. The chassis .v3def decides:

        cable: prev    this part keeps the strand to the part in front of it
        cable: next    this part keeps the strand to the part behind it
        cable: both    prev and next
        cable: none    this part never keeps a strand

      Several "cable" lines are allowed. Between the front part A and the rear part B:
        1. B has prev or both            -> the strand stays at B (rest position at B)
        2. otherwise A has next or both  -> the strand stays at A (rest position as
                                            in the game)
        3. otherwise A has none          -> the strand stays at B
        4. otherwise                     -> the strand is removed

      A strand that stays at the rear part keeps its trailer plug in the socket
      (e.g. of the dolly); the free end goes to a rest point of the chassis model:

        cable_rest_prev {
            rst_cable_y : 0.45; 1.20; 5.80 : 0; 0; 0
            rst_cable_w : 0.55; 1.20; 5.80 : 0; 0; 0
        }

        name : x; y; z : heading; pitch; roll   (metres, degrees, chassis model)

      The entry is chosen by the rest name of the cable accessory (upper / lower case
      does not matter); if the accessory has no rest name, by the ending of the socket
      locator (ele_cable_w -> ..._w), otherwise by the order of the strands. Missing
      rest points are listed in fleet_road_realism.log. When the parts are coupled again, the game cables the chain as
      usual and the rest strands disappear.

      How the DLL lays a rest strand:
        - The Z axis of the rest point (and of the socket locator) points to the end
          of the cable, i.e. to the plug head. The cable leaves on the opposite side:
          if the rest point points down, the cable goes up out of the plug.
        - Length: for straight cables straight_cable_length of the cable accessory,
          otherwise the rope length of the game.
        - At both ends the cable makes a bend (stiffness, the longer the cable, the
          wider); the extra length sags down in the middle.
        - The cable lies on the boxes of the chassis collision (.pmc, or
          collision_override): on a drawbar it lies on top. Boxes above both cable
          ends (frame, body) push the cable to the side or down, never over them.
        - If the cable is shorter than the way from the socket to the rest point, it
          is drawn taut - then move the rest point closer to the socket.
      Default:  none (when split, the cable strand between the parts is removed)

  >>> cable_connect: <m>
      only on the front link of a double where there is no room to plug the cables
      in when coupled (e.g. B-double): distance in metres between the cable points of
      this link and the front of the part coupled behind it at which the cables are
      plugged in or unplugged (greater than 0, less than 20)

      Coupling: reverse to the distance, plug in the cables with the key, then hook
      in. Uncoupling: the key unlocks, landing gear down, cables stay plugged in;
      drive forward to the distance and unplug with the key (further away they come
      off by themselves).

        cable_connect: 1.2
      Default: none (hook in first, then plug in the cables)

  >>> cable_rest_prev {
          ...
      }
      rest points for the free plug ends

  >>> hook_attach: <.soundref or .bank#event, - = no sound>
      sound: part behind couples on

      Coupling sounds between the parts, as the truck has them in its sound.sui. The
      sounds of the part in front are played at the coupling point:

        hook_attach: /sound/your_trailer/hook.soundref
        hook_detach: /sound/your_trailer.bank#hook_detach
        trailer_cables: /sound/your_trailer.bank#cables

        or in the form of the truck's sound.sui:
        sounds[]: "hook_attach|/sound/your_trailer/hook.soundref"

        - path to a .soundref or bank#event, "-" = no sound
        - several lines with the same name: one of them at random
        - other sound names (air_brake ...) are ignored
        - '#' starts a comment only at the beginning of the line or after a space
          (paths like "bank#event" stay intact)
      Default:  no sound

  >>> hook_detach: <.soundref or .bank#event, - = no sound>
      sound: part behind uncouples
      Default:  no sound

  >>> trailer_cables: <.soundref or .bank#event, - = no sound>
      sound: cables plugged in
      Default:  no sound

  >>> twistlock_lock: <.soundref or .bank#event, - = no sound>
      sound: twistlock locked

      Twistlock sounds of container chassis (lock and open by hand), at the twistlock:

        twistlock_lock: /sound/your_trailer.bank#lock
        twistlock_unlock: /sound/your_trailer.bank#open

        or: sounds[]: "twistlock_lock|/sound/your_trailer.bank#lock"
        (twistlock_open is the same as twistlock_unlock; same rules as above)
      Default:  /sound/trailer/container.bank#lock

  >>> twistlock_unlock: <.soundref or .bank#event, - = no sound>
      sound: twistlock opened (twistlock_open = the same)
      sound values: .soundref or .bank#event, or sounds[]: "name|path" (see "hook_attach" and "twistlock_lock")
      Default:  /sound/trailer/container.bank#open

  >>> trailer_brace_up_sound: <.soundref or .bank#event, - = no sound>
      sound when the support legs go up as the DLL couples a part of a double
      (e.g. "-" in dolly.v3def, a dolly has no legs)

      A sound of its own per leg with [n] (number as in trailer_brace_model[n]):

        trailer_brace_up_sound[0]: "/sound/your_trailer.bank#legs/up"
        trailer_brace_down_sound[0]: "/sound/your_trailer.bank#legs/down"

        - [n] applies to leg n only, [] = next free number, "-" = no sound
        - without [] the sound applies to all legs without an entry of their own
        - a leg without an entry of its own and without an entry without [] =
          game sound (in the example: leg 1 has the game sound)
      Default:  game sound

  >>> trailer_brace_down_sound: <.soundref or .bank#event, - = no sound>
      sound when the support legs go down as the DLL parks a part of a double;
      per leg with [n] (see "trailer_brace_up_sound")
      Default:  game sound

  >>> dbl_coupling {
          ...
      }
      coupling guide when re-coupling

      Shapes that guide the parts into each other when a detached part of an own
      double is coupled again (coupling jaw at the rear of the front part, drawbar
      eye or king pin at the front of the detached part). They work like the
      game's own guides (pmc parts "adv_cpling"): soft, without impact, and only
      while that part is being coupled; otherwise they are off.

        dbl_coupling {
            box : 0;0.543118;5.146128 : 0;0;0 : 0.099903;0.063770;0.153327
            cylinder : 0;0.539275;-5.769051 : 90.036583;0;0 : 0.053878;0.033937
        }

        box : x;y;z : rotX;rotY;rotZ : sizeX;sizeY;sizeZ
        capsule | cylinder : x;y;z : rotX;rotY;rotZ : scaleX;scaleZ

        - position in metres, rotation in degrees, sizes - all as ZModeler shows
          them for the chassis model
        - several lines, one shape each
        - instead of the block, the pmc of the chassis may hold parts named
          "dbl_cpling"

  >>> model_override: "<path>.pmd"
      own chassis model (.pmd)

      Replaces the chassis model of the game and adds support legs, e.g. for a
      part of a double that can stand on its own:

        model_override: "/vehicle/trailer_owned/your_trailer/chassis.pmd"
        collision_override: "/vehicle/trailer_owned/your_trailer/chassis.pmc"

        trailer_brace_model[0]: "/vehicle/trailer_owned/your_trailer/brace_front.pmd"
        trailer_brace_anim[0]: "/vehicle/trailer_owned/your_trailer/brace_front.pma"
        trailer_brace_use[0]: always

        trailer_brace_model[1]: "/vehicle/trailer_owned/your_trailer/brace_rear.pmd"
        trailer_brace_anim[1]: "/vehicle/trailer_owned/your_trailer/brace_rear.pma"
        trailer_brace_use_min[1]: 5500
        trailer_brace_use[1]: loading

        - model_override (.pmd) / collision_override (.pmc): model and collision
          instead of those of the chassis .sii
        - if a given file is missing (for .pmd also the .pmg), an error is written to
          fleet_road_realism.log and the game model stays (no crash)
        - trailer_brace_model / trailer_brace_anim: model (.pmd) and animation
          (.pma) of a support leg, as in the chassis .sii of the game. Without []
          = leg 0, with [n] = leg n (several legs)
        - trailer_brace_use / trailer_brace_use_min always with [n] (or []),
          model_override / collision_override always without []; n at most 15
        - trailer_brace_use[n]: always = the leg always goes down when the part is
          set down; loading = only when splitting for loading / unloading at the
          company, otherwise by weight (trailer_brace_use_min)
        - trailer_brace_use_min[n]: kg - the leg also goes down when the cargo of
          the part is at least this heavy
        - without trailer_brace_use: always, or only by weight if
          trailer_brace_use_min is set
        - legs go down in the order of the entries and up in reverse order; the
          model parts of leg 0 are brace_on / brace_off (or brace_on_0 /
          brace_off_0), those of leg n are brace_on_n / brace_off_n

  >>> collision_override: "<path>.pmc"
      own chassis collision (.pmc)

  >>> trailer_brace_model[n]: "<path>.pmd"
      model of support leg n (.pmd)

  >>> trailer_brace_anim[n]: "<path>.pma"
      animation of support leg n (.pma)

  >>> trailer_brace_use[n]: always | loading
      always = always
      loading = when split at the company, otherwise by weight

  >>> trailer_brace_use_min[n]: <kg>
      kg - support leg also goes down from this cargo weight
      (see "model_override")

ALL CHASSIS (truck and trailer)
-------------------------------
/def/vehicle/truck/xxxx/chassis/xxxx.v3def
/def/vehicle/trailer_owned/xxxx/chassis/xxxx.v3def

  >>> gross_vehicle_weight: <tonnes or kg>
      permissible gross weight
      Default:  truck by number of axles: 2 -> 18 t, 3 -> 26 t, 4 or more -> 32 t
                trailer by number of axles: 1 -> 20 t, 2 -> 30 t, 3 or more -> 39 t

  >>> suspension: air | leaf
      air = air suspension (or equivalent) of the driven axle(s) / trailer
      axles
      leaf = any other suspension
      Default:  air

  >>> plate_depth_rear: <mm>
      rear plate forward/back, mm
      (see "plate_depth_front" under TRUCK CHASSIS)
      Default:  0

  >>> plate_rotate_rear: <degrees>
      rear plate tilt, degrees
      (see "plate_depth_front" under TRUCK CHASSIS)
      Default:  0

  >>> italy_card_shift_rear: <mm>
      Italian cardboard plate rear up/down, mm
      (see "italy_card_shift_front" under TRUCK CHASSIS)
      Default:  0

  >>> italy_card_depth_rear: <mm>
      Italian cardboard plate rear forward/back, mm
      (see "italy_card_shift_front" under TRUCK CHASSIS)
      Default:  0

  >>> italy_card_tilt_rear: <degrees>
      Italian cardboard plate rear tilt, degrees
      (see "italy_card_shift_front" under TRUCK CHASSIS)
      Default:  0

  >>> serbia_card_shift_rear: <mm>
      PROBA plate rear up/down, mm
      (see "italy_card_shift_front" under TRUCK CHASSIS)
      Default:  0

  >>> serbia_card_depth_rear: <mm>
      PROBA plate rear forward/back, mm
      (see "italy_card_shift_front" under TRUCK CHASSIS)
      Default:  0

  >>> serbia_card_tilt_rear: <degrees>
      PROBA plate rear tilt, degrees
      (see "italy_card_shift_front" under TRUCK CHASSIS)
      Default:  0

  >>> greece_export_shift_rear: <mm>
      Greek export plate rear up/down, mm
      (see "greece_export_shift_front" under TRUCK CHASSIS)
      Default:  0

  >>> greece_export_depth_rear: <mm>
      Greek export plate rear forward/back, mm
      (see "greece_export_shift_front" under TRUCK CHASSIS)
      Default:  0

  >>> greece_export_rotate_rear: <degrees>
      Greek export plate rear tilt, degrees
      (see "greece_export_shift_front" under TRUCK CHASSIS)
      Default:  0

ACCESSORY REAR BUMPER
---------------------
/def/vehicle/trailer_owned/xxxx/accessory/r_bumper/xxxx.v3def

  An accessory can get its own model and an animation that runs depending on
  the part behind it, e.g. a rear bumper that folds up when the next part of a
  double is coupled. Currently for rear bumpers (accessory/r_bumper/) of the
  accessory type accessory_addon_data.

    model_override: "/vehicle/trailer_owned/upgrade/r_bumper/your_bumper.pmd"
    model_override_uk: "/vehicle/trailer_owned/upgrade/r_bumper/your_bumper_uk.pmd"
    collision_override: "/vehicle/trailer_owned/upgrade/r_bumper/your_bumper.pmc"
    model_anim: "/vehicle/trailer_owned/upgrade/r_bumper/your_bumper.pma"
    anim_type: attach_next
    anim_start: attached
    anim_distance: 2

  Locators of the model that have a bone of the same name move with the
  animation (lights, plate). truckpaint materials are painted as on the rest of
  the trailer.

  On animated accessories, make truckpaint meshes separate objects under bones
  of their own, do not attach them to other parts. Otherwise all other parts
  look wrong after painting (lights black, textures missing).

  >>> model_override: "<path>.pmd"
      own model (.pmd), instead of exterior_model of the accessory .sii

  >>> model_override_uk: "<path>.pmd"
      own UK model (.pmd), instead of exterior_model_uk of the accessory .sii
      Default:  model_override

  >>> collision_override: "<path>.pmc"
      own collision (.pmc), instead of coll of the accessory .sii

  >>> model_anim: "<path>.pma"
      animation (.pma) for the model

  >>> anim_type: attach_next
      attach_next = depends on the part behind (the only type)

  >>> anim_start: attached | detached
      which state the first frame of the .pma shows: attached (part behind
      coupled) or detached

  >>> anim_distance: <metres>
      metres. "detached" only when nothing is coupled behind and no part of the
      own double is closer than this (end to end), so the bumper does not block
      the doors when the parts stand close together for loading
      Default:  2

ACCESSORY MIRROR
----------------
/def/vehicle/truck/xxxx/accessory/mirror/xxxx.v3def
(likewise s_mirror, f_mirror and other mirror folders whose name ends with
"mirror"; accessory type accessory_addon_data)

  Turning mirror glasses: when the mirrors are adjusted in the game ("Adjust
  mirrors") the glass turns with them, by exactly the angle the game turns the
  mirror image. For this the mirror gets replacement models without glass,
  with locators, and every glass is a model of its own at its locator. Plus an
  adjustment sound (motor or by hand).

    interior_model_override: "/vehicle/truck/upgrade/mirror/your_truck/mirror_01_interior_mg.pmd"
    interior_model_override_uk: "/vehicle/truck/upgrade/mirror/your_truck/mirror_01_interior_uk_mg.pmd"
    exterior_model_override: "/vehicle/truck/upgrade/mirror/your_truck/mirror_01_mg.pmd"
    exterior_model_override_uk: "/vehicle/truck/upgrade/mirror/your_truck/mirror_01_uk_mg.pmd"
    mirror_glass[]: d "/vehicle/truck/upgrade/mirror/your_truck/glass_d.pmd"
    mirror_glass[]: ds "/vehicle/truck/upgrade/mirror/your_truck/glass_ds.pmd"
    mirror_glass_ext[]: d "/vehicle/truck/upgrade/mirror/your_truck/glass_d_ext.pmd"
    mirror_glass_ext[]: ds "/vehicle/truck/upgrade/mirror/your_truck/glass_ds_ext.pmd"
    mirror_adjust: electric

  Mirror slots (like the game's camera locators in the mirror model):

    d    driver side (cam_d)                  p    passenger side (cam_p)
    ds   driver side wide angle (cam_ds)      ps   passenger side wide angle (cam_ps)
    s    ramp / side mirror (cam_s)           f    front mirror (cam_f)
    h    hood / fender mirror (cam_h)

  Driver and passenger side also apply to right-hand drive (UK models).

  Models:
  - replacement models (interior and exterior): the previous mirror model
    without the glasses, with locators mglass_d, mglass_ds, mglass_p,
    mglass_ps, mglass_s, mglass_f, mglass_h instead (only the existing ones).
    Interior and exterior model use the same locator names. The locators get
    no hookup.
  - locator = pivot of the glass, rotation 0. On modern mirrors the
    adjustment motor or ball joint behind the glass, on mirrors whose whole
    head swings on the arm, the joint on the arm.
  - glass model (.pmd): origin in the pivot, the glass as it sits in the
    mirror model (only moved, not rotated). This position is the neutral
    position ("Reset" in the game). Interior and exterior have glass models
    of their own (different materials).
  - It turns by the angle of the game setting (sideways up to 10 degrees,
    up/down up to 7.5 degrees), in the axes of the camera locators. How far
    the glass moves follows from its distance to the pivot.
  - Exterior glasses are drawn on every vehicle with this mirror; only the own
    truck is adjusted, all others stay neutral.

  >>> interior_model_override: "<path>.pmd"
      interior model without glasses, instead of interior_model of the
      accessory .sii

  >>> interior_model_override_uk: "<path>.pmd"
      like interior_model_override for interior_model_uk (right-hand drive)

  >>> exterior_model_override: "<path>.pmd"
      exterior model without glasses, instead of exterior_model of the
      accessory .sii (mirrors only)

  >>> exterior_model_override_uk: "<path>.pmd"
      like exterior_model_override for exterior_model_uk (right-hand drive)

  >>> mirror_glass[]: <slot> "<path>.pmd"
      glass in the interior model at locator mglass_<slot>, one line per glass
      (needs interior_model_override)

  >>> mirror_glass_ext[]: <slot> "<path>.pmd"
      glass in the exterior model at locator mglass_<slot>, one line per glass
      (needs exterior_model_override)

  >>> mirror_adjust: electric | manual
      sound when adjusting: electric = adjustment motor (start-up, motor as
      long as the glass moves, strained motor at the end stop while the key
      is held, run-down), manual = short creak per step. The mod brings the
      sounds (/sound/lphd/mirror.bank). Applies to the mirrors with
      mirror_glass[] or mirror_glass_ext[] lines, otherwise by folder
      (mirror = d, ds, p, ps; s_mirror = s; f_mirror = f; others = f, h).
      Default:  no sound

  >>> mirror_axes: horizontal | vertical | both
      in which direction the mirrors of this accessory can be adjusted in the
      game: horizontal = only left/right, vertical = only up/down, both = both.
      The arrows of the other direction are hidden in the adjustment window.
      Default:  both

  >>> mirror_glass_axes[]: <slot> locator | camera
      rotation axes of one glass, one line per glass: camera = axes of the
      mirror camera cam_<slot> (like the mirror image), locator = axes of
      the locator mglass_<slot>. For mirrors whose head sits slanted on the
      arm while the camera is straight: tilt the locator in the model so its
      Y axis follows the slant of the arm (X to the side, Z to the rear as in
      the model). Left/right then turns the glass around this Y axis, up/down
      around the tilted cross axis. The glass model stays as in the mirror
      model (the locator does not rotate it).

        mirror_glass_axes[]: ds locator

      Default:  camera
      like mirror_glass[] for the interior model of right-hand drive
      (needs interior_model_override_uk)

  >>> mirror_glass_ext_uk[]: <slot> "<path>.pmd"
      like mirror_glass_ext[] for the exterior model of right-hand drive
      (needs exterior_model_override_uk)

  >>> mirror_rain[]: <slot> "<path>.mat"
      rain drops on the mirror glass (option for rain drops on the mirrors):
      material of the glass in the mirror model or in the glass model from
      mirror_glass[]. Every glass needs a material of its own; all faces with
      this material get drops like the windshield, a turning glass takes them
      along.

        mirror_rain[]: d "/vehicle/truck/upgrade/mirror/your_truck/glass_d.mat"

  >>> mirror_rain_uk[]: <slot> "<path>.mat"
      like mirror_rain[] for the right-hand drive models

  >>> mirror_rain_size: <factor>
      size of the drops on all glasses of this accessory relative to the
      windshield (e.g. 0.5 = half the size)
      Default:  1

ACCESSORY INTERIOR
------------------
/def/vehicle/truck/xxxx/interior/xxxx.v3def (interior accessory,
accessory_interior_data)

  Sleeping: with "rest" of 1 hour or more the driver gets up, walks between the
  seats to the bed and lies down (interior camera), after sleeping the same way
  back. Without a bed (or below 1 hour) he rests in the seat.

  >>> sleeper: true | false
      true = this interior accessory has a bed
      Default:  false

  >>> bed_area: "<locator a>" "<locator b>"
      two locators in the interior model at two opposite corners of the
      mattress; or the corners directly as coordinates of the interior model,
      as ZModeler shows them:

        bed_area: "bed_a" "bed_b"
        bed_area: 0.55;0.92;-0.61 : -0.55;0.92;-1.30

      Without bed_area there is no sleep sequence despite sleeper: true.

  >>> bed_head: a | b
      head end at the end of corner a or b
      Default:  random

  >>> windshield_material[]: "<material>"
      material of the windshield in the interior model (or of its
      replacement), one line per material. The faces of these materials give
      the curvature of the windshield for dirt and drops on the glass.
      Default:  no entry = flat glass

WASHER NOZZLES
--------------
/def/vehicle/truck/xxxx/cabin/xxxx.v3def (cabin accessory; every accessory of
the truck that has the lines is read)

  The windshield washer sprays onto the windshield where the nozzles aim.
  Coordinates are those of the cabin model, as ZModeler shows them; the mod
  converts them into the interior through the locator "interior" of the cabin
  model (without this locator they count as interior model coordinates).

  >>> washer: fixed | wiper
      fixed = fixed nozzles (bonnet/cowl), wiper = nozzles in the wiper blade
      (jet turns with the arm)
      Default:  fixed

  >>> washer_jets: single | double
      single = one jet per nozzle, double = two jets per nozzle in a V shape
      Default:  single

  >>> washer_jets_angle: <degrees 5 - 170>
      opening of the V with washer_jets: double
      Default:  two spots 15 cm left/right each

  >>> washer_spot[]: x;y;z
      spot where a fixed nozzle hits the glass, one line per nozzle
      Default:  per wiper a spot of about 15 cm above the resting blade

  >>> washer[n]: x;y;z
      position of the fixed nozzle n (n = 0, 1, 2 ...)

  >>> washer_spot[n]: x;y;z
      spot where nozzle n hits the glass (needs washer[n])

BODY
----
/def/vehicle/trailer_owned/xxxx/body/xxxx.v3def

  >>> floor: wood | metal | film
      wood, metal or film = deck
      Default:  wood

  >>> floor[]: "wood|x1|x2"
      "metal|x1|x2" = strip with a different deck
      (see README_lashing_data)

COMPANY TRAILER DRIVER TOURS
----------------------------
/def/vehicle/trailer/xxxx.v3def (next to the .sui)

  >>> equivalency: <token>
      same token = the same trailer in another length

      Trailers of /def/vehicle/trailer (the trailers of driver tours and quick jobs)
      that exist in two lengths (retracted / extended) get a .v3def next to their
      .sui, same name:

        /def/vehicle/trailer/scs_lowloader_2ax.sui
        -> /def/vehicle/trailer/scs_lowloader_2ax.v3def
        /def/vehicle/trailer/scs_lowloader_2ax_ext.sui
        -> /def/vehicle/trailer/scs_lowloader_2ax_ext.v3def

        equivalency: lowldr_2ax  same token = same trailer in another length

      Only trailers with such a file and a partner with the same token can be
      switched; all other trailers need no file. On a driver tour with an empty
      trailer and the truck standing still, the game action "adjust trailer" switches to the
      other length (chassis, body and trailer definition of the partner .sui).
      Cargo for both lengths can be offered; at the loading company the cargo is
      only loaded with the right length, the HUD asks to extend or retract the
      trailer (also possible during the waiting time). lphd_tieflader_v3def.zip
      holds the files for the SCS low loaders.


Errors
------
A line that is present but cannot be read (e.g. "gross_vehicle_weight: 18 t",
"emission: six", "emission: 9", "type: semi", "suspension: steel",
"registration: dolly", "italy_card_shift_rear: 1,5 cm",
"serbia_card_depth_rear: 2 cm", "italy_card_tilt_rear: 60",
"plate_rotate_rear: 50") is reported
as an error in game.log

  <ERROR> [fleet_road_realism] /def/.../your_chassis.v3def: invalid value for
          gross_vehicle_weight (expected e.g. "gross_vehicle_weight: 18.00"),
          using default 18 t

and in fleet_road_realism.log. The default value is used for that line.


What the values are used for
----------------------------
  Germany (own registration)      vehicle tax by emission class

  Austria (own registration)      vehicle tax per started tonne and month:
                                  up to 12 t 1.55 EUR (min. 15), 12-18 t 1.70 EUR,
                                  above 18 t 1.90 EUR; max. 80 EUR truck, 66 EUR trailer
                                  trailer weight = gross_vehicle_weight - king_pin_load

  Switzerland (own registration)  cantonal vehicle tax, tariff of the canton on the
                                  plate, per calendar year in advance (pro rata in the
                                  year of registration, rest refunded when the vehicle
                                  is sold, deregistered or moved to another canton).
                                  Depending on the canton by gross weight, payload
                                  (gross weight - empty weight), gross combination
                                  weight (tractor units), displacement or power;
                                  some cantons use the Euro class or reduce the tax
                                  for electric trucks. The number stays reserved for
                                  the company for one year after a sale.

  Switzerland (all trucks)        LSVA = km in Switzerland x weight x tariff
                                  weight = truck + coupled trailer - king_pin_load,
                                  max. 40 t; tariff by emission (Rappen per tkm):
                                  Euro 0-3 3.26, Euro 4-5 2.82, Euro 6-7 2.39
                                  electric trucks (engine "type: electric") are exempt

  France (own registration)       TSVR (heavy vehicle tax), settled in arrears per
                                  calendar year from a logbook (day by day):
                                  rigid trucks from 12 t by axles and gross weight,
                                  tractor units by gross combination weight and the
                                  axles of the trailer pulled that day (no trailer:
                                  nothing); air / other suspension

  Italy (own registration)        IPT at registration: tractor units by power (kW),
                                  rigid trucks and trailers by payload
                                  (gross weight - empty weight); bollo per year:
                                  rigid trucks by axles, gross weight and suspension,
                                  tractor units by region and axles (2 / 3 or more)

  Poland (own registration)       tax on means of transport (two instalments a year):
                                  rigid trucks by axles and gross weight, tractor
                                  units by axles and gross combination weight,
                                  trailers by axles; air / other suspension;
                                  rates of the municipality (minimum rates otherwise)

  Czechia (own registration)      road tax for trucks from 12 t, in arrears per
                                  calendar year (1/12 per started month): rigid
                                  trucks by axles and gross weight, tractor units by
                                  axles and gross combination weight (trailers are
                                  covered by the tractor); air / other suspension

  Slovakia (own registration)     motor vehicle tax, in arrears per calendar year
                                  (1/12 per month, return by 31 January, prepayments
                                  quarterly above 700 EUR / monthly above 8,300 EUR
                                  of the previous year's tax): rigid trucks by axles
                                  and gross weight, tractor units by axles and gross
                                  combination weight, air / other suspension;
                                  trailers (O4) a flat 150 EUR; trucks pay an age
                                  surcharge (+10 % after 3 years, rising every
                                  3 years, +50 % from the 181st month) counted from
                                  the first registration in the game

  Hungary (own registration)      motor vehicle tax per started 100 kg, paid by
                                  15 April for the months up to the end of the year
                                  (from the month after registration to the month
                                  of deregistration): rigid trucks and trailers
                                  empty weight + 50 % of the payload, tractor units
                                  2 x empty weight + 1/2 x (gross combination weight
                                  - 2 x empty weight); air / other suspension;
                                  reductions for Euro III (-20 %, tractor units
                                  -30 %) and Euro IV-V (-30 % / -50 %), none for
                                  Euro I-II and Euro VI; electric trucks (class 5E,
                                  emission entry ignored) -20 % / -30 %.
                                  Acquisition duty at the first registration in
                                  Hungary: trucks per kW by power and age (from the
                                  first registration in the game), trailers flat
                                  24,000 Ft

  Greece (own registration)       road tax per calendar year in advance (full year
                                  with the registration, then on 1 November for the
                                  following year): rigid trucks by gross weight
                                  (up to 10 t 300 EUR, 20 t 600, 30 t 940, 40 t 1,320,
                                  above 1,490), tractor units 300 EUR, trailers free.
                                  Used trucks below Euro V (emission 0-4) cannot be
                                  registered in Greece; electric trucks are exempt
                                  from this rule.

  Romania (own registration)      tax on means of transport per calendar year: rigid
                                  trucks by axles and gross weight, tractor units by
                                  their axles + the axles of the semi-trailer chosen
                                  at registration (none coupled: 3) and gross
                                  combination weight; air / other suspension. The
                                  tractor pays for the combination, the semi-trailer
                                  pays nothing. Electric trucks use the same table.
                                  The owner on 31 December pays for the next year:
                                  registered during the year -> from 1 January of
                                  the following year; whole year on 31 March with a
                                  bonus (10 %, Bacau 5 %); surcharge of the town of
                                  the garage (Brasov +35 %, Craiova +13 %,
                                  Timisoara +50 %); no refund on sale/deregistration

  Bulgaria (own registration)     vehicle tax per year: rigid trucks by axles and
                                  gross weight, tractor units by axles and gross
                                  combination weight; air / other suspension;
                                  multiple of the minimum rate set by the town of the
                                  garage (otherwise by the plate code): Sofia 1.25,
                                  Plovdiv 1.43, Varna 2.25, Burgas 1.5, Veliko
                                  Tarnovo 1.3, Stara Zagora 1.5, others 1.0;
                                  Euro 4 -20 %, Euro 5-6 -50 % (not in Stara Zagora,
                                  electric trucks full rate); trailers no own tax.
                                  Whole year by 30 April with 5 % discount; in the
                                  year of registration 1/12 per month from the month
                                  of registration (due in two months); sale or
                                  deregistration: tax up to the end of the month,
                                  overpaid tax refunded

  Slovenia (own registration)     annual vehicle charge = days x daily rate, one year
                                  in advance with the registration, then yearly:
                                  rigid trucks per started tonne of gross weight,
                                  tractor units per kW up to 190 kW (above a flat
                                  daily rate), separate rates up to / above 20 t
                                  gross weight; trailers per tonne of gross weight,
                                  semi-trailers free. Euro VI -35 %, V -25 %, IV 0,
                                  III +10 %, II +20 %, I +30 %, 0 +40 %; electric
                                  trucks -90 %; air suspension (rigid trucks only)
                                  a further -15 %. Minimum 5 EUR; rest refunded on
                                  sale/deregistration (amounts up to 5 EUR not)

  Croatia (own registration)      road charge 40 EUR x coefficient, one year in
                                  advance with the registration: trucks by gross
                                  weight and axles, trailers by gross weight and
                                  axles, semi-trailers by the sum of the axle loads
                                  (gross_vehicle_weight - king_pin_load).
                                  Environment charge (trucks only): 60.52 EUR x
                                  displacement factor x age factor (age from the
                                  first registration in the game); electric trucks
                                  0. No refund on sale/deregistration

  Serbia (own registration)       municipal fee per year (due at registration, then
                                  yearly, maximum rates for all areas): rigid trucks
                                  and trailers by payload (gross weight - empty
                                  weight), tractor units by power (kW); no refund
                                  on sale/deregistration

  Montenegro (own registration)   road charge for 12 months in advance with the
                                  registration, then with each renewal (shorter
                                  registration pro rata by months); no refund, a new
                                  owner pays nothing until it expires. Until 30 June
                                  2027: rigid trucks and trailers by payload (gross
                                  weight - empty weight), tractor units by power
                                  (kW); from 1 July 2027: 5 EUR x coefficient by
                                  gross weight and axles (separate tables for
                                  trailers and semi-trailers).
                                  Short-term liability insurance: rigid trucks and
                                  trailers by payload, tractor units by power (kW)

  North Macedonia                 road fee for 12 months with the registration
  (own registration)              (shorter registration pro rata, 30 days = 1 month),
                                  no refund: tractor units by power (kW), rigid
                                  trucks and trailers by payload (gross weight -
                                  empty weight), semi-trailers flat 5,200 MKD

  Bosnia and Herzegovina          annual charges for 12 months in advance with the
  (own registration)              registration, by the entity of the district.
                                  Federation: road charge 30 KM x coefficient, trucks
                                  and tractor units by gross weight and axles,
                                  semi-trailers by the sum of the axle loads
                                  (gross_vehicle_weight - king_pin_load), trailers
                                  by gross weight; environment charge (trucks only)
                                  by fuel (electric x 0.2), displacement and age
                                  (from the first registration in the game); water
                                  charge 0.30 KM per kW (not electric trucks); road
                                  charge refunded from the day of deregistration.
                                  Republika Srpska: road toll by gross weight,
                                  tractor units flat 120 KM; no refund

  Albania (own registration)      TVMP (trucks only): displacement x age coefficient
                                  x 12.5 ALL; free in the first 3 years, 0.20 in the
                                  4th year, +0.02 per year up to 0.60 (age from the
                                  first registration in the game); electric trucks
                                  and trailers pay nothing. Valid 365 days from
                                  payment, no refund; after a temporary
                                  deregistration pro rata per month to 31 December

  Turkey (own registration)       MTV (trucks only, trailers free) by gross weight of
                                  the truck (not the combination) and age (1-6,
                                  7-15, 16+ years, counted from the year of the
                                  first registration in the game); two equal
                                  instalments in January and July, with the
                                  registration the instalment of the current
                                  half-year; after sale/deregistration no further
                                  instalments

  Russia (own registration)       transport tax (trucks only, trailers free):
                                  horsepower (kW x 1.35962) x rate of the region on
                                  the plate (in some regions by age from the first
                                  registration in the game) x months / 12; paid in
                                  arrears per quarter (28 April, 28 July,
                                  28 October, 1 March); a month counts when
                                  registered by the 15th / deregistered after the
                                  15th; no refund, open months after deregistration
                                  are charged on the next date

  Lithuania (own registration)    annual charge from 12 t gross weight (trucks and
                                  trailers), by tonne of gross weight (semi-trailers:
                                  gross_vehicle_weight - king_pin_load), air / other
                                  suspension; 12 months with the registration, then
                                  yearly; no refund

  Latvia (own registration)       vehicle operation tax per calendar year: trucks up
                                  to 12 t by Euro class, above 12 t by axles and Euro
                                  class (own table for tractor units); electric
                                  trucks free. Trailers above 3.5 t: one axle 66 EUR,
                                  otherwise by axles, suspension of the towing
                                  vehicle and weight (semi-trailer: empty weight of
                                  the tractor + gross weight of the semi-trailer;
                                  trailer: gross weight of truck + trailer); the
                                  towing vehicle is chosen at registration (default:
                                  tractor 2 axles, 7.7 t empty, air suspension /
                                  rigid truck 3 axles, 26 t). With the registration
                                  the remaining months including the current one,
                                  then every January; deregistration: full
                                  remaining months refunded

  Estonia (own registration)      heavy vehicle tax per quarter: rigid trucks from
                                  12 t by axles, gross weight and suspension (air /
                                  other); tractor units as a combination: own axles
                                  + axles of the semi-trailer chosen at registration
                                  (default 3), by gross combination weight;
                                  trailers free. With the registration the full
                                  remaining months of the quarter (without the
                                  registration month), then the whole quarter on
                                  1 January / April / July / October; no refund,
                                  after deregistration nothing from the next quarter

  Kosovo (own registration)       road tax 90 EUR + eco tax 30 EUR for 365 days with
                                  the registration (trucks and trailers, flat, no
                                  vehicle values); renewal 170 EUR (incl. 50 EUR
                                  administration); no refund
