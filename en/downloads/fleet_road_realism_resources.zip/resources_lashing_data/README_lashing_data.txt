Fleet & Road Realism - Ladungssicherung (.v3def) / cargo securing (.v3def)
==========================================================================

Kleine optionale Dateien sagen der Mod, wie eine Ladung gesichert wird und wie
sie sich verhaelt: Kantenschoner, Verschleiss an Kanten, Kippen und Rutschen,
Antirutschmatten, Ladeboden und eigene Zurrmittel. Sie funktionieren mit jeder
Fracht-Mod: die Dateien liegen neben den Dateien, die das Spiel ohnehin laedt.
Die Beispiele im Ordner def/ dieses Pakets zeigen das Format.
Alles wirkt mit der Option "Ladung selbst sichern"; Antirutschmatten legt die
Mod ohne die Option selbst.

Small optional files tell the mod how a cargo is secured and how it behaves:
edge guards, wear at edges, tipping and sliding, anti-slip mats, deck and your
own lashing gear. They work for every cargo mod: the files sit next to the
files the game already loads. The examples in the def/ folder of this package
show the format.
Everything works with the option "secure cargo yourself"; anti-slip mats are
laid by the mod itself without the option.

DE
==

1. Ladungsmodell (cargo_model_match)
------------------------------------
Gleicher Ordner und gleicher Name wie die cargo_model_match-Datei der Fracht,
nur mit .v3def:

  /def/vehicle/cargo/your_cargo/model_area.sii
  -> /def/vehicle/cargo/your_cargo/model_area.v3def

Gibt es mehrere Match-Dateien (z. B. model_area.sii und model_area_1.sii),
bekommt jede ihre eigene .v3def. Alle Eintraege sind optional; fehlt die Datei,
gelten die Standardwerte. Ein Eintrag mit falschem Format steht als Fehler im
Log (Datei und gelesener Wert), die Zeile wird dann nicht verwendet.

1a. Kantenschoner
-----------------
  edge_guard: true          Schoner beim Sichern von Hand setzbar (Standard: false)
  edge_guard_width: 0.20    Breite des Schoners in m, 0.01 - 2
                            (Standard: Gurt = Gurtbreite + 0.20, eingefaedelt
                            + 0.04; Kette 0.20)
  edge_guard_leg: 0.10      Schenkellaenge je Seite der Kante in m, 0.005 - 1
                            (Standard: Gurt 0.10, eingefaedelt 0.05; Kette 0.15)

1b. Verschleiss an Kanten
-------------------------
  edge_wear: 0.4            Scheuern des Gurts an einer Kante ohne Schoner,
                            0.0 - 1.0 (Standard 0.5). Mit Schoner zaehlt nur
                            ein Fuenftel. Zusammen mit dem Nachgeben der Ratsche
                            wird der Gurt locker (ab 75 %).
  edge_crush: 0.5           Quetschen der Ladung an einer Kante ohne Schoner,
                            0.0 - 1.0 (Standard 0.5) - fuer eine spaetere
                            Version, derzeit noch ohne Wirkung.

1c. Kippen loser Ladung
-----------------------
Ist ein Zurrmittel an einem Ladungsstueck locker, kann das Stueck in Kurven
und beim Bremsen kippen - so weit, bis das lockere Zurrmittel es haelt - und
faellt mit einem Aufschlag zurueck. Ein straffes Zurrmittel am Stueck haelt es.
Alle Werte in Modellkoordinaten (m): x quer, y hoch, z laengs.

  tilt[]: false            Dieses Ladungsmodell kippt nie (z. B. sehr
                            flache oder fest verkeilte Ladung). Standard: true.

  tilt_base[]: "single|(x, z)|Radius"
      Ein Aufstandspunkt (Rad, Fuss, Stuetze). Radius = halbe Reifen- bzw.
      Fussbreite, so weit reicht der Aufstand nach aussen (optional, Standard 0).
  tilt_base[]: "area|(x, z)|(x, z)"
      Eine Standflaeche: Aussenmasse als zwei gegenueberliegende Ecken
      (Kiste, Palette, Rahmen, Keile).
  tilt_base[]: "ring|(x, z)|Radius aussen|Radius innen|Winkel von|Winkel bis"
      Ein Ring bzw. Ringsegment (stehendes Rohrstueck, Schalung, Bogen):
      Kreismitte, Aussen- und Innenradius, Bogen von - bis in Grad
      (0 = Richtung +x, 90 = Richtung +z). Ohne Winkel: voller Ring.
      Beispiel halber Ring ueber -x: "ring|(1.53, 0.0)|3.05|2.40|90|270"

  Mehrere Zeilen und alle Arten lassen sich mischen; die Standflaeche ist
  die Umrisslinie um alle Punkte. Gekippt wird um deren Kante.
  Ohne tilt_base[] nimmt die Mod die tiefsten Punkte des Modells (Mesh).

  Material oder Reibwert (optional, erstes Feld jeder tilt_base-Zeile):
  woraus die Aufstandsflaeche besteht. Daraus ergibt sich die Haftreibung auf
  der Ladeflaeche (fuers Rutschen) und, ob dort eine Antirutschmatte noetig
  ist (Abschnitt 3). Ohne Angabe 0.45.
      "Material|single|(x, z)|Radius"
      "Material|area|(x, z)|(x, z)"
      "Material|ring|(x, z)|Radius aussen|Radius innen|Winkel von|Winkel bis"
  Materialien (Wert auf Holzboden):
      wood 0.50       Schnittholz (Balken, Kisten, Kufen)
      plastic 0.20    Kunststoff
      metal 0.45      Stahl / Metall
      concrete 0.55   Beton
      rubber 0.60     Gummi (Reifen, Gummiketten)
      straw 0.40      Stroh
  Statt eines Materials geht auch eine Zahl 0.01 - 1.5 (Reibwert auf
  Holzboden). Richtwerte nach EN 12195-1: gehobeltes Holz 0.3, Beton rau 0.7.
  Der Wert wird mit dem Ladeboden des Aufliegers verrechnet (Abschnitt 4).
  Beispiel Rad: tilt_base[]: "rubber|single|(-0.75, -0.40)|0.08"
  Beispiel Kufe: tilt_base[]: "wood|area|(-1.15, -0.70)|(1.15, -0.60)"

  coll_base[]: "single|(x, y, z)|Radius"
  coll_base[]: "area|(x, y, z)|(x, y, z)"
  coll_base[]: "cylinder|(x, y, z)|(x, y, z)|Radius"
      Teile, die beim Kippen auf der Ladeflaeche aufsetzen (Gabel, Schaufel,
      Anbaugeraet, Ueberhang). Hier ist Schluss mit Kippen. single = Punkt mit
      Radius, area = Flaeche aus zwei gegenueberliegenden Ecken (x, y, z).
      Hoehe und Breite laufen in Laengsrichtung (z) gleichmaessig ueber:
      verschiedene Hoehe = schraeg. Liegen die Ecken links und rechts der
      Mitte, ist die Flaeche ein zur Mitte gleichmaessiges Trapez (je Ende
      +-x, z. B. Kotfluegel breit und tief, Kastenende schmal und hoeher).
      Liegen beide auf derselben Seite, ist es ein Rechteck dazwischen
      (z. B. Mast neben der Mitte).
      cylinder = Zylinder (Kessel, Rohr): Mitte der beiden Stirnflaechen
      (Start- und Endpunkt) und Radius. Ein zweiter Radius dahinter gilt am
      Endpunkt (Kegel, Uebergang): "cylinder|(x, y, z)|(x, y, z)|1.70|0.80"
      Ohne Eintrag nimmt die Mod alle Punkte des Modells bis 0,6 m Hoehe.

  tilt_cog[]: (x, y, z)     Schwerpunkt. Ohne Eintrag: Mitte des Modells.
                            Tief und weit innen = standfest, hoch und nah
                            an einer Kante = kippt frueh.

  sounds[]: "drop|/sound/your_mod/your.bank#your_event"
      Ton beim Rueckfall (FMOD-Event, Einmal-Sound, Parameter impact 0-1 =
      Haerte des Aufschlags, mass 0-1 = Gewicht / 20 t, aero_wnd 0-2 = Kabine
      zu/offen). "drop|-" = kein Ton. Ohne Eintrag:
      /sound/lphd/lashing.bank#cargo_drop. Auch .soundref ist moeglich.

  Mehrere Modelle in einem Match (mehrere data_path[]):
  Ohne Nummer gelten tilt[], tilt_base[], coll_base[], tilt_cog[] und sounds[] fuer
  Modelle des Match. Mit Nummer nur fuer das Modell an dieser Stelle in
  data_path[] (erstes = 0):
    tilt_base[0]: "area|(-1.08, -1.50)|(1.08, 5.80)"
    tilt_cog[0]: (0.00, 1.35, 1.80)
    sounds[0]: "drop|/sound/lphd/lashing.bank#cargo_drop"
    tilt[1]: false
  tilt[], tilt_cog[] und sounds[] mit Nummer ersetzen den Wert ohne Nummer.
  tilt_base und coll_base mit Nummer kommen dazu: alle Zeilen ohne Nummer
  und alle mit der Nummer des Modells gelten zusammen.


2. Zurrmittel
-------------
Eigene Datei im Ordner /def/vehicle, Name beginnt mit lashing_gear_data:

  /def/vehicle/lashing_gear_data.your_mod.v3def

In eckigen Klammern steht der Name der Einheit cargo_lashing_gear aus der
lashing_gear_data-Datei des Spiels bzw. der Mod (z. B. .strap, .chain).

  loosen_minutes[.your_strap]: 10
      Minuten harter Fahrt (summiert, z. B. Kurven mit etwa 4 m/s2 quer), bis
      sich das Zurrmittel lockert. Ohne Eintrag: Gurt 10, Kette 20.
      Dazu kommen je Zurrmittel eine Streuung, die Lage am Ladungsstueck, das
      Gewicht je Zurrmittel, die freie Laenge und der Winkel.

  lashing_capacity[.your_strap]: 2.5
      Zulaessige Zugkraft LC in t (Etikett in daN / 1000, z. B. LC 2500 daN
      = 2.5). Je staerker das Zurrmittel ausgelastet ist (Gewicht je
      Zurrmittel / LC), desto schneller lockert es sich. Ohne Eintrag:
      Gurt 2.5, Kette 6.3.

  sounds[.your_strap]: "loose|/sound/your_mod/your.bank#your_event"
      Ton des lockeren Zurrmittels (Mitte des Gurts), Schleife mit den
      Parametern aero_speed 0-200, aero_wnd 0-2, slack 0-1.
  sounds[.your_strap]: "rattle|/sound/your_mod/your.bank#your_event"
      Klappernde Ratsche bzw. Spanner, gleiche Parameter.

  "-" statt Pfad = kein Ton. Mehrere gleiche Namen: die Gurte wechseln sich
  ab. Ohne Eintrag: Gurt strap_noise + ratchet_rattle, Kette chain_noise
  (ohne eigenes Klappern), alle aus /sound/lphd/lashing.bank.

3. Antirutschmatten
-------------------
Fuer jede Aufstandsflaeche aus tilt_base[] rechnet die Mod: Wert des
Materials x Faktor des Ladebodens an dieser Stelle (Abschnitt 4). Liegt das
unter 0.60, bekommt die Flaeche eine Antirutschmatte. Ohne tilt_base[] gibt es
keine Matten.

  - Mit "Ladung selbst sichern" legt der Spieler die Matten vor dem Aufladen
    in einer eigenen Szene selbst (Symbol an jeder Flaeche). Ohne die Option,
    auf fertig beladenen Auftragsaufliegern und auf abgestellten Aufliegern
    legt die Mod sie selbst.
  - Matte: 8 mm dick, Reibwert 0.60 unabhaengig von Ladung und Boden. Die
    Ladung steht mit ihrer Unterkante auf der Matte; liegen nur unter einem
    Teil der Flaechen Matten, steht sie schraeg auf der Mattenkante.
  - Groesse: kleine Flaeche (beide Seiten bis 0.5 m) ganz; groessere Flaeche
    Stuecke von 0.3 m an den Ecken und alle 1.2 m entlang der Raender;
    single als Quadrat (Radius bis 0.25 m) bzw. Stuecke auf dem Kreis;
    ring Stuecke auf dem mittleren Radius alle 1.2 m.
  - Die Matten werden am Rand der Ladeflaeche abgeschnitten. Stuecke unter
    2 cm entfallen - single braucht dafuer einen Radius ab 0.01.

Tipp: Reifen und Gummiketten (rubber) brauchen keine Matte, Holzkufen und
Stahl auf Holz schon, auf Metallboden fast alles.


4. Ladeboden (Auflieger)
------------------------
Eigene Datei neben der Body-Datei des Aufliegers, gleicher Name mit .v3def
(ohne Body neben der Chassis-Datei):

  /def/vehicle/trailer_owned/your_trailer/body/your_body.sii
  -> /def/vehicle/trailer_owned/your_trailer/body/your_body.v3def

  floor: wood               Ladeboden: wood (Faktor 1.00), metal (0.70) oder
                            film (Siebdruck, 0.60). Standard: wood.
  floor[]: "metal|x1|x2"    Streifen mit anderem Boden ueber die ganze Laenge,
                            von x1 bis x2 quer in m (Auflieger-Koordinaten,
                            0 = Mitte). Mehrere Zeilen moeglich, z. B.
                            Stahlrahmen aussen und Holz dazwischen.

Der Faktor wird mit dem Wert des Materials der Aufstandsflaeche
multipliziert (Rutschen und Antirutschmatten).


5. Modelle der Zurrmittel (Haken, Ratsche, Spanner)
---------------------------------------------------
Damit Haken und Ratsche beim Sichern richtig sitzen, bekommt das Modell eine
Datei neben seiner .pmd, gleicher Name mit .v3def. Gemeint sind die Modelle,
die in der lashing_gear_data stehen (Haken Anfang, Haken Ende, Ratsche bzw.
Spanner):

  /vehicle/your_mod/lashing/your_hook.pmd
  -> /vehicle/your_mod/lashing/your_hook.v3def

Haken:

  lphd_lash_model : .hook {
      pivot: (0.0, 0.0, -0.025)     Drehpunkt: Stelle, mit der der Haken in
                                    der Oese bzw. am Zurrpunkt haengt
      tip: (0.0, -0.04, -0.03)      Spitze (wird gelesen, wirkt derzeit nicht)
      sounds[]: "hook|/sound/your_mod/your.bank#hook"
  }

Ratsche / Spanner:

  lphd_lash_model : .binder {
      in: (0.0, 0.0, 0.085)         Welle, auf die Gurt bzw. Kette laeuft
      fixed: (0.0, 0.0, 0.0)        Bolzen, an dem die Ratsche haengt
      contact: (0.0, -0.018, 0.042) Anlage: diese Seite liegt am Fahrzeug
                                    bzw. an der Ladung (ohne Eintrag:
                                    rundum gleich, z. B. Kettenspanner)
      lever: (0.0, 0.045, -0.092)   Ende des Hebels (Spannen)
      sounds[]: "ratchet_up|/sound/your_mod/your.bank#ratchet_up"
  }

  - Punkte in Metern im Raum des Modells, Schreibweise (x, y, z)
  - Ohne Datei bzw. ohne Punkte liegt das Modell so, wie das Spiel es setzt.
  - Fuer eine Ratsche braucht es in und fixed, sonst gilt sie als ohne Punkte.

Toene (sounds[]: "name|pfad", Pfad zu .soundref oder bank#event, "-" = kein
Ton, mehrere gleiche Namen: einer davon zufaellig). Ohne Eintrag ist es still.

  Haken      hook_in    einhaken            (sonst hook)
             hook_out   aushaken            (sonst hook)
             strap_throw / chain_throw   Gurt bzw. Kette ueberwerfen, am Haken
                        Ende (sonst throw)
  Ratsche    ratchet_up    Hebel hoch
             ratchet_down  Hebel runter, spannen (sonst tension)
             ratchet_open  oeffnen (sonst ratchet_up)

EN
==

1. Cargo model (cargo_model_match)
----------------------------------
Same folder and same name as the cargo_model_match file of the cargo, only
with .v3def:

  /def/vehicle/cargo/your_cargo/model_area.sii
  -> /def/vehicle/cargo/your_cargo/model_area.v3def

If there are several match files (e.g. model_area.sii and model_area_1.sii),
each one gets its own .v3def. All entries are optional; without the file the
defaults apply. An entry with a wrong format is listed as an error in the log
(file and value read), that line is then not used.

1a. Edge guards
---------------
  edge_guard: true          guards can be placed when securing by hand (default: false)
  edge_guard_width: 0.20    width of the guard in m, 0.01 - 2
                            (default: strap = strap width + 0.20, threaded
                            + 0.04; chain 0.20)
  edge_guard_leg: 0.10      leg length on each side of the edge in m, 0.005 - 1
                            (default: strap 0.10, threaded 0.05; chain 0.15)

1b. Wear at edges
-----------------
  edge_wear: 0.4            wear of the strap at an edge without guard,
                            0.0 - 1.0 (default 0.5). With a guard only a fifth
                            counts. Together with the give of the ratchet the
                            strap becomes loose (from 75 %).
  edge_crush: 0.5           crushing of the cargo at an edge without guard,
                            0.0 - 1.0 (default 0.5) - for a later version,
                            no effect yet.

1c. Tipping of loose cargo
--------------------------
If a lashing on a cargo piece is loose, the piece can tip in corners and when
braking - as far as the loose lashing lets it - and drops back with an impact.
A tight lashing on the piece holds it.
All values in model coordinates (m): x across, y up, z along.

  tilt[]: false            this cargo model never tips (e.g. very flat or
                            firmly chocked cargo). Default: true.

  tilt_base[]: "single|(x, z)|radius"
      One support point (wheel, foot, prop). Radius = half tyre or foot
      width, the contact reaches that far outwards (optional, default 0).
  tilt_base[]: "area|(x, z)|(x, z)"
      A support area: outer dimensions as two opposite corners
      (crate, pallet, frame, chocks).
  tilt_base[]: "ring|(x, z)|outer radius|inner radius|angle from|angle to"
      A ring or ring segment (upright pipe section, formwork, arch):
      circle centre, outer and inner radius, arc from - to in degrees
      (0 = towards +x, 90 = towards +z). Without angles: full ring.
      Example half ring over -x: "ring|(1.53, 0.0)|3.05|2.40|90|270"

  Several lines and all types can be mixed; the support area is the outline
  around all points. The piece tips about its edge.
  Without tilt_base[] the mod uses the lowest points of the model (mesh).

  Material or friction value (optional, first field of each tilt_base line):
  what the support area is made of. This gives the static friction on the
  deck (for sliding) and whether an anti-slip mat is needed there
  (section 3). Default 0.45.
      "material|single|(x, z)|radius"
      "material|area|(x, z)|(x, z)"
      "material|ring|(x, z)|outer radius|inner radius|angle from|angle to"
  Materials (value on a wooden deck):
      wood 0.50       sawn wood (beams, crates, skids)
      plastic 0.20    plastic
      metal 0.45      steel / metal
      concrete 0.55   concrete
      rubber 0.60     rubber (tyres, rubber tracks)
      straw 0.40      straw
  Instead of a material a number 0.01 - 1.5 works too (friction on a wooden
  deck). Guide values per EN 12195-1: planed wood 0.3, rough concrete 0.7.
  The value is combined with the deck of the trailer (section 4).
  Example wheel: tilt_base[]: "rubber|single|(-0.75, -0.40)|0.08"
  Example skid: tilt_base[]: "wood|area|(-1.15, -0.70)|(1.15, -0.60)"

  coll_base[]: "single|(x, y, z)|radius"
  coll_base[]: "area|(x, y, z)|(x, y, z)"
  coll_base[]: "cylinder|(x, y, z)|(x, y, z)|radius"
      parts that touch the deck when tipping (forks, bucket, attachment,
      overhang). Tipping stops there. single = point with radius,
      area = surface from two opposite corners (x, y, z). Height and width
      change evenly along the length (z): different heights = sloped. If the
      corners are left and right of the centre, the surface is a trapezoid
      symmetric to the centre (+-x at each end, e.g. wide and low at the
      fender, narrow and higher at the end of the box). If both are on the
      same side, it is a rectangle between them (e.g. mast beside the centre).
      cylinder = cylinder (boiler, pipe): centre of both end faces (start and
      end point) and radius. A second radius after it applies at the end point
      (cone, transition): "cylinder|(x, y, z)|(x, y, z)|1.70|0.80"
      Without entry the mod uses all model points up to 0.6 m height.

  tilt_cog[]: (x, y, z)     centre of gravity. Without entry: centre of the
                            model. Low and far inside = stable, high and close
                            to an edge = tips early.

  sounds[]: "drop|/sound/your_mod/your.bank#your_event"
      sound when dropping back (FMOD event, one-shot, parameters impact 0-1 =
      hardness of the impact, mass 0-1 = weight / 20 t, aero_wnd 0-2 = cabin
      closed/open). "drop|-" = no sound. Without entry:
      /sound/lphd/lashing.bank#cargo_drop. .soundref is possible too.

  Several models in one match (several data_path[]):
  Without a number, tilt[], tilt_base[], coll_base[], tilt_cog[] and sounds[] apply to
  models of the match. With a number only to the model at that position in
  data_path[] (first = 0):
    tilt_base[0]: "area|(-1.08, -1.50)|(1.08, 5.80)"
    tilt_cog[0]: (0.00, 1.35, 1.80)
    sounds[0]: "drop|/sound/lphd/lashing.bank#cargo_drop"
    tilt[1]: false
  tilt[], tilt_cog[] and sounds[] with a number replace the value without.
  tilt_base and coll_base with a number are added: all lines without a
  number and all with the model's number apply together.


2. Lashing gear
---------------
Own file in the folder /def/vehicle, name starts with lashing_gear_data:

  /def/vehicle/lashing_gear_data.your_mod.v3def

In square brackets the name of the cargo_lashing_gear unit from the
lashing_gear_data file of the game or the mod (e.g. .strap, .chain).

  loosen_minutes[.your_strap]: 10
      minutes of hard driving (summed, e.g. corners with about 4 m/s2
      lateral) until the lashing loosens. Without entry: strap 10, chain 20.
      Added per lashing: a spread, the position on the cargo piece, the
      weight per lashing, the free length and the angle.

  lashing_capacity[.your_strap]: 2.5
      lashing capacity LC in t (label in daN / 1000, e.g. LC 2500 daN
      = 2.5). The more the lashing is loaded (weight per lashing / LC),
      the faster it loosens. Without entry: strap 2.5, chain 6.3.

  sounds[.your_strap]: "loose|/sound/your_mod/your.bank#your_event"
      sound of the loose lashing (middle of the strap), loop with the
      parameters aero_speed 0-200, aero_wnd 0-2, slack 0-1.
  sounds[.your_strap]: "rattle|/sound/your_mod/your.bank#your_event"
      rattling ratchet or tensioner, same parameters.

  "-" instead of a path = no sound. Several equal names: the straps take
  turns. Without entry: strap strap_noise + ratchet_rattle, chain chain_noise
  (no separate rattle), all from /sound/lphd/lashing.bank.

3. Anti-slip mats
-----------------
For each support area from tilt_base[] the mod calculates: value of the
material x factor of the deck at that spot (section 4). Below 0.60 the area
gets an anti-slip mat. Without tilt_base[] there are no mats.

  - With "secure cargo yourself" the player lays the mats before loading in
    a separate scene (marker at each area). Without the option, on pre-loaded
    job trailers and on parked trailers the mod lays them itself.
  - Mat: 8 mm thick, friction 0.60 regardless of cargo and deck. The cargo
    stands with its underside on the mat; if only some areas have mats, it
    rests tilted on the mat edge.
  - Size: small area (both sides up to 0.5 m) completely; larger area pieces
    of 0.3 m at the corners and every 1.2 m along the edges; single as a
    square (radius up to 0.25 m) or pieces on the circle; ring pieces on the
    middle radius every 1.2 m.
  - Mats are cut off at the edge of the deck. Pieces under 2 cm are left
    out - single needs a radius of at least 0.01 for that.

Tip: tyres and rubber tracks (rubber) need no mat, wooden skids and steel on
wood do, on a metal deck almost everything does.


4. Deck (trailer)
-----------------
Own file next to the body file of the trailer, same name with .v3def
(without a body next to the chassis file):

  /def/vehicle/trailer_owned/your_trailer/body/your_body.sii
  -> /def/vehicle/trailer_owned/your_trailer/body/your_body.v3def

  floor: wood               deck: wood (factor 1.00), metal (0.70) or film
                            (film-faced plywood, 0.60). Default: wood.
  floor[]: "metal|x1|x2"    strip with a different deck over the full length,
                            from x1 to x2 across in m (trailer coordinates,
                            0 = centre). Several lines possible, e.g. steel
                            frame outside and wood in between.

The factor is multiplied with the value of the material of the support area
(sliding and anti-slip mats).


5. Models of the lashing gear (hook, ratchet, tensioner)
--------------------------------------------------------
So that hook and ratchet sit correctly when securing, the model gets a file
next to its .pmd, same name with .v3def. These are the models named in the
lashing_gear_data (hook at the start, hook at the end, ratchet or tensioner):

  /vehicle/your_mod/lashing/your_hook.pmd
  -> /vehicle/your_mod/lashing/your_hook.v3def

Hook:

  lphd_lash_model : .hook {
      pivot: (0.0, 0.0, -0.025)     pivot: the point with which the hook hangs
                                    in the eye or at the lashing point
      tip: (0.0, -0.04, -0.03)      tip (read, currently without effect)
      sounds[]: "hook|/sound/your_mod/your.bank#hook"
  }

Ratchet / tensioner:

  lphd_lash_model : .binder {
      in: (0.0, 0.0, 0.085)         shaft the strap or chain runs onto
      fixed: (0.0, 0.0, 0.0)        bolt the ratchet hangs on
      contact: (0.0, -0.018, 0.042) contact: this side rests against the
                                    vehicle or the cargo (without entry:
                                    the same all round, e.g. chain tensioner)
      lever: (0.0, 0.045, -0.092)   end of the lever (tensioning)
      sounds[]: "ratchet_up|/sound/your_mod/your.bank#ratchet_up"
  }

  - points in metres in the space of the model, written as (x, y, z)
  - without a file or without points the model lies as the game sets it
  - a ratchet needs in and fixed, otherwise it counts as without points

Sounds (sounds[]: "name|path", path to a .soundref or bank#event, "-" = no
sound, several equal names: one of them at random). Without entry it is
silent.

  hook       hook_in    hooking in          (otherwise hook)
             hook_out   unhooking           (otherwise hook)
             strap_throw / chain_throw   throwing the strap or chain over, at
                        the end hook (otherwise throw)
  ratchet    ratchet_up    lever up
             ratchet_down  lever down, tensioning (otherwise tension)
             ratchet_open  opening (otherwise ratchet_up)
