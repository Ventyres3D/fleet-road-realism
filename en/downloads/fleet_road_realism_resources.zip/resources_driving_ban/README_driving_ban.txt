Fleet & Road Realism - Lkw-Fahrverbote (.v3def) / truck driving bans (.v3def)
=============================================================================

Fahrverbote, Ausnahmen und Bussgelder stehen in kleinen .v3def-Dateien neben den
Dateien, die das Spiel ohnehin laedt: je Land, je Stadt und je Fracht. Damit
koennen Karten- und Fracht-Mods eigene Laender, Staedte und Frachten mitbringen.
Die Beispiele im Ordner def/ dieses Pakets zeigen das Format.

Driving bans, exemptions and fines live in small .v3def files next to the files
the game already loads: per country, per city and per cargo. Map and cargo mods
can bring their own countries, cities and cargo this way. The examples in the
def/ folder of this package show the format.

DE
==

1. Wo die Dateien liegen
------------------------
  Land:   /def/country/<land>.v3def        (<land> = Token des Landes, z. B. germany)
  Stadt:  /def/city/<stadt>.v3def          (<stadt> = Token der Stadt, z. B. warszawa)
  Fracht: /def/cargo/<fracht>.v3def        (<fracht> = Token der Fracht)

Steht in einer Land-v3def schon etwas (z. B. driver_wage), kommen die Bloecke
einfach darunter. Fehlt eine Datei, gilt dort kein Verbot - das ist kein Fehler.
Eine Zeile mit falschem Format steht als Fehler im Log (Datei, Zeile, gelesener
Wert) und wird nicht verwendet.

2. Verbotsbloecke
-----------------
Drei Arten, jede darf mehrmals vorkommen:
  driving_ban           gilt fuer alle Lkw
  driving_ban_adr       nur Gefahrgut (Fracht mit ADR-Klasse)
  driving_ban_oversize  nur Sondertransporte (Schwerlast-Auftraege)

Aufbau wie die Oeffnungszeiten der Firmen: ein Tag je Zeile, ein oder mehrere
Zeitfenster (hh.mm, hh.mm). Ein Tag, der fehlt, hat kein Verbot. Ein Verbot ueber
Mitternacht wird auf beide Tage aufgeteilt (saturday bis 24.00, sunday ab 00.00).
  Tage: monday tuesday wednesday thursday friday saturday sunday

Zusaetzliche Zeilen im Block (alle optional):
  transit: true       gilt nur fuer die Durchfahrt. Wer im Land / in der Stadt
                      be- oder entlaedt (Absender oder Ziel des Auftrags), ist frei,
                      ebenso die Fahrt hinaus nach dem Entladen und die Fahrt zur
                      eigenen Garage dort.
  inbound: true       gilt nur, wenn die Stadt das Ziel des Auftrags ist
  to: <land>          gilt nur, wenn das Zielland des Auftrags passt (z. B. france)
  rural: true         gilt nur ausserhalb von Staedten
  tractor_solo: true  Zugmaschine ohne Auflieger ist frei
  min_cargo: 1500     gilt erst ab dieser Ladung in kg
  share: 50           eine Ausnahme (exempt) zaehlt erst, wenn die ausgenommene
                      Fracht mindestens so viel Prozent der Ladung ausmacht
                      (Mischladungen)
  combined: 150       kombinierter Verkehr: Container-Chassis mit einer Firma mit
                      Reach Stacker (container_load: true) als Absender oder Ziel
                      ist bis zu dieser Entfernung (km Luftlinie) frei

Ausgenommene Frachtkategorien als eigener Block, ein Eintrag je Zeile:
  exempt :
  {
  milk
  meat
  }

Bussgeld als eigener Block im Verbotsblock:
  fine :
  {
  driver: 250 750       Fahreranteil in EUR; mehrere Werte = 1., 2. Verstoss
  holder: 3750          Halteranteil in EUR (eigener Lkw), ebenso gestaffelt
  by_time: true         optional: Werte gelten nach gefahrener Dauer im Verbot
                        (bis 1 h, bis 2 h, darueber) statt nach Verstoss
  }
Ein Wert gilt fuer jeden Verstoss. Hat ein Verbotsblock einer Stadt keinen
fine-Block, gilt der fine-Block des Landes fuer dieselbe Art (driving_ban,
_adr, _oversize). Im Fahrerjob zahlt man nur den Fahreranteil, mit eigenem Lkw
beide Anteile.

Stadt-Bloecke ersetzen fuer diese Stadt die Landes-Bloecke derselben Art.

3. Frachtkategorien (Fracht-v3def)
----------------------------------
Je Kategorie eine Zeile:
  ban_class[]: milk
  ban_class[]: perishable

Kategorien:
  perishable     verderbliche Lebensmittel allgemein
  milk           Milch und Milcherzeugnisse
  meat           Fleisch und Fleischerzeugnisse
  fish           Fisch und Fischerzeugnisse
  fruit_veg      Obst und Gemuese
  bakery         frische Backwaren
  livestock      lebende Tiere
  flowers        Schnittblumen und Pflanzen
  post           Post und Presse
  medical        Medizin und Krankenhausbedarf
  fuel           Kraftstoff fuer Tankstellen
  gas_supply     Heiz- und Medizingas
  construction   Baustellengueter (Stahl, Beton, Bitumen)
  event          Veranstaltungsmaterial
  removal        Umzugsgut
  animal_byprod  tierische Nebenprodukte
Milch, Fleisch, Fisch, Obst/Gemuese und Backwaren bekommen zusaetzlich
perishable, weil manche Laender nur "verderbliche Lebensmittel" nennen.
Leerfahrten zu einer vorgemerkten / gebuchten ausgenommenen Fracht und nach dem
Entladen einer ausgenommenen Fracht sind frei.

EN
==

1. Where the files go
---------------------
  Country: /def/country/<country>.v3def   (<country> = country token, e.g. germany)
  City:    /def/city/<city>.v3def         (<city> = city token, e.g. warszawa)
  Cargo:   /def/cargo/<cargo>.v3def       (<cargo> = cargo token)

If a country .v3def already holds entries (e.g. driver_wage), simply add the
blocks below them. A missing file means no ban there - that is not an error.
A line with a wrong format is logged as an error (file, line, value read) and
is not used.

2. Ban blocks
-------------
Three kinds, each may appear more than once:
  driving_ban           applies to all trucks
  driving_ban_adr       dangerous goods only (cargo with an ADR class)
  driving_ban_oversize  special transports only (heavy haulage jobs)

Same layout as the companies' opening hours: one day per line, one or more
time windows (hh.mm, hh.mm). A missing day has no ban. A ban across midnight is
split over both days (saturday until 24.00, sunday from 00.00).
  Days: monday tuesday wednesday thursday friday saturday sunday

Extra lines in the block (all optional):
  transit: true       applies to through traffic only. Loading or unloading in
                      the country / city (sender or target of the job) is free,
                      so is driving out after unloading and to your own garage
                      there.
  inbound: true       applies only if the city is the job's target
  to: <country>       applies only if the job's target country matches
  rural: true         applies only outside cities
  tractor_solo: true  a tractor without trailer is free
  min_cargo: 1500     applies only from this cargo mass in kg
  share: 50           an exemption only counts if the exempt cargo makes up at
                      least this percentage of the load (mixed loads)
  combined: 150       combined transport: a container chassis with a company
                      that has a reach stacker (container_load: true) as sender
                      or target is free up to this distance (km straight line)

Exempt cargo categories as their own block, one entry per line:
  exempt :
  {
  milk
  meat
  }

Fine as its own block inside the ban block:
  fine :
  {
  driver: 250 750       driver's share in EUR; several values = 1st, 2nd offence
  holder: 3750          holder's share in EUR (own truck), tiered the same way
  by_time: true         optional: values follow the time driven during the ban
                        (up to 1 h, up to 2 h, above) instead of the offence
  }
One value applies to every offence. If a city's ban block has no fine block,
the country's fine block of the same kind (driving_ban, _adr, _oversize)
applies. In a driver job you only pay the driver's share, with your own truck
both shares.

City blocks replace the country blocks of the same kind for that city.

3. Cargo categories (cargo .v3def)
----------------------------------
One line per category:
  ban_class[]: milk
  ban_class[]: perishable

Categories:
  perishable     perishable food in general
  milk           milk and dairy products
  meat           meat and meat products
  fish           fish and fish products
  fruit_veg      fruit and vegetables
  bakery         fresh bakery products
  livestock      live animals
  flowers        cut flowers and plants
  post           mail and press
  medical        medicine and hospital supplies
  fuel           fuel for filling stations
  gas_supply     heating and medical gas
  construction   building site goods (steel, concrete, bitumen)
  event          event equipment
  removal        household removals
  animal_byprod  animal by-products
Milk, meat, fish, fruit/vegetables and bakery products also get perishable,
because some countries only name "perishable food".
Empty runs to a reserved / booked exempt cargo and after unloading an exempt
cargo are free.
