Fleet & Road Realism - Frachtdaten (.v3def) / cargo data (.v3def)
=================================================================

Kleine optionale Dateien legen je Fracht einen Zuschlag fest und wie die Fracht
bei Teilladungen behandelt wird. Sie liegen neben den Fracht-Dateien des Spiels.
Small optional files set a surcharge per cargo and how the cargo is handled in
partial loads. They sit next to the cargo files of the game.


DE
==

1. Datei
--------
Gleicher Ordner und gleicher Name wie die Fracht, nur mit .v3def:

  /def/cargo/<fracht>.v3def        z. B. /def/cargo/fuel_oil.v3def

Alle Zeilen sind optional. Ohne Datei verhaelt sich die Fracht wie im Spiel.


2. Lohn
-------
Frachtauftraege (eigener Lkw + Auftragsauflieger) werden wie echte Traktion bezahlt:
  - bis 150 km 1,90 EUR/km, 150-400 km gleitend, ab 400 km 1,53 EUR/km
  - mindestens 80 EUR/h x (Fahrzeit + 1 h)
  - Frachtmarkt (eigener Auflieger) +20 %
  - Dringlichkeit wie delivery_window_coef in economy_data.sii


3. Zuschlag
-----------
  surcharge: 25                    Prozent auf den Frachtpreis

  - ohne Datei oder ohne Zeile: kein Zuschlag
  - Leerfahrten bekommen keinen Zuschlag
  - mitgeliefert: alle ADR-Frachten des Spiels
    (Klasse 1: 30 %, Klasse 2 und 3: 25 %, Klasse 4, 6 und 8: 15 %)


4. Teilladungen (Frachtmarkt, eigener Auflieger)
------------------------------------------------
  load_unit: pallet                single | pallet | whole

  - whole          = nur als Komplettladung, nie als Teilladung
  - single, pallet = Teilladung erlaubt (Stueckgut bzw. Paletten)
  - ohne Zeile     = Teilladung erlaubt, wenn die Firmen es zulassen
                     (units_out / units_in, siehe README_company_data)

Lohn einer Teilladung: Palettensatz (Europa-Durchschnitt) nach Entfernung.
  - Paletten = Anteil am Auflieger x 34
  - bis 5 Paletten:  100 / 150 / 215 / 265 EUR bei 100 / 350 / 650 / 1200 km
  - ab 15 Paletten:   70 / 105 / 150 / 190 EUR bei 100 / 350 / 650 / 1200 km
  - dazwischen gleitend, ueber 1200 km weiter steigend
  - hoechstens die Pauschale der vollen Ladung
  - Dringlichkeit und surcharge gelten wie bei der vollen Ladung

Wartezeit beim Laden und Entladen: anteilig zur Menge, mindestens 10 Minuten.


5. Vertraeglichkeit (Zuladen, Tourplanung)
------------------------------------------
  temp: 2;8                        Temperaturbereich von;bis in Grad C
  food: true                       Lebensmittel

In einem Auflieger zusammen nur, was zusammenpasst:
  - Temperaturbereiche muessen sich ueberschneiden (ohne temp-Zeile passt alles)
  - Lebensmittel/Futtermittel nie mit giftiger Fracht (ADR-Klasse 6, CV28)
    (ADR-Klasse aus der Fracht-.sui des Spiels, adr_class)
  - Explosivstoffe (ADR-Klasse 1) nie mit anderem Gefahrgut, mit normaler
    Fracht erlaubt (ADR 7.5.2.1)
  - ADR-Klassen 2 bis 8 untereinander frei


6. Ladungsmodell, Zurren und Verladen
-------------------------------------
  lashing_method: direct           direct | top_over
  lash_through: true               true | false
  ramp: true                       true | false
  volume: 15.6                     Volumen je Einheit in m3
  unit_volume_factor: 0.1667       Faktor je Ladungsmodell

  - lashing_method: Zurrart der Fracht (direct = Direktzurren an der Ladung,
    top_over = Niederzurren ueber die Ladung). Ersetzt die Zurrart aus den
    cargo_model_match-Dateien der Fracht.
  - lash_through: true = der Gurt laeuft durch die Ladung (beim Sichern von
    Hand), z. B. bei Rohren oder Rollen.
  - ramp: true = die Fracht kommt ueber die Rampe auf den Auflieger
    (selbstfahrend oder rollbar). Bei gemischten Ladungen nur auf Tiefbett-
    Aufliegern, nie mit Schwanenhals.
  - volume: ersetzt das Volumen je Einheit aus der Fracht-Definition des
    Spiels.
  - unit_volume_factor: ersetzt den Faktor aus dem cargo_model_match. Kleiner
    als 1 heisst: ein Ladungsmodell sind 1 / Faktor Einheiten (0.1667 = 6
    Einheiten). Teilladungen gibt es dann nur in ganzen Ladungsmodellen.


7. Format
---------
  schluessel: wert

  - ein Eintrag je Zeile, Leerzeichen um den Doppelpunkt erlaubt
  - Zeilen mit # oder // am Anfang sind Kommentare, ein # nach dem Wert auch
  - Zahlen mit Dezimalpunkt, keine Einheiten in der Zeile
  - eine Zeile mit falschem Wert steht im game.log und wird ignoriert


EN
==

1. File
-------
Same folder and same name as the cargo, only with .v3def:

  /def/cargo/<cargo>.v3def         e.g. /def/cargo/fuel_oil.v3def

All lines are optional. Without a file the cargo behaves as in the game.


2. Pay
------
Freight jobs (own truck + job trailer) are paid like real traction:
  - up to 150 km 1.90 EUR/km, 150-400 km sliding, from 400 km 1.53 EUR/km
  - at least 80 EUR/h x (driving time + 1 h)
  - cargo market (own trailer) +20 %
  - urgency as delivery_window_coef in economy_data.sii


3. Surcharge
------------
  surcharge: 25                    percent on the freight price

  - no file or no line: no surcharge
  - empty runs get no surcharge
  - included: all ADR cargoes of the game
    (class 1: 30 %, classes 2 and 3: 25 %, classes 4, 6 and 8: 15 %)


4. Partial loads (cargo market, own trailer)
--------------------------------------------
  load_unit: pallet                single | pallet | whole

  - whole          = full load only, never a partial load
  - single, pallet = partial loads allowed (piece goods or pallets)
  - no line        = partial loads allowed if the companies allow them
                     (units_out / units_in, see README_company_data)

Pay of a partial load: pallet rate (European average) by distance.
  - pallets = share of the trailer x 34
  - up to 5 pallets:  100 / 150 / 215 / 265 EUR at 100 / 350 / 650 / 1200 km
  - from 15 pallets:   70 / 105 / 150 / 190 EUR at 100 / 350 / 650 / 1200 km
  - sliding in between, rising further beyond 1200 km
  - at most the flat rate of the full load
  - urgency and surcharge apply as for the full load

Waiting time for loading and unloading: in proportion to the amount, at least
10 minutes.


5. Compatibility (adding cargo, tour planning)
----------------------------------------------
  temp: 2;8                        temperature range from;to in degrees C
  food: true                       food

Only what fits together goes into one trailer:
  - temperature ranges must overlap (no temp line = fits everything)
  - food/feed never together with toxic cargo (ADR class 6, CV28)
    (ADR class from the game's cargo .sui, adr_class)
  - explosives (ADR class 1) never with other dangerous goods, allowed with
    normal cargo (ADR 7.5.2.1)
  - ADR classes 2 to 8 freely with each other


6. Cargo model, lashing and loading
-----------------------------------
  lashing_method: direct           direct | top_over
  lash_through: true               true | false
  ramp: true                       true | false
  volume: 15.6                     volume per unit in m3
  unit_volume_factor: 0.1667       factor per cargo model

  - lashing_method: lashing method of the cargo (direct = direct lashing at
    the cargo, top_over = tie-down over the cargo). Replaces the method of
    the cargo_model_match files of the cargo.
  - lash_through: true = the strap runs through the cargo (when securing by
    hand), e.g. for pipes or coils.
  - ramp: true = the cargo goes onto the trailer over the ramp (self-driving
    or rollable). In mixed loads only on low-bed trailers, never with a
    gooseneck.
  - volume: replaces the volume per unit of the game's cargo definition.
  - unit_volume_factor: replaces the factor of the cargo_model_match. Below 1
    means: one cargo model is 1 / factor units (0.1667 = 6 units). Partial
    loads then come only in whole cargo models.


7. Format
---------
  key: value

  - one entry per line, spaces around the colon are allowed
  - lines starting with # or // are comments, a # after the value too
  - numbers with decimal point, no units on the line
  - a line with a wrong value is reported in game.log and ignored
