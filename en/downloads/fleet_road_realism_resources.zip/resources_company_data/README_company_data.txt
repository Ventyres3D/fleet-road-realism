Fleet & Road Realism - Firmen- und Containerdaten (.v3def) / company and container data (.v3def)
===============================================================================================

Kleine optionale Dateien sagen der Mod, wann eine Firma offen ist, ob sie einen
Reachstacker fuer Container hat und was eine Containerfracht ist. Sie
funktionieren mit jeder Karte und jeder Fracht-Mod: die Dateien liegen neben den
Dateien, die das Spiel ohnehin laedt. Die Beispiele im Ordner def/ dieses Pakets
zeigen das Format.

Small optional files tell the mod when a company is open, whether it has a
reach stacker for containers, and what a container cargo is. They work for
every map and every cargo mod: the files sit next to the files the game
already loads. The examples in the def/ folder of this package show the format.


DE
==

1. Firmen-Dateien
-----------------
Gleicher Ordner und gleicher Name wie die Firmen-Dateien des Spiels, nur mit .v3def:

  alle Staedte  /def/company/your_company.sui
             -> /def/company/your_company.v3def

  eine Stadt    /def/company/your_company/editor/your_city.sii
             -> /def/company/your_company/editor/your_city.v3def

Der Name der Stadt-Datei ist das Stadt-Token (Name der Editor-Datei bis zum
ersten Punkt). Eine Stadt-Datei ersetzt in dieser Stadt die Oeffnungszeiten der
Firmen-Datei, und eine container_load-Zeile in einer Stadt-Datei gilt nur fuer
diese Stadt (z. B. eine Firma, die nur an einem Standort einen Reachstacker hat).


1a. Oeffnungszeiten
-------------------
  working_time :
  {
  monday: (06.00, 22.00)
  saturday: (07.00, 12.00);(13.00, 16.00)
  sunday: closed
  }

  - Tage: monday tuesday wednesday thursday friday saturday sunday
  - eine oder mehrere Zeitspannen (hh.mm, hh.mm), mehrere getrennt durch ;
  - 24.00 = Ende des Tages; ein Ende vor oder gleich dem Anfang laeuft ueber
    Mitternacht, z. B. (22.00, 06.00)
  - closed = ganzen Tag geschlossen
  - fehlender Tag = ganzen Tag offen
  - keine Datei oder kein working_time-Block = die Firma ist immer offen

Solange eine Firma geschlossen ist, sind ihre Angebote ausgeblendet, es wird
dort keine neue Fracht erzeugt, und ihr Firmenpunkt zeigt "geschlossen" mit den
Oeffnungszeiten.

Schwertransporte (oversize) koennen in derselben Datei eigene Zeiten haben:

  working_time_oversize :
  {
  monday: (07.00, 16.00)
  saturday: closed
  sunday: closed
  }

  - gleiches Format wie working_time
  - gilt fuer das Laden (Start) und Entladen (Ziel) von Schwertransporten;
    fehlender Block = working_time gilt
  - ein Schwertransport-Angebot erscheint nur, wenn es jetzt geladen, gefahren
    (50 km/h im Schnitt, hoechstens 10 h Fahrt je 24 h, 45 min Pause nach
    4,5 h) und in diesen Zeiten vor Freitag 15:00 entladen werden kann (keine
    Schwertransporte Fr 15:00 - Mo 09:00)


1b. Reachstacker (Container)
----------------------------
  container_load: true     Reachstacker: Containerfracht wird an eigene
                           Container-Chassis vergeben, ein Container wird beim
                           Abliefern abgehoben
  container_load: false    kein Reachstacker: keine Containerfracht fuer
                           eigene Container-Chassis, der Container bleibt auf
                           dem Chassis

Firmen ohne die Zeile: der Frachtmarkt bleibt unveraendert; beim Abliefern
gilt die Firma als ohne Reachstacker (Container bleibt).

Was mit einem eigenen Container-Chassis passiert:
- Ein Container wird nur dort auf- und abgesetzt, wo die Firma einen
  Reachstacker hat.
- Bei einer Firma ohne Reachstacker abgeliefert, bleibt der Container auf dem
  Chassis. Das Chassis arbeitet dann wie der Aufliegertyp des Containers
  (siehe 2.), mit Leergewicht und Innenvolumen des Containers, und der
  Frachtmarkt bietet Fracht fuer diesen Aufliegertyp an.
- Direkt nach dem Entladen dort bietet der Frachtmarkt dieser Firma auch
  "Leercontainer" zurueck zu einer der 10 naechsten Firmen mit Reachstacker
  an: wenig Lohn, kein Beladen. Das Angebot gilt, solange der Lkw auf dem
  Firmenhof bleibt.
- Eine Fracht, die im Container zu einer Firma mit Reachstacker gefahren
  wird, nimmt den Container vom Chassis.


1c. Frachtfilter
----------------
Bloecke mit einer Fracht je Zeile, geschrieben als cargo_data-Name des Spiels
(cargo.<name>, wie in der Fracht-.sui):

  ignore_in :                  Fracht, die die Firma nie annimmt
  {                            (Frachtmarkt und Auflieger-Auftraege)
  cargo.air_mails
  }
  ignore_out :                 Fracht, die die Firma nie verschickt
  { ... }

  freight_market: false        keine Frachtmarkt-Angebote fuer eigene Auflieger
                               bei dieser Firma ("Frachtmarkt" / "Externer
                               Frachtmarkt"); die Firma laedt auch nie Fracht
                               auf einen Auflieger, der nicht ihr eigener ist
  freight_market_ignore_in : { ... }    nur fuer den Frachtmarkt
  freight_market_ignore_out : { ... }

  semi_trailerjob_in: false    keine Auflieger-Auftraege ("Frachtauftraege",
  semi_trailerjob_out: false   Auflieger wird gestellt) zu / von dieser Firma
  semi_trailerjob_ignore_in : { ... }   nur fuer Auflieger-Auftraege
  semi_trailerjob_ignore_out : { ... }

  - fuer freight_market / semi_trailerjob_in / _out ist nur false erlaubt;
    fehlende Zeile = das Spiel listet vollstaendig
  - die Filter addieren sich (z. B. ignore_out und
    semi_trailerjob_ignore_out)
  - was bei einer Firma ankommt, entscheiden nur ihr in-Ordner im Spiel und
    diese Filter


1d. Auflieger-Auftraege: was am Ziel passiert (Rueckfahrten)
------------------------------------------------------------
Bei Auflieger-Auftraegen entscheidet die Zielfirma je Aufbau des Aufliegers,
was nach der Ankunft passiert:

  semi_trailerjob_return_full :    entladen, Rueckfracht bei dieser Firma
  {                                laden, zurueck zum Absender
  curtainside
  dryvan
  }
  semi_trailerjob_return_empty :   nur entladen; die Rueckfracht wird bei der
  {                                naechsten passenden Firma geladen (zuerst
  fueltank                         in der Stadt, sonst ausserhalb), sonst leer
  lowbed                           zurueck
  }
  semi_trailerjob_drop: true       reiner Abstellplatz (z. B. unbegleitete
                                   Auflieger fuer Faehre oder Bahn): jeder
                                   Auflieger wird nur abgestellt, der Auftrag
                                   endet dort
  trailer_hub: true                Umschlagplatz (Bahn- oder Faehrterminal):
                                   nimmt als ABSENDER beladene Auflieger
                                   zurueck, die Rueckfracht muss nicht in
                                   seiner in-Liste stehen

Aufbau ohne Eintrag:
  curtainside, dryvan, refrigerated, insulated, flatbed, container,
  flatbed_cont = return_full; jeder andere Aufbau (Tanks, Silo, Kipper,
  Tieflader, Holz, Viehtransporter, Autotransporter ...) = return_empty.
Faustregel: return_full fuer einen Spezialaufbau nur dort, wo die Firma diesen
Aufbau selbst belaedt (Steinbruch - Kipper, Saegewerk - Holz, Autoterminal -
Autotransporter); Tieflader immer return_empty.

Rueckfracht:
  - geladen, wie der Frachtmarkt des Spiels einen Auflieger belaedt, der nicht
    der Firma gehoert: die Fracht muss zum Auflieger passen (Aufbau, Volumen,
    Gewicht), die ladende Firma muss sie verschicken duerfen (ignore_out,
    freight_market-Regeln; semi_trailerjob_out gilt nicht, die Firma laedt
    nur), der Absender muss sie annehmen (seine in-Liste, ignore_in,
    semi_trailerjob-Regeln), ausser der Absender ist ein trailer_hub
  - zufaellig nach den Frachtgewichtungen des Spiels gewaehlt, fest je Angebot
  - Container: ladende Firma mit container_load: true - der Container wird
    abgehoben und jede Containerfracht kommt aufs Chassis; mit
    container_load: false - der Container bleibt, ein Koffercontainer wird mit
    Fracht seines Aufbaus beladen, ein Spezialcontainer (body_type =
    Frachtname, siehe Abschnitt 2) nur mit dieser Fracht
  - die Zielfirma gibt nie die Fracht zurueck, die sie gerade bekommen hat
  - die ganze Fahrt ist ein Auftrag: eine Lieferzeit beim Absender, bezahlt
    beim Absender: Hinfracht + Rueckfracht; eine Leerfahrt (Ziel - ladende
    Firma, oder leer zurueck) wird wie ein Leercontainer bezahlt: 10 % der
    Einheiten der Hinfracht je km

Die Auftragsliste zeigt die Fahrt als Start > Ziel > (2. Firma >) Start, die
Rueckfracht blau nach der Hinfracht, dazu Gesamtstrecke, -zeit und -lohn. Eine
Stadt-Datei kann dieselben Zeilen fuer eine Stadt enthalten (ein Block in der
Stadt-Datei geht fuer seine Aufbauten vor).


1e. Wartezeiten
---------------
  wait_time :
  {
  load: 30-180
  unload: 30-180
  pickup: 5-20
  drop: 5-15
  }
  wait_factors :
  {
  1.5 : (06.00, 08.00);(12.00, 13.00)
  0.7 : (22.00, 06.00)
  }

  - load = Beladen, unload = Entladen, pickup = Uebernahme eines
    vorbereiteten, beladenen Aufliegers, drop = Abstellen des Aufliegers an
    einem reinen Abstellplatz (T)
  - Minuten von-bis; bei jeder Anmeldung wird eine Zeit dazwischen gewuerfelt
  - wait_factors: Faktor = Zeitspannen (hh.mm oder hh:mm), mehrere Spannen
    mit demselben Faktor getrennt durch ;  ein Ende vor oder gleich dem
    Anfang laeuft ueber Mitternacht; ausserhalb aller Spannen ist der Faktor
    1.0
  - fehlende Zeile oder fehlender Block: Stadt-Datei, dann Firmen-Datei, dann
    Standard: load/unload 30-180, pickup 5-20, drop 5-15, Faktoren
    06-10 x1.5, 16-22 x0.7, 22-06 x0.5

Die Wartezeit liegt zwischen dem Bestaetigen (Wahl der Parkschwierigkeit beim
Abliefern, Enter an der Lade-/Abladespur mit eigenem Auflieger oder die
Lade-Kachel) und der Freigabe von Spur bzw. Auflieger. Bei der Anmeldung zeigt
eine Meldung die erwartete Zeit. Verlassen des Firmengelaendes hebt die
Anmeldung auf. Waehrend des Wartens auf dem Gelaende anhalten und den Motor
abstellen: ein Hinweis bietet eine Pause bis zum Ende der Wartezeit an. Bei der
Freigabe geht alles von selbst weiter.


1f. Spuren je Aufbau (Parkschwierigkeit)
----------------------------------------
Eine Firma kann Spuren einer Schwierigkeit fuer bestimmte Aufbauten sperren,
z. B. keine Tieflader an den Laderampen (schwere Spuren):

  lanes_hard_ignore :          Aufbauten (body_type des Aufliegers, ohne
  {                            Praefix), die nie auf einer schweren Spur
  lowbed                       laden oder entladen
  lowboy
  }
  lanes_medium_ignore : { ... }   dasselbe fuer mittlere Spuren
  lanes_easy_ignore : { ... }     dasselbe fuer leichte Spuren

  - gilt fuer jede Auftragsart bei dieser Firma: Frachtmarkt,
    Fahrerauftraege, Auflieger-Auftraege und Rueckfracht
  - Beladen: liegt die Ladespur des Auftrags auf einer gesperrten
    Schwierigkeit, bekommt der Auftrag eine freie erlaubte Ladespur der Firma
    (passende Laenge, nicht belegt); gibt es keine, bleibt die Spur des
    Spiels
  - Entladen: gesperrte Schwierigkeiten sind nicht waehlbar
  - Frachtmarkt: hat die ladende Firma keine erlaubte Ladespur oder das Ziel
    keine erlaubte Abladespur fuer den Auflieger, gibt es kein Angebot dafuer
  - es zaehlt der Aufbau des angekuppelten Aufliegers
  - fest in der DLL, bei allen Firmen: Tieflader (lowbed, lowboy) nur an
    leichten Spuren; mittlere, schwere und Ladestellen ohne Schwierigkeit
    (z. B. Rampen) sind fuer sie immer gesperrt; ausgenommen Umschlagplaetze
    (trailer_hub: true), dort wird nur abgestellt
  - eine Stadt-Datei kann dieselben Bloecke enthalten; sie addieren sich zur
    Firmen-Datei


1g. Teilladungen und Tourplanung (Frachtmarkt, eigener Auflieger)
-----------------------------------------------------------------
Eine Firma kann im Frachtmarkt Teilladungen anbieten und annehmen:

  units_out :                  Einheiten, die diese Firma je Fracht VERSCHICKT
  {
  default: 1-max               jede Menge bis zur vollen Ladung
  cargo.furniture: 1-6         diese Fracht nur 1 bis 6 Einheiten
  cargo.cement: max            diese Fracht nur als volle Ladung
  }
  units_in : { ... }           dasselbe fuer das, was diese Firma ANNIMMT

  load_mix_out :               wie oft eine volle bzw. eine Teilladung
  {                            angeboten wird (Gewichtung, beliebige Zahlen)
  default :
  {
  full: 60
  partial: 40
  }
  cargo.furniture :
  {
  full: 20
  partial: 80
  }
  }
  load_mix_in : { ... }        dasselbe auf der Empfaengerseite

  - Werte: eine Zahl, von-bis (z. B. 1-6) oder max (= volle Ladung)
  - eine cargo.<name>-Zeile geht vor, sonst gilt default
  - eine Stadt-Datei ersetzt in dieser Stadt den ganzen Block der
    Firmen-Datei
  - kein units-Block bei Absender und Empfaenger = nur volle Ladungen wie im
    Spiel; ein Block nur auf einer Seite = die andere Seite nimmt nur volle
    Ladungen
  - kein load_mix-Block = volle und Teilladungen halb und halb
  - tour und mixed in load_mix sind fuer eine spaetere Version reserviert
  - eine Teilladung ist weniger als die Mindestfuellung des Aufliegers
    (cargo_min_fill des Aufbaus in /def/economy_trailers_data/, im Spiel
    meist 0.8); die Menge ist auf das begrenzt, was noch auf den Auflieger
    passt
  - Fracht mit load_unit: whole (siehe README der Frachtdaten) gibt es nie als
    Teilladung

Zuladen und Tourplanung mit Teilladungen:
  - "Als Navi-Ziel einstellen" bei einem Frachtmarkt-Angebot merkt es vor
    (auch bevor etwas geladen ist); Annehmen auf dem Firmenhof nimmt es in die
    Fahrt; hoechstens 8 Auftraege und Vormerkungen zusammen
  - jeder Auftrag und jede Vormerkung belegt ihren Anteil an Platz und
    Gewicht; der Frachtmarkt zeigt dann nur noch Angebote, die zusaetzlich
    passen: Platz, Gewicht, Temperatur / Lebensmittel / Gefahrgut,
    Lieferzeiten und das Gebiet: ab der zweiten Fracht muessen Absender UND
    Empfaenger eines neuen Angebots je hoechstens 100 km (Strasse) von einem
    Absender oder Empfaenger der Fahrt entfernt liegen (auch im Ausland); die
    erste Fracht ist frei
  - ein voll verplanter Auflieger sperrt den Frachtmarkt, bis ein Teil
    abgeliefert oder eine Vormerkung storniert ist
  - der aktive Auftrag (Navi) ist die Wahl des Spielers (Rechtsklick auf eine
    Auftragskachel im Hauptmenue oder "Als Naechstes anfahren" in "Aktueller
    Auftrag"), sonst das naechste Ziel zuerst, ausser ein anderer Auftrag
    wuerde dadurch seine Lieferzeit verpassen
  - Fahrt und Vormerkungen werden mit dem Spielstand gespeichert


2. Containerfracht
------------------
Gleicher Ordner und gleicher Name wie die model_area-Datei der Containerfracht,
nur mit .v3def, eine Datei je Containergroesse:

  /def/vehicle/cargo/your_cargo_c/model_area_20.sii
  -> /def/vehicle/cargo/your_cargo_c/model_area_20.v3def
  /def/vehicle/cargo/your_cargo_c/model_area_40.sii
  -> /def/vehicle/cargo/your_cargo_c/model_area_40.v3def

  body_type: dryvan        Container fuer jede Fracht dieses Aufliegertyps,
                           solange er auf dem Chassis bleibt (dryvan,
                           refrigerated, insulated, oder foodtank fuer einen
                           Lebensmittel-Tankcontainer)
  body_type: <Frachtname>  Spezialcontainer fuer genau eine Fracht (z. B.
                           Gefahrgut-Tankcontainer - Kraftstoff, Chemikalien,
                           Gas - deren Tafeln zur Fracht gehoeren): der Aufbau
                           heisst GENAU wie die Fracht (ihre Fracht-.sui und
                           dieser Ordner). Er wird nur wieder mit dieser
                           Fracht beladen, nie von der Firma, die ihn gerade
                           bekommen hat (eine andere Firma belaedt ihn, sonst
                           geht er leer zurueck). Jeder andere Name steht im
                           Log.
  body_type: none          gar keine Folgefracht: der Container kann nur leer
                           zurueckgebracht werden
  body_mass: 2200          Leergewicht des Containers in kg
  volume: 33               Innenvolumen in m3

Fehlende Datei oder fehlende Zeile - Standardwerte:
  body_type  dryvan
  body_mass  20 ft 2200 kg, 40 ft 3750 kg  (Kuehl: 3000 / 4800 kg)
  volume     20 ft 33 m3,   40 ft 67 m3    (Kuehl: 28 / 59 m3)
20 ft oder 40 ft ergibt sich aus der Modellgroesse (laenger als 9 m = 40 ft).


Symbol fuer "Leercontainer zurueck"
-----------------------------------
Datei: def/vehicle/cargo/<your_cargo_c>/accessory_container_<groesse>_<farbe>.v3def
       (gleicher Name wie die Accessory-.sii, Endung .v3def)

  empty_icon: "/material/ui/cargo_icons/<your_icon>.mat"

Die .mat muss in /material/ui/cargo_icons/ liegen (wie jedes Frachtsymbol,
122 x 96 px, transparent). Sie erscheint im Frachtmarkt und in der Auftragsinfo
beim Angebot "Leercontainer zurueck" dieses Containers.
Fehlende Datei - das Symbol der Mod fuer einen 20 ft / 40 ft Koffer- oder
Tankcontainer wird verwendet.


3. Land-Datei (Fahrerlohn)
--------------------------
Gleicher Ordner und gleicher Name wie die Land-Datei des Spiels, nur mit .v3def:

  /def/country/your_country.sui
  -> /def/country/your_country.v3def

  driver_wage :
  {
  hourly_net_wage: 11.13
  daily_allowance: 28
  bonus_max: 25
  allowance_tier[]: 8 0.5
  allowance_travel[]: 0 0.5
  }

  - hourly_net_wage: Nettolohn je Arbeitsstunde; eine Fahrer-Tour zahlt
    hoechstens 10 Arbeitsstunden je Kalendertag und 48 Stunden je Tour (eine
    Tour dauert hoechstens 4 Tage + 8 Stunden)
  - daily_allowance: Spesen fuer einen vollen Tag Abwesenheit
  - die Tour beginnt mit der Annahme und endet mit dem Lieferbericht;
    Kalendertage in Spielzeit. Volle Tage zwischen dem ersten und dem letzten
    Tag zaehlen immer voll. Wie viel der erste/letzte Tag und eine eintaegige
    Tour bekommen, haengt vom Land ab:
  - allowance_tier[]: Stunden Anteil - eintaegige Tour (Start und Ende am
    selben Kalendertag): der Anteil gilt fuer MEHR als diese Stunden, die
    hoechste passende Zeile zaehlt; 0 = jede Dauer. Keine Zeile = nichts.
      allowance_tier[]: 8 0.5      (mehr als 8 h: halber Tag)
  - allowance_travel[]: Stunden Anteil - erster und letzter Tag einer
    mehrtaegigen Tour, Stunden an diesem Tag; fehlt = wie allowance_tier.
      allowance_travel[]: 0 0.5    (immer halber Tag)
  - allowance_meal[]: hh:mm Anteil / night Anteil - statt Stunden: der Anteil
    zaehlt, wenn die Essenszeit an diesem Tag in der Tour liegt, night = eine
    auswaerts verbrachte Nacht (nicht am letzten Tag); hoechstens 1 je Tag.
    Zeilen von allowance_meal ersetzen die Stunden-Zeilen.
      allowance_meal[]: 13:00 0.333
      allowance_meal[]: night 0.334
  - allowance_same_day: 0 = eine eintaegige Tour bekommt keine Spesen
  - die Zeilen einer Liste ersetzen die Zeilen der Mod fuer dieses Land (alle
    Zeilen dieser Liste, nicht einzelne). Anteile 0 ... 1.
  - keine Spesen = keine Spesen-Zeile im Lieferbericht
  - bonus_max: hoechster Lohn ueber dem Satz in Prozent; jede Startfirma
    wuerfelt je Spielwoche ihren eigenen Bonus (die meisten zahlen den Satz),
    0 = nie
  - es entscheidet das Land der Firma, bei der die Tour beginnt
  - fehlende Datei oder Zeile: der Wert der Mod fuer dieses Land gilt
    (lphd_land_v3def.zip enthaelt sie fuer alle Laender)

Fahrer-Touren (Schnellauftraege) zahlen Lohn und Spesen statt des
Frachtlohns. Kraftstoff zahlt der Arbeitgeber (Spiel), Abzuege fuer
Frachtschaden oder Verspaetung uebernimmt der Arbeitgeber.


Format
------
  schluessel: wert

  - ein Eintrag je Zeile, Leerzeichen oder Tabs um den Doppelpunkt erlaubt
  - Zeilen mit # oder // am Anfang sind Kommentare, ein # nach dem Wert auch
  - Zahlen mit Dezimalpunkt, keine Einheiten in der Zeile
  - eine Zeile mit falschem Wert steht im game.log und wird ignoriert


EN
==

1. Company files
----------------
Same folder and same name as the company files of the game, only with .v3def:

  all cities    /def/company/your_company.sui
             -> /def/company/your_company.v3def

  one city      /def/company/your_company/editor/your_city.sii
             -> /def/company/your_company/editor/your_city.v3def

The city file name is the city token (the editor file name up to the first
dot). A city file replaces the working hours of the company file in that city,
and a container_load line in a city file applies to that city only (e.g. a
company that has a reach stacker at just one of its sites).


1a. Working hours
-----------------
  working_time :
  {
  monday: (06.00, 22.00)
  saturday: (07.00, 12.00);(13.00, 16.00)
  sunday: closed
  }

  - days: monday tuesday wednesday thursday friday saturday sunday
  - one or more time spans (hh.mm, hh.mm), several separated by ;
  - 24.00 = end of the day; an end at or before the start runs past
    midnight, e.g. (22.00, 06.00)
  - closed = closed all day
  - a missing day = open all day
  - no file or no working_time block = the company is always open

While a company is closed, its offers are hidden, no new cargo is generated
there, and its company point shows that it is closed together with the
working hours.

Special transports (oversize) can have their own hours in the same file:

  working_time_oversize :
  {
  monday: (07.00, 16.00)
  saturday: closed
  sunday: closed
  }

  - same format as working_time
  - used for loading (start) and unloading (destination) of special
    transports; missing block = working_time applies
  - a special transport offer only appears if it can be loaded now, driven
    (50 km/h on average, at most 10 h driving per 24 h, 45 min break after
    4.5 h) and unloaded in these hours before Friday 15:00 (no oversize
    driving Fri 15:00 - Mon 09:00)


1b. Reach stacker (containers)
------------------------------
  container_load: true     reach stacker: container cargo is given out to own
                           container chassis, a container is lifted off on
                           delivery
  container_load: false    no reach stacker: no container cargo for own
                           container chassis, the container stays on the
                           chassis

Companies without the line: the cargo market is not changed; on delivery the
company counts as without reach stacker (container stays).

What happens with an own container chassis:
- A container is lifted on and off only where the company has a reach stacker.
- Delivered at a company without reach stacker, the container stays on the
  chassis. The chassis then works like the trailer type of the container
  (see 2.), with the empty weight and inner volume of the container, and the
  cargo market offers cargo for that trailer type.
- Directly after unloading there, the cargo market of that company also offers
  "Empty container" back to one of the 10 nearest companies with reach
  stacker: low pay, no loading. The offer is valid as long as the truck stays
  on the company yard.
- A cargo carried in the container to a company with reach stacker takes the
  container off the chassis.


1c. Cargo filters
-----------------
Blocks with one cargo per line, written as the cargo_data name of the game
(cargo.<name>, as in the cargo .sui):

  ignore_in :                  cargo the company never receives
  {                            (cargo market and trailer jobs)
  cargo.air_mails
  }
  ignore_out :                 cargo the company never sends
  { ... }

  freight_market: false        no cargo market offers for own trailers at this
                               company ("Cargo market" / "External cargo
                               market"); the company also never loads cargo
                               onto a trailer that is not its own
  freight_market_ignore_in : { ... }    only for the cargo market
  freight_market_ignore_out : { ... }

  semi_trailerjob_in: false    no trailer jobs ("Freight market", trailer is
  semi_trailerjob_out: false   provided) to / from this company
  semi_trailerjob_ignore_in : { ... }   only for trailer jobs
  semi_trailerjob_ignore_out : { ... }

  - only false is allowed for freight_market / semi_trailerjob_in / _out;
    a missing line = the game lists in full
  - the filters add to each other (e.g. ignore_out and
    semi_trailerjob_ignore_out)
  - what arrives at a company is decided only by its in folder of the game and
    these filters


1d. Trailer jobs: what happens at the destination (return trips)
----------------------------------------------------------------
For trailer jobs the destination company decides per body type of the
trailer what happens after arrival:

  semi_trailerjob_return_full :    unload, load return cargo at this company,
  {                                drive back to the sender
  curtainside
  dryvan
  }
  semi_trailerjob_return_empty :   unload only; the return cargo is loaded at
  {                                the nearest fitting company (same city
  fueltank                         first, else outside), otherwise back empty
  lowbed
  }
  semi_trailerjob_drop: true       pure drop yard (e.g. unaccompanied trailers
                                   for ferry or rail): every trailer is only
                                   parked, the job ends there
  trailer_hub: true                transshipment point (rail or ferry
                                   terminal): as SENDER it takes back loaded
                                   trailers, the return cargo does not have to
                                   be in its in list

Body type without entry:
  curtainside, dryvan, refrigerated, insulated, flatbed, container,
  flatbed_cont = return_full; every other body type (tanks, silo, tipper,
  low loader, logs, livestock, car transporter ...) = return_empty.
Rule of thumb: return_full for a special body only where the company loads the
same body itself (quarry - tipper, sawmill - logs, car terminal - car
transporter); low loaders always return_empty.

Return cargo:
  - loaded like the cargo market of the game loads a trailer that is not the
    company's own: the cargo must fit the trailer (body type, volume, weight),
    the loading company must be allowed to send it (ignore_out,
    freight_market rules; semi_trailerjob_out does not apply, the company
    only loads), the sender must accept it (its in list, ignore_in,
    semi_trailerjob rules) unless the sender is a trailer_hub
  - chosen at random with the cargo weights of the game, fixed per offer
  - containers: loading company with container_load: true - the container is
    lifted off and any container cargo goes onto the chassis; with
    container_load: false - the container stays, a box container is loaded
    with cargo of its body type, a special container (body_type = cargo name,
    see section 2) only with that cargo
  - the destination company never gives back the cargo it has just received
  - the whole trip is one job: one delivery time at the sender, paid at the
    sender: outbound + return cargo; an empty run (destination - loading
    company, or back empty) is paid like an empty container: 10 % of the
    units of the outbound cargo per km

The job list shows the trip as Start > Destination > (2nd company >) Start,
the return cargo in blue after the outbound cargo, and the total distance,
time and pay. A city file can hold the same lines for one city (a block in
the city file goes first for its body types).


1e. Waiting times
-----------------
  wait_time :
  {
  load: 30-180
  unload: 30-180
  pickup: 5-20
  drop: 5-15
  }
  wait_factors :
  {
  1.5 : (06.00, 08.00);(12.00, 13.00)
  0.7 : (22.00, 06.00)
  }

  - load = loading, unload = unloading, pickup = taking over a prepared
    loaded trailer, drop = parking the trailer at a pure drop yard (T)
  - minutes from-to; each check-in rolls a random time in between
  - wait_factors: factor = time spans (hh.mm or hh:mm), several spans with
    the same factor separated by ;  an end at or before the start runs past
    midnight; outside all spans the factor is 1.0
  - a missing line or block uses the city file, then the company file, then
    the default: load/unload 30-180, pickup 5-20, drop 5-15, factors
    06-10 x1.5, 16-22 x0.7, 22-06 x0.5

The waiting time sits between confirming (choosing the parking difficulty on
delivery, Enter on the loading/unloading bay with an own trailer, or the
loading tile) and the bay/trailer being released. On check-in a message shows
the expected time. Leaving the company premises cancels the check-in. While
waiting, stop on the premises and switch the engine off: a hint offers a rest
until the end of the waiting time. On release everything continues by itself.


1f. Bays per body type (parking difficulty)
-------------------------------------------
A company can keep bays of one difficulty free of certain body types, e.g.
no low loaders at the loading docks (hard bays):

  lanes_hard_ignore :          body types (body_type of the trailer, without
  {                            prefix) that never load or unload on a hard bay
  lowbed
  lowboy
  }
  lanes_medium_ignore : { ... }   the same for medium bays
  lanes_easy_ignore : { ... }     the same for easy bays

  - applies to every job type at this company: cargo market, driver jobs,
    trailer jobs and return cargo
  - loading: if the loading bay of the job is on a blocked difficulty, the job
    gets a free allowed loading bay of the company (fitting length, not
    occupied); if there is none, the bay of the game stays
  - unloading: blocked difficulties cannot be chosen
  - cargo market: if the loading company has no allowed loading bay or the
    destination has no allowed unloading bay for the trailer, there is no
    offer for it
  - the body type is the one of the trailer that is attached
  - fixed in the DLL, at every company: low loaders (lowbed, lowboy) only on
    easy bays; medium, hard and loading points without difficulty (e.g. docks)
    are always blocked for them; except trailer hubs (trailer_hub: true),
    where trailers are only dropped
  - a city file can hold the same blocks; they add to the company file

1g. Partial loads and tour planning (cargo market, own trailer)
---------------------------------------------------------------
A company can offer and accept partial loads in the cargo market:

  units_out :                  units this company SENDS per cargo
  {
  default: 1-max               any amount up to a full load
  cargo.furniture: 1-6         this cargo only 1 to 6 units
  cargo.cement: max            this cargo only as a full load
  }
  units_in : { ... }           the same for what this company RECEIVES

  load_mix_out :               how often a full or a partial load is offered
  {                            (weights, any numbers)
  default :
  {
  full: 60
  partial: 40
  }
  cargo.furniture :
  {
  full: 20
  partial: 80
  }
  }
  load_mix_in : { ... }        the same on the receiving side

  - values: a number, from-to (e.g. 1-6), or max (= a full load)
  - a cargo.<name> line goes first, otherwise default applies
  - a city file replaces the whole block of the company file in that city
  - no units block at sender and receiver = full loads only, as in the game;
    a block on one side only = the other side takes full loads only
  - no load_mix block = full and partial half and half
  - tour and mixed in load_mix are reserved for a later version
  - a partial load is less than the minimum filling of the trailer
    (cargo_min_fill of the body type in /def/economy_trailers_data/, game
    default 0.8); the amount is limited to what still fits on the trailer
  - cargo with load_unit: whole (see README of the cargo data) is never
    offered as a partial load

Adding cargo and tour planning with partial loads:
  - "Set as GPS destination" on a cargo market offer reserves it (also
    before anything is loaded); taking an offer on the company yard adds it to
    the trip; at most 8 jobs and reservations together
  - every job and reservation takes its share of space and weight; the
    cargo market then only shows offers that still fit: space, weight,
    temperature / food / dangerous goods, delivery times, and the area:
    from the second cargo on, the sender AND the receiver of a new offer must
    each lie within 100 km (road) of a sender or receiver already in the
    trip (also abroad); the first cargo is free
  - a fully planned trailer locks the cargo market until a part is
    delivered or a reservation is cancelled
  - the active job (GPS) is the player's choice (right-click on a job tile in
    the main menu, or "Drive here next" in Current job), otherwise the
    nearest destination first unless another job would then miss its
    delivery time
  - the trip and the reservations are saved with the save game

2. Container cargo
------------------
Same folder and same name as the model_area file of the container cargo, only
with .v3def, one file per container size:

  /def/vehicle/cargo/your_cargo_c/model_area_20.sii
  -> /def/vehicle/cargo/your_cargo_c/model_area_20.v3def
  /def/vehicle/cargo/your_cargo_c/model_area_40.sii
  -> /def/vehicle/cargo/your_cargo_c/model_area_40.v3def

  body_type: dryvan        container for any cargo of this trailer type
                           while it stays on the chassis (dryvan,
                           refrigerated, insulated, or foodtank for a food
                           tank container)
  body_type: <cargo name> special container made for exactly one cargo
                           (e.g. dangerous goods tank containers - fuel,
                           chemicals, gas - whose plates belong to the
                           cargo): the body type has the
                           SAME name as the cargo (its cargo .sui and this
                           folder). It is only loaded again with this cargo,
                           never by the company that just received it
                           (another company loads it, otherwise it goes back
                           empty). Any other name is reported in the log.
  body_type: none          no follow-up cargo at all: the container can only
                           be returned empty
  body_mass: 2200          empty weight of the container in kg
  volume: 33               inner volume in m3

Missing file or missing line - default values:
  body_type  dryvan
  body_mass  20 ft 2200 kg, 40 ft 3750 kg  (refrigerated: 3000 / 4800 kg)
  volume     20 ft 33 m3,   40 ft 67 m3    (refrigerated: 28 / 59 m3)
20 ft or 40 ft comes from the model size (longer than 9 m = 40 ft).


Icon for "Return container"
---------------------------
File: def/vehicle/cargo/<your_cargo_c>/accessory_container_<size>_<color>.v3def
      (same name as the accessory .sii, ending .v3def)

  empty_icon: "/material/ui/cargo_icons/<your_icon>.mat"

The .mat must be in /material/ui/cargo_icons/ (like every cargo icon,
122 x 96 px, transparent). It is shown in the cargo market and the job info
for the "Return container" offer of this container.
Missing file - the mod icon for a 20 ft / 40 ft box or tank container is used.


3. Country file (driver wage)
-----------------------------
Same folder and same name as the country file of the game, only with .v3def:

  /def/country/your_country.sui
  -> /def/country/your_country.v3def

  driver_wage :
  {
  hourly_net_wage: 11.13
  daily_allowance: 28
  bonus_max: 25
  allowance_tier[]: 8 0.5
  allowance_travel[]: 0 0.5
  }

  - hourly_net_wage: net wage per working hour; a driver tour pays at most
    10 working hours per calendar day and 48 hours per tour (a tour lasts at
    most 4 days + 8 hours)
  - daily_allowance: allowance for one full day of absence
  - the tour starts when it is taken and ends with the delivery report;
    calendar days in game time. Full days between the first and the last
    day always count full. How much the first/last day and a one-day tour
    get depends on the country:
  - allowance_tier[]: hours share - one-day tour (start and end on the same
    calendar day): the share applies to MORE than these hours, the highest
    matching line counts; 0 = any duration. No line = nothing.
      allowance_tier[]: 8 0.5      (more than 8 h: half a day)
  - allowance_travel[]: hours share - first and last day of a tour over
    several days, hours counted on that day; missing = as allowance_tier.
      allowance_travel[]: 0 0.5    (always half a day)
  - allowance_meal[]: hh:mm share / night share - instead of hours: the
    share counts if the meal time lies within the tour on that day, night =
    a night spent away (not on the last day); at most 1 per day. Lines of
    allowance_meal replace the hour lines.
      allowance_meal[]: 13:00 0.333
      allowance_meal[]: night 0.334
  - allowance_same_day: 0 = a one-day tour gets no allowance
  - the lines of a list replace the mod's lines for this country (all lines
    of that list, not single ones). Shares 0 ... 1.
  - no allowance = no allowance line in the delivery report
  - bonus_max: highest pay above the rate in percent; each start company
    rolls its own bonus per game week (most pay the rate), 0 = never
  - the country of the company where the tour starts decides
  - missing file or line: the mod's value for this country is used
    (lphd_land_v3def.zip holds them for all countries)

Driver tours (quick jobs) pay wage and allowance instead of the cargo pay.
Fuel is paid by the employer (game), deductions for cargo damage or delay are
taken over by the employer.


Format
------
  key: value

  - one entry per line, spaces or tabs around the colon are allowed
  - lines starting with # or // are comments, a # after the value too
  - numbers with decimal point, no units on the line
  - a line with a wrong value is reported in game.log and ignored
